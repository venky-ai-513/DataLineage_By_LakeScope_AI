#!/bin/bash
set -e
#---------------------------------------------
# Input parameters
#---------------------------------------------
ENVIRONMENT=${1}
DEPLOYMENT_ID=${2}

aws_account_id=720968118375		# aws-crg-daas-datalake-dev AWS account ID
region=ap-southeast-2

####################################
# tag docker image and push to ECR
####################################
# there are two versions of the AWS client in our infrastructure,
# this get-login help command only works on the AWS CLI (version 1).
# AWS CLI version 2, use get-login-password instead.
echo "Logging to ECR registry in Datalake Dev AWS account"
if aws ecr get-login help &> /dev/null
then
  # shellcheck disable=SC2046
  eval $(aws ecr get-login --registry-ids ${aws_account_id} --no-include-email --region ${region})
else
  aws ecr get-login-password --region ${region} | docker login --username AWS --password-stdin ${aws_account_id}.dkr.ecr.${region}.amazonaws.com
fi

module_path=daas-crg
submodule_path=materialized-views
if [ "$DEPLOYMENT_ID" != "dev" ]
then
	repo_name=${module_path}/${submodule_path}/${DEPLOYMENT_ID}
else
	repo_name=${module_path}/${submodule_path}
fi

# check if repo exists
repo=$(aws ecr describe-repositories --region ${region} --repository-names ${repo_name} --registry-id ${aws_account_id})

docker tag ${submodule_path}:latest ${aws_account_id}.dkr.ecr.${region}.amazonaws.com/${repo_name}:latest

# retag ecr image:latest to image:now
MANIFEST=$(aws ecr batch-get-image --repository-name ${repo_name} --image-ids imageTag=latest --query 'images[].imageManifest' --output text --region ${region} --registry-id ${aws_account_id})
if test ! -z "$MANIFEST"
then
	newtag=$(date +%Y-%m-%dT%H-%M-%S)
	aws ecr put-image --repository-name ${repo_name} --image-tag ${newtag} --image-manifest "$MANIFEST" --region ${region} --registry-id ${aws_account_id}
fi

# push image to aws ecr repo
docker push ${aws_account_id}.dkr.ecr.${region}.amazonaws.com/${repo_name}:latest

# remove docker images from local machine
docker logout
# docker system prune -a -f