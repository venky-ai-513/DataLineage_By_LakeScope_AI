import configparser
import sys
import os
import re

# Define a mapping from your data types to Spark data types
type_mapping = {
    "varchar": "StringType",
    "int": "IntegerType",
    "date": "DateType",
    "timestamp": "TimestampType",
    "double": "DoubleType",
    "decimal": "DecimalType",
    "binary": "IntegerType",
    "bigint": "IntegerType"
}

def convert_to_spark_type(data_type):
    """
    Converts a given data type to a corresponding Spark data type.
    """
    if data_type.startswith("decimal"):
        match = re.match(r"decimal\((\d+),(\d+)\)", data_type)
        if match:
            precision, scale = match.groups()
            return f"DecimalType({precision},{scale})"
        else:
            return "DecimalType"  # Default if no precision/scale provided
    for key in type_mapping.keys():
        if data_type.startswith(key):
            return type_mapping[key]
    return "StringType"  # Default fallback

def read_schema_from_tsv(file_path):
    """
    Reads a TSV file and returns a dictionary mapping column to data type.
    """
    schema = {}
    if not os.path.isfile(file_path):
        print(f"  ❌ File not found: {file_path}")
        return schema

    with open(file_path, 'r') as file:
        for line_number, line in enumerate(file, start=1):
            if '\t' not in line:
                print(f"  ⚠️ Skipping line {line_number}: no tab delimiter.")
                continue
            parts = line.strip().split('\t')
            if len(parts) != 2:
                print(f"  ⚠️ Skipping line {line_number}: expected 2 fields, got {len(parts)}")
                continue
            column, data_type = parts
            schema[column] = data_type
    return schema

def main(views_folder, output_file_path):
    config = configparser.ConfigParser()
    sections_added = False

    print(f"🔍 Scanning base folder: {views_folder}")
    
    if not os.path.isdir(views_folder):
        print(f"❌ Error: Provided path '{views_folder}' is not a folder.")
        sys.exit(1)

    for folder_name in os.listdir(views_folder):
        folder_path = os.path.join(views_folder, folder_name)
        print(f"📁 Checking folder: {folder_path}")

        if not os.path.isdir(folder_path):
            print(f"  ⏭️ Skipped (not a folder): {folder_path}")
            continue

        for file_name in os.listdir(folder_path):
            print(f"    📄 Found file: {file_name}")
            if file_name == f'{folder_name}.txt':
                print(f"    ✅ Matched expected TSV: {file_name}")
                view = file_name.split('.')[0]
                input_file_path = os.path.join(folder_path, file_name)

                schema = read_schema_from_tsv(input_file_path)
                if not schema:
                    print(f"    ⚠️ Skipping '{file_name}' — empty or invalid format.")
                    continue

                if not config.has_section(view):
                    config.add_section(view)
                    sections_added = True
                    print(f"    ➕ Adding section: {view}")

                for column, data_type in schema.items():
                    spark_data_type = convert_to_spark_type(data_type)
                    config.set(view, column, spark_data_type)
                    print(f"      ➕ {column}: {spark_data_type}")

    if not sections_added:
        print("⚠️ No sections added. Are the TSV files named correctly and not empty?")
    else:
        # Ensure output directory exists
        os.makedirs(os.path.dirname(output_file_path), exist_ok=True)
        with open(output_file_path, 'w') as configfile:
            config.write(configfile)
        print(f"✅ INI file written: {output_file_path}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python create_sparkdtypes.py <views_folder>")
        sys.exit(1)
    else:
        views_folder = sys.argv[1]
        output_file_path = '../glue/configfiles/bamv_schema.ini'
        main(views_folder, output_file_path)
