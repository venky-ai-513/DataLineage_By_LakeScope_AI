#!/bin/bash

#---------------------------------------------
# Input parameters
#---------------------------------------------
ENVIRONMENT=${1}
DEPLOYMENT_ID=${2}

aws_account_id=$(aws sts get-caller-identity --output text --query 'Account')
region=ap-southeast-2

echo "Logging to ECR registry in ${ENVIRONMENT}"
if aws ecr get-login help &> /dev/null
then
  # shellcheck disable=SC2046
  eval $(aws ecr get-login --registry-ids ${aws_account_id} --no-include-email --region ${region})
else
  aws ecr get-login-password --region ${region} | docker login --username AWS --password-stdin ${aws_account_id}.dkr.ecr.${region}.amazonaws.com
fi

# module settings
module_path=daas-crg
submodule_path="materialized-views"

if [ "$DEPLOYMENT_ID" != "dev" ] &&
  [ "$DEPLOYMENT_ID" != "uat" ] &&
  [ "$DEPLOYMENT_ID" != "prod" ]
then
    repo_name=${module_path}/${submodule_path}/${DEPLOYMENT_ID}
else
    repo_name=${module_path}/${submodule_path}
fi

# check if repo exists
repo=$(aws ecr describe-repositories --region ${region} --repository-names ${repo_name})
if test -n "$repo"
then
	# delete images from repo
	IMAGES=$(aws ecr list-images --repository-name ${repo_name} --query 'imageIds[*]' --output json --region ${region})
	echo $IMAGES
	aws ecr batch-delete-image --region ${region} \
		--repository-name ${repo_name} \
		--image-ids "$(aws ecr list-images --repository-name ${repo_name} --query 'imageIds[*]' --output json --region ${region})" || true

	# delete the repo
	aws ecr delete-repository --region ${region} \
		--repository-name ${repo_name}
else
	echo "Repository does not exist.. Cleanup not required in ${ENVIRONMENT}"
fi
