#!/bin/bash

BRANCH=${CODEBUILD_WEBHOOK_TRIGGER:-UNKNOWN}
BRANCH=${BRANCH/branch\//}
export BRANCH

set -euo pipefail

if [ "x${BRANCH}" != "x${ENVIRONMENT}" ]; then
    if [ "${DO_DEPLOY_TEST}" = "true" ]; then
        echo "*******************************************************"
        echo "This is a DEPLOY-TEST environment"
        echo "Branch: ${BRANCH}"
        echo "*******************************************************"

        # Create a temporary environment name from the commit
        if [ -n "${CODEBUILD_BUILD_ID}" ]; then
            ENVIRONMENT=$( echo "${CODEBUILD_BUILD_ID}" | cut -f2 -d: | cut -c1-8 )
        elif type -P git >/dev/null 2>&1; then
            ENVIRONMENT=$( git rev-parse --short HEAD )
        else
            ENVIRONMENT=$( date +%H%M%S )
        fi

        # don't exit on failure here, we need to clean up
        # set +e
        echo "SKIPPING deploy-test for SQL Views only (don't know how yet)"
        # make deploy-test
        # RETVAL=$?
        # if [ $RETVAL -ne 0 ]; then
            # echo "BUILD FAILED, stack events follow"
            # make status
            # echo "BUILD FAILED, cleaning up"
            # make undeploy
        # fi
        # exit $RETVAL
        exit 0
    else
        echo "*******************************************************"
        echo "Branch does not match this environment, will not deploy"
        echo "Branch: ${BRANCH}"
        echo "Environment: ${ENVIRONMENT}"
        echo "*******************************************************"
        exit 0
    fi
fi

case "$ENVIRONMENT" in
    dev|uat|prod)
        echo "Deploying to $ENVIRONMENT ..."
        make deploy
        ;;
    *)
        echo "Unknown environment: $ENVIRONMENT"
        exit 1
        ;;
esac
