import boto3
import botocore.exceptions

def delete_views_with_feature(database_name):
    glue_client = boto3.client('glue', region_name='ap-southeast-2')
    try:
        # Use paginator to fetch all tables in the database
        paginator = glue_client.get_paginator('get_tables')
        response_iterator = paginator.paginate(DatabaseName=database_name)
        views_to_delete = []

        # Iterate through all pages of tables
        for page in response_iterator:
            for table in page['TableList']:
                table_name = table['Name']
                # Check if the table is a view and contains 'feature' in its name
                if 'ViewOriginalText' in table and 'feature' in table_name:
                    views_to_delete.append(table_name)

        if not views_to_delete:
            print(f"No views containing 'feature' found in {database_name}.")
            return

        print(f"Views to delete: {views_to_delete}")

        # Delete views one by one
        for view in views_to_delete:
            print(f"Deleting view: {view}")
            glue_client.delete_table(DatabaseName=database_name, Name=view)
            print(f"View {view} deleted successfully.")

    except botocore.exceptions.ClientError as error:
        print(f"Error interacting with Glue: {error}")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

if __name__ == "__main__":
    # Replace this with your actual database name
    database_name = "crg_daas_dev_business_aligned_db"
    delete_views_with_feature(database_name)
