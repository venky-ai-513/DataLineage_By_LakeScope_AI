#!/bin/bash

# Usage: ./run_glue_job.sh <VIEW> <environment>
if [ -z "$1" ]; then
  echo "Please provide the view name as an argument."
  exit 1
fi

#Getting Account Id and setting enviroment
ACCOUNT_ID=$(aws sts get-caller-identity --query "Account" --output text)
echo "AWS Account ID: $ACCOUNT_ID"

if [ $? -ne 0 ]; then
  echo "Failed to retrieve AWS account ID. Please check your AWS CLI configuration."
  exit 1
fi

# Determine environment based on account ID
if [ "$ACCOUNT_ID" == "720968118375" ]; then
  ENV="dev"
elif [ "$ACCOUNT_ID" == "879173540614" ]; then
  ENV="prod"
else
  ENV="uat"
fi

# Print the environment
echo "Environment: $ENV"

# Extract the branch name and deployment ID
BUILDKITE_BRANCH=$(git branch --show-current)
DEPLOYMENT_ID=$(echo $BUILDKITE_BRANCH | tr -c -d '[A-Za-z0-9]' | tr '[A-Z]' '[a-z]' | cut -c1-15)
echo "Buildkite Branch: $BUILDKITE_BRANCH"
echo "Deployment ID: $DEPLOYMENT_ID"

# Set the view name from the script argument
VIEW=$1
echo "View Name: $VIEW"

# Define job name conditionally based on the environment and branch
if [ "$ENV" == "dev" ]; then
  if [ "$BUILDKITE_BRANCH" != "main" ]; then
    JOB_NAME="bamv_athena_output_convert_to_parquet_job_${ENV}_$DEPLOYMENT_ID"
  else
    JOB_NAME="bamv_athena_output_convert_to_parquet_job_${ENV}"
  fi
else
  JOB_NAME="bamv_athena_output_convert_to_parquet_job_${ENV}"
fi
echo "Job Name: $JOB_NAME"

# Define other parameters
TARGET_BUCKET="crg-daas-${ENV}-ap-southeast-2-${ACCOUNT_ID}-snapshot"
SOURCE_BUCKET="crg-daas-${ENV}-ap-southeast-2-${ACCOUNT_ID}-raw"
CONFIG_FILE_NAME="bamv_schema.ini"
EXTRA_FILES="s3://artifactory-ap-southeast-2-${ACCOUNT_ID}/crg-business-aligned-athena-views/materialized-views/glue/configfiles/$CONFIG_FILE_NAME"
echo "Target Bucket: $TARGET_BUCKET"
echo "Source Bucket: $SOURCE_BUCKET"
echo "Config File Name: $CONFIG_FILE_NAME"
echo "Extra Files: $EXTRA_FILES"

# Print the AWS Glue job command for debugging
echo "Running AWS Glue job with the following parameters:"
echo "aws glue start-job-run \
    --job-name $JOB_NAME \
    --arguments '{
        \"--TARGET_BUCKET\":\"$TARGET_BUCKET\",
        \"--SOURCE_PATH\":\"datasets/bamv/"$VIEW"_csv/\",
        \"--enable-job-insights\":\"true\",
        \"--TARGET_PATH\":\"datasets/bamv/"$VIEW"/snapshots/\",
        \"--SOURCE_BUCKET\":\"$SOURCE_BUCKET\",
        \"--config_file_name\":\"$CONFIG_FILE_NAME\",
        \"--job-language\":\"python\",
        \"--extra-files\":\"$EXTRA_FILES\",
        \"--JOB_NAME\":\"$JOB_NAME\",
        \"--DEPLOYMENT_ID\":\"$DEPLOYMENT_ID\",
        \"--VIEW\":\"$VIEW\"
    }'"

# Run the AWS Glue job with the specified parameters
aws glue start-job-run \
    --job-name $JOB_NAME \
    --arguments '{
        "--TARGET_BUCKET":"'"$TARGET_BUCKET"'",
        "--SOURCE_PATH":"datasets/bamv/'"$VIEW"'_csv/",
        "--enable-job-insights":"true",
        "--TARGET_PATH":"datasets/bamv/'"$VIEW"'/snapshots/",
        "--SOURCE_BUCKET":"'"$SOURCE_BUCKET"'",
        "--config_file_name":"'"$CONFIG_FILE_NAME"'",
        "--job-language":"python",
        "--extra-files":"'"$EXTRA_FILES"'",
        "--JOB_NAME":"'"$JOB_NAME"'",
        "--DEPLOYMENT_ID":"'"$DEPLOYMENT_ID"'",
        "--VIEW":"'"$VIEW"'"
    }'
