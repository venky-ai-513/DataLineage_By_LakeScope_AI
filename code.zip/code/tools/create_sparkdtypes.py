import configparser
import sys
import os
import re

# Define a mapping from your data types to Spark data types
type_mapping = {
    "varchar": "StringType",
    "int": "IntegerType",
    "date": "DateType",
    "double": "DoubleType",
    "decimal": "DecimalType",
    "binary": "IntegerType"
    # Add more mappings as needed
}

def convert_to_spark_type(data_type):
    """
    Converts a given data type to a corresponding Spark data type.
    """
    if data_type.startswith("decimal"):
        # Match and extract precision and scale using a regex
        match = re.match(r"decimal\((\d+),(\d+)\)", data_type)
        if match:
            precision, scale = match.groups()
            return f"DecimalType({precision}, {scale})"
        else:
            return "DecimalType"  # Default if no precision/scale provided
    for key in type_mapping.keys():
        if data_type.startswith(key):
            return type_mapping[key]
    return "StringType"  # Default to StringType if no match found

def read_schema_from_tsv(file_path):
    """
    Reads the schema from a TSV file and returns a dictionary.
    """
    schema = {}
    if not os.path.isfile(file_path):
        print(f"Error: File '{file_path}' not found.")
        sys.exit(1)
    with open(file_path, 'r') as file:
        for line in file:
            column, data_type = line.strip().split('\t')
            schema[column] = data_type
    return schema

def main(input_file_path, output_file_path, view):
    # Read the schema from the TSV file
    schema = read_schema_from_tsv(input_file_path)

    # Initialize the ConfigParser
    config = configparser.ConfigParser()

    # Read the existing INI file if it exists
    if os.path.isfile(output_file_path):
        config.read(output_file_path)
    
    # Create or update the section for the view
    if not config.has_section(view):
        config.add_section(view)

    # Add or update the schema to the section with Spark data types
    for column, data_type in schema.items():
        spark_data_type = convert_to_spark_type(data_type)
        if config.has_option(view, column):
            # If the option already exists, update it
            config.set(view, column, spark_data_type)
        else:
            # If the option does not exist, add it
            config.set(view, column, spark_data_type)

    # Write the updated configuration to the INI file
    with open(output_file_path, 'w') as configfile:
        config.write(configfile)

    print(f"INI file '{output_file_path}' updated successfully.")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python create_sparkdtypes.py <view_name>")
        sys.exit(1)
    else:
        view = sys.argv[1]
        input_file_path = f'../Views/{view}/{view}.txt'
        output_file_path = 'spark_values.ini'
        main(input_file_path, output_file_path, view)
