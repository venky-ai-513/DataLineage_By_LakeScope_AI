import boto3
import time

# AWS configurations
aws_region = "ap-southeast-2"  # Change to your AWS region
cloudtrail_bucket = "aws-controltower-logs-225818957351-ap-southeast-2"  # Replace with your CloudTrail bucket name
athena_output_bucket = "crg-daas-prod-materialized-views"  # Replace with your Athena results bucket
athena_output_location = f"s3://{athena_output_bucket}/athena-output-cloudwatch-testing/"
database_name = "cloudtrail_logs_db"  # Replace with your Athena database name
table_name = "cloudtrail_logs"  # Replace with your Athena CloudTrail table name

# Athena client
athena_client = boto3.client("athena", region_name=aws_region)

def execute_athena_query(query):
    """
    Executes an Athena query and returns the query execution ID.
    """
    response = athena_client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={"Database": database_name},
        ResultConfiguration={"OutputLocation": athena_output_location},
    )
    return response["QueryExecutionId"]

def wait_for_query(query_execution_id):
    """
    Waits for the Athena query to complete.
    """
    while True:
        response = athena_client.get_query_execution(QueryExecutionId=query_execution_id)
        status = response["QueryExecution"]["Status"]["State"]
        if status in ["SUCCEEDED", "FAILED", "CANCELLED"]:
            return status
        time.sleep(2)

def fetch_query_results(query_execution_id):
    """
    Fetches results of the Athena query.
    """
    paginator = athena_client.get_paginator("get_query_results")
    response_iterator = paginator.paginate(QueryExecutionId=query_execution_id)

    results = []
    for response in response_iterator:
        rows = response["ResultSet"]["Rows"]
        for row in rows[1:]:  # Skip header
            data = [col.get("VarCharValue", None) for col in row["Data"]]
            results.append(data)
    return results

def get_listbucket_api_calls():
    """
    Executes the Athena query to get ListBucket API call counts per bucket.
    """
    query = f"""
    SELECT 
        requestParameters.bucketName AS bucket_name, 
        COUNT(*) AS call_count
    FROM {table_name}
    WHERE eventName = 'ListBucket'
    GROUP BY requestParameters.bucketName
    ORDER BY call_count DESC
    """
    print("Executing query...")
    query_execution_id = execute_athena_query(query)
    status = wait_for_query(query_execution_id)

    if status == "SUCCEEDED":
        print("Query succeeded. Fetching results...")
        results = fetch_query_results(query_execution_id)
        print("Bucket | Calls")
        for bucket, call_count in results:
            print(f"{bucket} | {call_count}")
    else:
        print(f"Query failed with status: {status}")

if __name__ == "__main__":
    get_listbucket_api_calls()
