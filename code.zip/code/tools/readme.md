## How to Run Local Test
1. Make Sure Docker Application is Running
2. cd tools
3. ./local_test_repo <view_name>

## How to Run Glue Job

tip: Data should be present in aws s3 bucket location datasets/bamv/<viewname>_csv/

-->> ./runglue.sh <view_name>


## If you want to test the spark dtype thats been created(Before deploying to Main)

1. cd tools

2. RUN:
    -->> python3 create_sparkdtypes.py <view_name>


##  If you want to test pipleline ini file creation for all views

1. cd scripts

2. RUN:
    -->> python3 allsparkdtypes.py ../Views

