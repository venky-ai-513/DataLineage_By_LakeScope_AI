import sys
from pyathena import connect
import pandas as pd
import boto3

# Get AccountID
sts_client = boto3.client("sts")
account_id = sts_client.get_caller_identity()["Account"]

# Define Environment
def get_env(account_id):
    if account_id == '720968118375':
        return 'dev'
    elif account_id == '838525369068':
        return 'uat'
    else:
        return 'prod'

# Set Environment
env = get_env(account_id)

# Athena connection details
ATHENA_OUTPUT_LOCATION = f"s3://crg-daas-{env}-materialized-views"
ATHENA_DATABASE_BAMV = f"crg_daas_{env}_bamv_db"
ATHENA_DATABASE_BUSINESS_ALIGNED = f"crg_daas_{env}_business_aligned_db"

def get_columns(cursor, database, viewname):
    """Fetch column names dynamically from Athena for the specific view, capturing all words before a tab"""
    describe_query = f"DESCRIBE {database}.{viewname}"
    cursor.execute(describe_query)
    
    # Fetch all column names, stripping leading/trailing spaces and capturing everything before the first tab
    columns = [row[0].split('\t')[0].strip() for row in cursor.fetchall()]

    # Filter out any columns containing 'timestamp'
    columns = [col for col in columns if 'timestamp' not in col.lower()]

    # Sort the columns alphabetically
    columns = sorted(columns)

    return columns

def align_columns(bamv_columns, bal_columns):
    """Align bal_columns based on the order of bamv_columns."""
    
    # Normalize both lists for easier comparison
    normalized_bamv = [col.lower().replace('_', ' ') for col in bamv_columns]
    normalized_bal = {col.lower().replace('_', ' '): col for col in bal_columns}

    # Create an ordered list that includes all columns from bamv_columns
    ordered_bal_columns = []
    for col in normalized_bamv:
        # Check if the normalized column exists in normalized_bal
        if col in normalized_bal:
            ordered_bal_columns.append(normalized_bal[col])
        else:
            # If not found, keep the original name from bamv_columns
            # Here we add the column name directly, preserving the original from bamv_columns
            original_col_name = bamv_columns[normalized_bamv.index(col)]  # Find the original name
            ordered_bal_columns.append(original_col_name)

    # Remove duplicates while preserving order (if needed)
    final_ordered_columns = []
    [final_ordered_columns.append(col) for col in ordered_bal_columns if col not in final_ordered_columns]
    sys.stderr.write(f'{final_ordered_columns}')
    return final_ordered_columns

def build_dynamic_query(viewname, bamv_columns, bal_columns):
    """Build the SQL query using aligned columns"""

    #Aligning bal_columns to be same as bamv
    bal_columns = align_columns(bamv_columns, bal_columns)
    
    bamv_count_selects = ",\n    ".join([
        f'''
        COUNT(CASE 
            WHEN CAST({viewname}."{col}" AS VARCHAR) IS NULL OR CAST({viewname}."{col}" AS VARCHAR) = '' THEN NULL 
            ELSE CAST({viewname}."{col}" AS VARCHAR)
        END) AS "{col}_count"
        '''
        for col in bamv_columns
    ])
    
    bal_count_selects = ",\n    ".join([
        f'''
        COUNT(CASE 
            WHEN CAST(bal."{bal_col}" AS VARCHAR) IS NULL OR CAST(bal."{bal_col}" AS VARCHAR) = '' THEN NULL 
            ELSE CAST(bal."{bal_col}" AS VARCHAR)
        END) AS "{bamv_col}_count"
        '''
        for bamv_col, bal_col in zip(bamv_columns, bal_columns)  # Ensure corresponding pairs
    ])

    query = f"""
    SELECT 
        'bamv' AS table_name,
        COUNT(*) AS total_count,
        {bamv_count_selects}
    FROM 
        "{ATHENA_DATABASE_BAMV}"."{viewname}" AS {viewname}

    UNION ALL

    SELECT 
        'bal' AS table_name,
        COUNT(*) AS total_count,
        {bal_count_selects}
    FROM 
        "{ATHENA_DATABASE_BUSINESS_ALIGNED}"."{viewname}" AS bal;
    """
    #sys.stderr.write(f'{query}')
    return query

def fetch_and_display_results(viewname):
    """Execute the query and display the results in the terminal"""
    conn = connect(s3_staging_dir=ATHENA_OUTPUT_LOCATION, region_name='ap-southeast-2')

    with conn.cursor() as cursor:
        # Fetch dynamic columns for bamv and bal views
        bamv_columns = get_columns(cursor, ATHENA_DATABASE_BAMV, viewname)
        bal_columns = get_columns(cursor, ATHENA_DATABASE_BUSINESS_ALIGNED, viewname)

        # Build the query using aligned columns
        query = build_dynamic_query(viewname, bamv_columns, bal_columns)

        cursor.execute(query)

        # Fetch the result into a pandas DataFrame
        df = pd.DataFrame(cursor.fetchall(), columns=[col[0] for col in cursor.description])
        print(df)

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 tablecheck.py {Viewname}")
        sys.exit(1)
    
    viewname = sys.argv[1]
    fetch_and_display_results(viewname)

if __name__ == "__main__":
    main()
