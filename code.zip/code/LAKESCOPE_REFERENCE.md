# BAMV reference source

This folder is an extracted copy of the supplied CRG materialized-views archive. LakeScope reads the SQL files under `Views/` to enrich AWS-discovered BAMV tables with deterministic upstream lineage.

LakeScope never executes the Python, CloudFormation, SQL, or utility scripts in this folder. A definition is imported only when a matching live table already exists in an AWS Glue database named `crg_daas_<environment>_bamv_db`.

For normal BAMVs, lineage comes from `Views/<bamv>/<bamv>.sql`. For multi-stage Dask transformations, LakeScope reads the child SQL files and connects their physical AWS sources directly to the live BAMV; local intermediate dataframes are not added to the catalogue.

