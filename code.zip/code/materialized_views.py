import os
import boto3
import logging
import datetime
import pandas as pd
from crg_utils import aws
import awswrangler as wr
import subprocess
from dask_sql import Context
import time
from botocore.exceptions import ClientError
import sys
import time
import datetime
if os.path.dirname(os.path.realpath(__file__))=='/var/task':
    from crg_utils.help_functions import  GlueTableManager, clean_up_temp_tables, match_dtypes,snapshot_query, daskquery,partion_and_filters, ecs_function, glue_function,delete_unlisted_glue_tables,delete_athena_database
else:
    from test_playground.crg_utils.help_functions import  GlueTableManager, clean_up_temp_tables, match_dtypes,snapshot_query, daskquery,partion_and_filters, ecs_function, glue_function,delete_unlisted_glue_tables
import concurrent.futures
try:
    import test_playground.materialized_views_test as tpmv
except:
    pass
import test_playground.materialized_views_test as tpmv

def glue_partition_loads(database_name: str, output_bucket_uri: str, View: str, cview: str, env: str, accountid: str) -> aws.pd.DataFrame:
    # -------------------------------------------------------
    # Read the sql of a single view and export the data as a pandas dataframe
    # -------------------------------------------------------
    manager = GlueTableManager(region='ap-southeast-2')
    bucket = f"crg-daas-{env}-ap-southeast-2-{accountid}-raw"
    table, date1, period, now, partitions, filter = partion_and_filters(database_name, output_bucket_uri, View, cview, env, accountid=accountid)
    sys.stderr.write(f'\n{filter}')
    
    # Write filter to SQL file
    sql_file_path = f'Views/{View}/{cview}.sql'
    with open(sql_file_path, "a") as file:
        file.write(filter)
        file.seek(0)
    
    # Function to handle glue_function calls
    def process_glue_partition(i):
        with open(sql_file_path, "r+") as file:
            if (period == 'fullload') or (period == 'yearload') or (period == 'monthload') or (period =='yearmonth'):
                glue_function(View, env, accountid, bucket, date1, partitions, file, i)
            else:
                # Do nothing or return an appropriate value if necessary
                pass
    
    # Parallel processing for glue_function
    if (period == 'fullload') or (period == 'yearload') or (period == 'monthload') or (period =='yearmonth'):
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = [executor.submit(process_glue_partition, i) for i in range(len(partitions))]
            for future in concurrent.futures.as_completed(futures):
                try:
                    future.result()  # This will raise an exception if the function raised one
                except Exception as exc:
                    # Cancel all other futures
                    for f in futures:
                        if not f.done():
                            f.cancel()
                            sys.stderr.write(f"\nCancelled Multithreading Job")
                            # Print the exception message and exit the script immediately
                            sys.exit(f"Glue function for partition generated an exception: {exc}")
    else:
        bucket=f"crg-daas-{env}-ap-southeast-2-{accountid}-snapshot"
        for i in range(len(partitions)):
            with open(sql_file_path, "r+") as file:
                ecs_function(database_name, output_bucket_uri, View, env,bucket, date1, period, now, partitions, file, i)
    
    sys.stderr.write(f"\n{View} partitioned all data")

    
def push_data_to_s3(View: str,env: str,accountid: str,database: str):
    # -------------------------------------------------------
    # Set which bucket the data is to be pushed to, and read the sql query in view and save date into dask df
    # -------------------------------------------------------
    sys.stderr.write(f"\ndatabase: {database}")
    now = datetime.datetime.utcnow()
    sys.stderr.write(f"\nEnviroment: {env}\nAccountID: {accountid}")
    bucket = f"crg-daas-{env}-ap-southeast-2-{accountid}-snapshot"
    sys.stderr.write(f"\nS3 Snapshot Bucket Output Location: {bucket}")
    outputbucket_uri = f"crg-daas-{env}-materialized-views"
    outputbucketurifolder = f"Athena-Output/{View}"
    testingfolder = f"datasets/bamv_testing/{View}"
    aws.create_s3_folder(outputbucket_uri, outputbucketurifolder)
    aws.create_s3_folder(bucket, testingfolder)
    outputbucketuri = f"s3://crg-daas-{env}-materialized-views/Athena-Output/{View}/"
    databasename = f"crg_daas_{env}_business_aligned_db"
    #try:
    files = folders = 0
    for _, dirnames, filenames in os.walk(f'./Views/{View}'):
        files += len(filenames)
        folders += len(dirnames)
        file_path = ""
        if folders > 0:
            sys.stderr.write(f'\n{View}')
            # -------------------------------------------------------
            # Tables that use dask-sql local memory
            # -------------------------------------------------------
            MV_df = daskquery(databasename,outputbucketuri,View=f"{View}",env=env)
            if database==f"crg_daas_{env}_bamv_db_testing":
                file_path = f"datasets/bamv_testing/{View}/snapshots/{now.strftime('%Y%m%d%H%M%S')}.parquet"
            else:
                file_path = f"datasets/bamv/{View}/snapshots/{now.strftime('%Y%m%d%H%M%S')}.parquet"
            _ = aws.put_object_to_s3(df=MV_df.compute(),
                                bucket_name=bucket,
                                key=file_path)
            sys.stderr.write(f"\nExported Data to s3 {file_path}")
        elif (os.path.exists(f'Views/{View}/fullload.txt') ==  False):
            # -------------------------------------------------------
            # Tables that either Go to Raw or Output Directly to Snapshot Bucket 
            # -------------------------------------------------------
            sys.stderr.write(f'\n{View} running')
            snapshot_query(databasename, outputbucketuri, View, env,accountid=accountid)
            sys.stderr.write(f'\n{View} successful')
                
        else:
            # -------------------------------------------------------
            # Tables that Utilize Partitions of Glue Full Load
            # -------------------------------------------------------
            glue_partition_loads(database_name = databasename,output_bucket_uri = outputbucketuri,View=f'{View}',cview=f'{View}',env=env, accountid=accountid)

    # except ClientError as e:
    #     Exception(f"Failed to upload object {file_path}... {e}")
    # sys.stderr.write("file pushed to s3")

def main(database:str,run:str):
    View = os.environ.get('View')
    Test = os.environ.get('Test_Enabled')
    if os.path.isdir(os.path.join('./Views', f'{View}'))==False:
        raise Exception('Invalid View in input')

    client = boto3.client("sts")
    glue_client = boto3.client("glue")
    account_id = client.get_caller_identity()["Account"]
    
    if account_id == '720968118375':
        env = 'dev'
    elif account_id == '838525369068':
        env = 'uat'
    else:
        env = 'prod'
    if Test=='False':
        database = f'crg_daas_{env}_bamv_db'
    else:
        database = f'crg_daas_{env}_bamv_db_testing'
    try:
        match_dtypes(View=View)
    except:
        pass
    if Test =='True' and run=='/var/task':
        try:
            sys.stderr.write(f"\nAttempting Testing Enviroment")
            clean_up_temp_tables(temp_table_prefix="temp_table_", region_name="ap-southeast-2", env=f'{env}')
            tpmv.push_data_to_s3(View,env,account_id,database=database)
            delete_unlisted_glue_tables(glue_client=glue_client,database_name=database,views_folder_path='./Views')
        except Exception as e:
            sys.stderr.write(f"\nAn error occurred: {e}")
            return  # Exit early to avoid normal run
    elif Test =='False' and run!='/var/task/test_playground':
        sys.stderr.write(f"\nAttempting Main Branch Run")
        clean_up_temp_tables(temp_table_prefix="temp_table_", region_name="ap-southeast-2", env=f'{env}')
        push_data_to_s3(View,env,account_id,database=database)
        delete_unlisted_glue_tables(glue_client=glue_client,database_name=database,views_folder_path='./Views')
    #delete_athena_database(env,f"crg_daas_{env}_bamv_db_testing", "ap-southeast-2")
    
main(database="",run=os.path.dirname(os.path.realpath(__file__)))



