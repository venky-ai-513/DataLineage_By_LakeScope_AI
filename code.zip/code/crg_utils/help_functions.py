import os, psutil
import gc
import re
import boto3
import json
import logging
import datetime
from dask.dataframe import from_pandas
import pandas as pd
from crg_utils import aws
import awswrangler as wr
import subprocess
from dask_sql import Context
import time
from botocore.exceptions import ClientError
import sys
import time
import datetime 

def remove_duplicates(schema):
    seen = set()
    new_schema = []
    for column in schema:
        if column['Name'] not in seen:
            new_schema.append(column)
            seen.add(column['Name'])
    return new_schema
           
def create_parquet_glue_table(database,View,columns, s3_location):
    
    glue_client = boto3.client('glue', region_name='ap-southeast-2')

    table_input = {
        'Name': f'{View}',
        'StorageDescriptor': {
            'Columns': columns,
            'Location': s3_location,
            'InputFormat': 'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat',
            'OutputFormat': 'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat',
            'SerdeInfo': {
                'SerializationLibrary': 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe'
            }
        },
        'TableType': 'EXTERNAL_TABLE',
        'Parameters': {
            'classification': 'parquet'
        }
    }
    
    client = boto3.client("sts")
    glue_client = boto3.client("glue")
    account_id = client.get_caller_identity()["Account"]
    
    if account_id == '720968118375':
        env = 'dev'
    elif account_id == '838525369068':
        env = 'uat'
    else:
        env = 'prod'
    if (wr.catalog.does_table_exist(database=f'crg_daas_{env}_bamv_db', table=f'{View}')==False):
        response = glue_client.create_table(
            DatabaseName=database,
            TableInput=table_input
        )
        response
    elif (os.path.exists(f'Views/{View}/fullload.txt') ==  True)&(wr.catalog.does_table_exist(database=f'crg_daas_{env}_bamv_db', table=f'{View}')==True):
            sys.stderr.write(f"\n File Exists")
    


class GlueTableManager:
    def __init__(self, region: str):
        self.glue_client = boto3.client('glue', region_name=region)

    def read_schema(self, definition_file: str) -> list:
        with open(definition_file, 'r') as file:
            return [{'Name': line.split('\t')[0], 'Type': line.split('\t')[1]} for line in file]

    def create_parquet_table(self, database: str, view: str, columns: list, s3bucket: str):
        create_parquet_glue_table(database, view, columns, s3bucket)

    def get_table(self, database: str, view: str) -> dict:
        try:
            return self.glue_client.get_table(DatabaseName=database, Name=view)
        except self.glue_client.exceptions.EntityNotFoundException:
            return {}

    def update_table(self, database: str, table_input: dict):
        return self.glue_client.update_table(DatabaseName=database, TableInput=table_input)

    def define_table_definition(self, definition: str, view: str, s3bucket: str, env: str):
        # Clean and validate column definitions
        def clean_column_definitions(column_definitions):
            cleaned_columns = []
            for col in column_definitions:
                cleaned_column = {
                    'Name': col['Name'].strip(),
                    'Type': col['Type'].strip().lower()  # Ensure the type is lowercase and has no extra spaces
                }
                cleaned_columns.append(cleaned_column)
            return cleaned_columns
        
        # Read and clean the schema
        column_definitions = self.read_schema(definition)
        column_definitions = clean_column_definitions(column_definitions)
        
        
        
        self.create_parquet_table(f'crg_daas_{env}_bamv_db', view, column_definitions, s3bucket)
        try:
            table = pd.read_csv(f'Views/{view}/fullload.txt', index_col=False, header=0, sep='\t')
            period = table.iloc[0][1].strip()
        except:
            pass

        table_schema = column_definitions
        table_input = {
            'Name': view,
            'StorageDescriptor': {
                'Columns': table_schema,
                'Location': s3bucket,
                'InputFormat': 'org.apache.hadoop.mapred.TextInputFormat',
                'OutputFormat': 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat',
                'SerdeInfo': {'SerializationLibrary': 'org.apache.hadoop.hive.serde2.OpenCSVSerde'}
            },
            'TableType': 'EXTERNAL_TABLE',
            'Parameters': {'classification': 'parquet'}
        }

        current_table1 = self.get_table(f'crg_daas_{env}_bamv_db', view)
        storage_descriptor1 = current_table1.get('Table', {}).get('StorageDescriptor', {})
        current_partition_keys1 = current_table1.get('Table', {}).get('PartitionKeys', [])

        current_table2 = self.get_table(f'crg_daas_{env}_bamv_staging_db', view)
        storage_descriptor2 = current_table2.get('Table', {}).get('StorageDescriptor', {})
        current_partition_keys2 = current_table2.get('Table', {}).get('PartitionKeys', [])

        if storage_descriptor1:
            storage_descriptor1['Columns'] = column_definitions
            storage_descriptor1['Location'] = s3bucket

            updated_table_input1 = {
                'Name': view,
                'StorageDescriptor': storage_descriptor1,
                'TableType': current_table1.get('Table', {}).get('TableType', 'EXTERNAL_TABLE'),
                'Parameters': current_table1.get('Table', {}).get('Parameters', {}),
                'PartitionKeys': current_partition_keys1
            }
            self.update_table(f'crg_daas_{env}_bamv_db', updated_table_input1)

        if storage_descriptor2:
            storage_descriptor2['Columns'] = column_definitions
            updated_table_input2 = {
                'Name': view,
                'StorageDescriptor': storage_descriptor2,
                'TableType': current_table2.get('Table', {}).get('TableType', 'EXTERNAL_TABLE'),
                'Parameters': current_table2.get('Table', {}).get('Parameters', {}),
                'PartitionKeys': current_partition_keys2
            }
            self.update_table(f'crg_daas_{env}_bamv_staging_db', updated_table_input2)



def decimal_conversion(row,  total_digits, decimals):
    def round_to_total_digits(number, total_digits):
        digits_before_decimal = len(str(number).split('.')[0])
        digits_after_decimal = total_digits - digits_before_decimal
        if number is None:
            return None
        elif number is np.nan:
            return '{number:.{digits}f}'.format(number=float(0), digits=int(total_digits))
        else:
            return '{number:.{digits}f}'.format(number=float(number), digits=int(digits_after_decimal))
    def round_to_decimal(value,decimals):
        if value is None:
            return None
        elif value is np.nan:
            return None
        else:
            return '{number:.{digits}f}'.format(number=float(value), digits=int(decimals))
    
    if row is None:
        return row
    else:
        # Apply the second function to the desired column(s)
        row = round_to_decimal(row, decimals)
        row = round_to_total_digits(row, total_digits)
        return row

def extract_precision_scale(string):
    match = re.match(r"decimal\((\d+),(\d+)\)", string)
    if match:
        precision = int(match.group(1))
        scale = int(match.group(2))
        return precision, scale
    else:
        return None
    
def contains_decimal(string):
    return bool(re.search(r'\bdecimal\b', string, flags=re.IGNORECASE))

def chunk_dtype(View, df):
    for y in pd.read_csv(f'Views/{View}/{View}.txt', sep='\t').iterrows():
            for col in df.columns:
                print(y[1][1])
                if contains_decimal(col):  
                    precision, decimal =  extract_precision_scale(y[1][1])
                    try:
                        df[col] = df[col].replace('',np.nan).astype(dtype='float')
                    except:
                        pass
                    df[col] = df[col].apply(decimal_conversion, args=( precision, decimal))
                if col in y[1][0]:
                    df[col] = df[col].astype(y[1][2])
                    

def clean_up_temp_tables(temp_table_prefix="temp_table_", region_name="ap-southeast-2", env="dev"):
    # Initialize Athena client
    athena_client = boto3.client('athena', region_name=region_name)
    
    # Query to list all tables in the database
    list_tables_query = f"SHOW TABLES IN crg_daas_{env}_business_aligned_db"

    try:
        # Start query execution
        response = athena_client.start_query_execution(
            QueryString=list_tables_query,
            QueryExecutionContext={'Database': f'crg_daas_{env}_business_aligned_db'},
            ResultConfiguration={'OutputLocation': f's3://crg-daas-{env}-materialized-views/'}
        )

        # Get the query execution ID
        query_execution_id = response['QueryExecutionId']
        
        # Wait for the query to complete
        query_status = athena_client.get_query_execution(QueryExecutionId=query_execution_id)
        while query_status['QueryExecution']['Status']['State'] not in ['SUCCEEDED', 'FAILED', 'CANCELLED']:
            time.sleep(1)
            query_status = athena_client.get_query_execution(QueryExecutionId=query_execution_id)

        if query_status['QueryExecution']['Status']['State'] == 'SUCCEEDED':
            # Get the query results
            result_response = athena_client.get_query_results(QueryExecutionId=query_execution_id)
            
            # Extract the table names
            table_names = [row['Data'][0]['VarCharValue'] for row in result_response['ResultSet']['Rows'][1:]]
            
            # Identify and drop temporary tables
            for table_name in table_names:
                if table_name.startswith(temp_table_prefix):
                    drop_table_query = f"DROP TABLE crg_daas_{env}_business_aligned_db.{table_name}"
                    athena_client.start_query_execution(
                        QueryString=drop_table_query,
                        QueryExecutionContext={'Database': f'crg_daas_{env}_business_aligned_db'},
                        ResultConfiguration={'OutputLocation': f's3://crg-daas-{env}-materialized-views/'}
                    )
                    sys.stderr.write(f"\nDropped table: {table_name}")
        else:
            sys.stderr.write(f"\nQuery failed with state: {query_status['QueryExecution']['Status']['State']}")
    except Exception as e:
        sys.stderr.write(f"\nAn error occurred: {e}")


def match_dtypes(View:str):
    '''Make sure the SQL Descibe Dtypes are casted as python dtypes'''

    files = folders = 0
    for _, dirnames, filenames in os.walk(f'./Views/{View}'):
        files += len(filenames)
        folders += len(dirnames)
    if folders > 0:
        directory_list = list()
        for root, dirs, files in os.walk(f'./Views/{View}', topdown=False):
            for name in dirs:
                directory_list.append(os.path.join(root, name))
                directory_list
                pythondtype = pd.read_csv('./crg_utils/dtypes.txt', sep='\t',header=0,index_col=False).rename(columns={"SQL type": "dtype","Python type":"pythondtype"})
                if 'py_dtype' not in pd.read_csv(f'Views/{View}/{name}/{name}.txt', sep='\t',header=0).columns:
                    athenadtype = pd.read_csv(f'Views/{View}/{name}/{name}.txt', sep='\t',names=["column","dtype"])
                    athenadtype['py_dtype'] = None
                    for j in range(len(athenadtype)):
                        for k in range(len(pythondtype)):
                            if pythondtype.iloc[k][0] in athenadtype.iloc[j][1]:
                                athenadtype['py_dtype'][j] = pythondtype.iloc[k][1]                
                    athenadtype.to_csv(f'Views/{View}/{name}/{name}.txt', sep="\t",index=False)
                if 'py_dtype' not in pd.read_csv(f'Views/{View}/{View}.txt', sep='\t',header=0).columns:
                    athenadtype = pd.read_csv(f'Views/{View}/{View}.txt', sep='\t',header=0,index_col=False,names=["column","dtype"])
                    athenadtype['py_dtype'] = None
                    for j in range(len(athenadtype)):
                        for k in range(len(pythondtype)):
                            if pythondtype.iloc[k][0] in athenadtype.iloc[j][1]:
                                athenadtype['py_dtype'][j] = pythondtype.iloc[k][1]
                    athenadtype.to_csv(f'./Views/{View}/{View}.txt', sep="\t",index=False)               
        else:
            pythondtype = pd.read_csv('./crg_utils/dtypes.txt', sep='\t',header=0,index_col=False).rename(columns={"SQL type": "dtype","Python type":"pythondtype"})
            if 'py_dtype' not in pd.read_csv(f'Views/{View}/{View}.txt', sep='\t',header=0).columns:
                athenadtype = pd.read_csv(f'Views/{View}/{View}.txt', sep='\t',header=False)
                athenadtype['py_dtype'] = None
                for j in range(len(athenadtype)):
                    for k in range(len(pythondtype)):
                        if pythondtype.iloc[k][0] in athenadtype.iloc[j][1]:
                            athenadtype['py_dtype'][j] = pythondtype.iloc[k][1]
                athenadtype.to_csv(f'./Views/{View}/{View}.txt', sep="\t",index=False)
    gc.collect()  

class AthenaMaterializer:
    def __init__(self, athena_output_location):
        """
        Initializes the AthenaMaterializer class.
        
        Args:
            athena_output_location (str): S3 location where Athena query results will be stored.
        """
        self.athena_client = boto3.client('athena')
        self.glue_client = boto3.client('glue')
        self.athena_output_location = athena_output_location

    def get_view_schema(self, database, view_name):
        """
        Retrieves the schema of a specified view from the Glue Data Catalog.

        Args:
            database (str): The name of the source database.
            view_name (str): The name of the view or table to retrieve the schema from.

        Returns:
            List of tuples: A list of (column_name, data_type) tuples.
        """
        try:
            sys.stderr.write(f"\n response start")
            if not view_name.endswith('_view'):
                view_name += '_view'
            # Retrieve table metadata from Glue Data Catalog
            response = self.glue_client.get_table(DatabaseName=database, Name=view_name)
            sys.stderr.write(f"\n response end")
            # Extract column definitions
            columns = response['Table']['StorageDescriptor']['Columns']

            # Include partition columns if they exist
            if 'PartitionKeys' in response['Table']:
                columns.extend(response['Table']['PartitionKeys'])

            # Extract column names and types
            column_schema = [(col['Name'], col['Type']) for col in columns]
            
            sys.stderr.write(f"\nSchema for {view_name} retrieved successfully.")
            return column_schema
        except self.glue_client.exceptions.EntityNotFoundException as e:
            sys.stderr.write(f"\nError: Table {view_name} not found in database {database}. {e}")
        except Exception as e:
            sys.stderr.write(f"\nAn error occurred while retrieving schema: {e}")

        return []  # Return an empty list if the schema could not be retrieved

    def check_table_exists(self, database, table_name):
        """
        Checks if a table exists in the given Glue database.
        
        Args:
            database (str): The name of the target database.
            table_name (str): The name of the table to check for existence.
        
        Returns:
            bool: True if the table exists, False otherwise.
        """
        try:
            self.glue_client.get_table(DatabaseName=database, Name=table_name)
            return True
        except self.glue_client.exceptions.EntityNotFoundException:
            return False

    def create_table(self, source_db, target_db, view_name, table_name):
        """
        Creates a materialized table in the target database with the schema of the specified view.
        
        Args:
            source_db (str): The name of the source database containing the view.
            target_db (str): The name of the target database where the table will be created.
            view_name (str): The name of the view to materialize.
            table_name (str): The name of the materialized table to create.
        """
        schema = self.get_view_schema(source_db, view_name)
        column_definitions = ', '.join([f"{col[0]} {col[1]}" for col in schema])
        create_table_query = f"""
        CREATE TABLE {target_db}.{table_name} AS 
        SELECT * FROM {source_db}.{view_name};
        """
        response = self.athena_client.start_query_execution(
            QueryString=create_table_query,
            QueryExecutionContext={'Database': target_db},
            ResultConfiguration={'OutputLocation': self.athena_output_location}
        )
        query_execution_id = response['QueryExecutionId']
        self.athena_client.get_waiter('query_succeeded').wait(QueryExecutionId=query_execution_id)
        sys.stderr.write(f"\nTable {table_name} created successfully in {target_db}.")

    def read_schema_from_file(view_name):
        """
        Reads schema from the text file located in ./Views/{View}/{View}.txt.

        Args:
            view_name (str): The name of the view.

        Returns:
            list: A list of tuples representing column names and their types.
        """
        schema_file = f'./Views/{view_name}/{view_name}.txt'
        if os.path.exists(schema_file):
            schema = []
            with open(schema_file, 'r') as file:
                for line in file:
                    name, col_type = line.strip().split('\t')
                    schema.append((name, col_type))
            return schema
        else:
            return None

    def update_table(self, source_db, target_db, view_name, table_name):
        """
        Updates an existing materialized table by fetching the schema of the view
        or reading from a schema text file, and updating the Glue table schema.

        Args:
            source_db (str): The name of the source database containing the view.
            target_db (str): The name of the target database where the table is located.
            view_name (str): The name of the view to materialize.
            table_name (str): The name of the table to update.
        """
        # Check if a schema file exists for the view
        schema = self.read_schema_from_file(view_name)

        # If no file schema exists, retrieve schema from the view
        if schema is None:
            schema = self.get_view_schema(source_db, view_name)

        # Fetch the current Glue table definition
        try:
            table_definition = self.glue_client.get_table(DatabaseName=target_db, Name=table_name)
            existing_columns = table_definition['Table']['StorageDescriptor']['Columns']
        except self.glue_client.exceptions.EntityNotFoundException:
            sys.stderr.write(f"\nTable {table_name} does not exist in {target_db}.")
            return
        except Exception as e:
            sys.stderr.write(f"\nError fetching table {table_name} in {target_db}: {e}")
            return

        # Extract new columns and map them to the Glue format
        glue_columns = [{'Name': col[0], 'Type': col[1]} for col in schema]

        # Check if there are differences between the existing and new columns
        if existing_columns != glue_columns:
            # Update Glue table schema
            try:
                response = self.glue_client.update_table(
                    DatabaseName=target_db,
                    TableInput={
                        'Name': table_name,
                        'StorageDescriptor': {
                            'Columns': glue_columns,
                            'Location': table_definition['Table']['StorageDescriptor']['Location'],
                            'InputFormat': table_definition['Table']['StorageDescriptor']['InputFormat'],
                            'OutputFormat': table_definition['Table']['StorageDescriptor']['OutputFormat'],
                            'SerdeInfo': table_definition['Table']['StorageDescriptor']['SerdeInfo'],
                            # Add other StorageDescriptor properties as needed
                        },
                        'TableType': table_definition['Table'].get('TableType', 'EXTERNAL_TABLE'),
                        'Parameters': table_definition['Table'].get('Parameters', {}),
                    }
                )
                sys.stderr.write(f"\nTable {table_name} schema updated successfully in {target_db}.")
            except Exception as e:
                sys.stderr.write(f"\nError updating Glue table {table_name} in {target_db}: {e}")
        else:
            sys.stderr.write(f"\nNo schema changes detected for {table_name} in {target_db}.")

    def materialize_view(self, source_db, target_db, view_name, table_name):
        sys.stderr.write(f"\nIn Materialized View Function.")
        """
        Creates or updates a materialized table in the target database based on a view from the source database.
        
        Args:
            source_db (str): The name of the source database containing the view.
            target_db (str): The name of the target database where the table will be created or updated.
            view_name (str): The name of the view to materialize.
            table_name (str): The name of the materialized table to create or update.
        """
        if not self.check_table_exists(target_db, table_name):
            self.create_table(source_db, target_db, view_name, table_name)
        else:
            self.update_table(source_db, target_db, view_name, table_name) 
               
def platform_query(database_name, output_bucket_uri, View, env,account_id):
    df = pd.DataFrame(aws.run_query_in_athena(db_name=database_name,
                            query=open((f'Views/{View}/{View}.sql'), "r").read().replace('{env}',env),
                            output_bucket=output_bucket_uri)).to_parquet(f'/{View}.parquet',engine='pyarrow')
    try:
        for y in pd.read_csv(f'Views/{View}/{View}.txt', sep='\t').iterrows():
            for col in df.columns:
                if col in [y[1][0]]:
                    df[col] = df[col].astype(y[1][2])
    except:
        sys.stderr.write(f'\n')

def snapshot_query(database_name, output_bucket_uri, View, env,accountid):
    manager = GlueTableManager(region='ap-southeast-2')
    manager.define_table_definition(definition=f'Views/{View}/{View}.txt',view=f'{View}',s3bucket=f"s3://crg-daas-{env}-ap-southeast-2-{accountid}-snapshot/datasets/bamv/{View}/",env=f'{env}')  
    df = pd.DataFrame(aws.run_query_in_athena(db_name=database_name,
                            query=open((f'Views/{View}/{View}.sql'), "r").read().replace('{env}',env),
                            output_bucket=output_bucket_uri)).to_parquet(f'/{View}.parquet',engine='pyarrow')
    print(df)
    now = datetime.datetime.utcnow()
    bucket = f"crg-daas-{env}-ap-southeast-2-{accountid}-snapshot"
    try:
        for y in pd.read_csv(f'Views/{View}/{View}.txt', sep='\t').iterrows():
            for col in df.columns:
                if col in [y[1][0]]:
                    df[col] = df[col].astype(y[1][2])
    except:
        sys.stderr.write(f'\n')
    s3 = boto3.client('s3')
    lists = f'datasets/bamv/{View}/'
    files = []

    try:
        paginator = s3.get_paginator('list_objects_v2')
        page_iterator = paginator.paginate(Bucket=f"crg-daas-{env}-ap-southeast-2-{accountid}-snapshot", Prefix=lists)

        for page in page_iterator:
            if 'Contents' in page:
                for item in page['Contents']:
                    sys.stderr.write(f"{item['Key']} exists in bucket\n")
                    files.append(item['Key'])
    except Exception as e:
        sys.stderr.write(f"\nError listing files in bucket crg-daas-{env}-ap-southeast-2-{accountid}-bamv-raw: {e}")

    for file in files:
        try:
            s3.delete_object(Bucket=f"crg-daas-{env}-ap-southeast-2-{accountid}-snapshot", Key=file)
            sys.stderr.write(f"deleted {file}\n")
        except Exception as e:
            sys.stderr.write(f"\nError deleting file {file}: {e}")
    file_path = f"datasets/bamv/{View}/snapshots/{now.strftime('%Y%m%d%H%M%S')}.parquet"
    _ = aws.put_object_to_s3(df=pd.read_parquet(f'/{View}.parquet',engine='pyarrow'),
                                        bucket_name=bucket,
                                        key=file_path)
      
def daskchildquery(database_name, output_bucket_uri, View, cview, env):
    # -------------------------------------------------------
    # Dask Child Query Load
    # -------------------------------------------------------
    df = pd.DataFrame(aws.run_query_in_athena(db_name=database_name,
                            query=open((f'Views/{View}/{cview}/{cview}.sql'), "r").read().replace('{env}',env),
                            output_bucket=output_bucket_uri)).to_parquet(f'/{View}-{cview}.parquet',engine='pyarrow')
    sys.stderr.write(f'\n/{View}-{cview}.parquet'+' exported')
    try:
        for y in pd.read_csv(f'Views/{View}/{cview}/{cview}.txt', sep='\t').iterrows():
            for col in df.columns:
                if col in [y[1][0]]:
                    df[col] = df[col].astype(y[1][2])
    except:
        sys.stderr.write(f'\n')

def daskquery(databasename: str,outputbucketuri: str,View: str, env: str):
    c = Context()
    directory_list = list()
    s3 = boto3.client('s3')
    client = boto3.client("sts")
    accountid = client.get_caller_identity()["Account"]
    lists = f'datasets/bamv/{View}/'
    files = []
    try:
        paginator = s3.get_paginator('list_objects_v2')
        page_iterator = paginator.paginate(Bucket=f"crg-daas-{env}-ap-southeast-2-{accountid}-snapshot", Prefix=lists)

        for page in page_iterator:
            if 'Contents' in page:
                for item in page['Contents']:
                    sys.stderr.write(f"{item['Key']} exists in bucket\n")
                    files.append(item['Key'])
    except Exception as e:
        sys.stderr.write(f"\nError listing files in bucket crg-daas-{env}-ap-southeast-2-{accountid}-bamv-raw: {e}")

    for file in files:
        try:
            s3.delete_object(Bucket=f"crg-daas-{env}-ap-southeast-2-{accountid}-snapshot", Key=file)
            sys.stderr.write(f"deleted {file}\n")
        except Exception as e:
            sys.stderr.write(f"\nError deleting file {file}: {e}")
    files = folders = 0
    for _, dirnames, filenames in os.walk(f'./Views/{View}'):
        files += len(filenames)
        folders += len(dirnames)
        if folders > 0:
            print(files)
            for root, dirs, files in os.walk(f'./Views/{View}', topdown=False):
                for name in dirs:
                    print(name)
                    directory_list.append(os.path.join(root, name))
                    daskchildquery(databasename, outputbucketuri, View, name, env)
                    c.create_table(f'{name}',pd.read_parquet(f'/{View}-{name}.parquet',engine='pyarrow'))
                    sys.stderr.write(f'\n{name} created successfully')
            ddf = c.sql(open((f'Views/{View}/{View}.sql'), "r").read())
            sys.stderr.write(f'\ndask dataframe created succesfully')
        return ddf

def partion_and_filters(database_name, output_bucket_uri, View, cview, env, accountid: str):
    table = pd.read_csv(f'Views/{View}/fullload.txt',index_col=False,header=0,sep='\t')
    period = table.iloc[0][1].strip()
    sys.stderr.write(f'\nperiod:{period}')
    sys.stderr.write(f'\ncview:{cview}')
    if (os.path.exists(f'Views/{View}/fullload.txt') ==  True)&(wr.catalog.does_table_exist(database=f'crg_daas_{env}_bamv_db', table=f'{cview}')==False):
        date1 = table.iloc[0][0].strip()
        date1 = f'"{date1}"'
        sys.stderr.write(f'\nfirst iteration of partitioned loading')
    elif (os.path.exists(f'Views/{View}/fullload.txt') ==  True)&(wr.catalog.does_table_exist(database=f'crg_daas_{env}_bamv_db', table=f'{cview}')==True):
        if (period == 'fullload')|(period == 'yearload'):
            date1 = table.iloc[0][0].strip()
            date1 = f'"{date1}"'
        else:
            date1 = table.iloc[0][0].strip()
            date1 = f'"{date1}"'
        sys.stderr.write(f'\nsecond iteration of partitioned loading')
    now = datetime.datetime.utcnow() 
    sys.stderr.write('first iteration of partitioned loading')
    bucket = f"crg-daas-{env}-ap-southeast-2-{accountid}-bamv-raw"
    s3 = boto3.client('s3')
    if (period != 'yearmonth')&(period != 'yearmonthhalf')&(period != 'yearload')&(period != 'fullload')&(period != 'monthload'):
        partitions = pd.DataFrame(aws.run_query_in_athena(db_name=database_name,
                        query=f"select distinct {period}"+f'({date1}) as '+f" {period}_date "+ "from"+f' "crg_daas_{env}_business_aligned_db"'+f"."+f'"{cview}_view"',
                        output_bucket=output_bucket_uri))
        filter = '\n where {period}'+'({date1}) = '+"{part}"
    elif (period == 'fullload'):
        partitions = pd.DataFrame([0])
        filter = ''
    elif (period == 'yearmonthhalf'):
        partitions = pd.DataFrame(aws.run_query_in_athena(db_name=database_name,
                        query=f'''select distinct CONCAT(cast(YEAR("{date1}") as varchar), 
                                        LPAD(cast(MONTH("{date1}") as varchar), 2, '0'), 
                                        CASE
                                            WHEN DAY("{date1}") <= 15 THEN 'a'
                                            ELSE 'b'
                                        END) as '''+f"{period}_date "+ "from"+f" crg_daas_{env}_business_aligned_db"+f"."+f'"{cview}_view"',
                        output_bucket=output_bucket_uri))
        filter = '''\nwhere CONCAT(cast(YEAR({date1}) as varchar), 
                    LPAD(cast(MONTH("{date1}") as varchar), 2, '0'), 
                    CASE
                        WHEN DAY({date1}) <= 15 THEN 'a'
                        ELSE 'b'
                    END) = '''+"'{part}'"
    elif (period == 'yearmonth'):
        sys.stderr.write(f"\n Executing the correct step\n")
        ##FULL LOAD IF NEEDED
        if f'{View}'=='fieloeepoint_v':
            partitions = pd.DataFrame(aws.run_query_in_athena(db_name=database_name,
                            query=f'''select distinct date_format("timestamp", '%Y%m') as'''+f' "{period}_date" '+"from"+f" crg_daas_{env}_salesforce_db"+f"."+f'"{View}"',
                            output_bucket=output_bucket_uri))
            print('salesforce partitions aql :',partitions)
        else:
            partitions = pd.DataFrame(aws.run_query_in_athena(db_name=database_name,
                            query=f'''select distinct date_format("Sale Date", '%Y%m') as'''+f' "{period}_date" '+"from"+f" crg_daas_{env}_business_aligned_db"+f"."+f'"{View}"',
                            output_bucket=output_bucket_uri))            

        ##----------
        ## Ongoing Load month , prev_month
        ##-------
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        # Calculate the previous month and year
        if month == 1:
            previous_month = 12
            previous_year = year - 1
        else:
            previous_month = month - 1
            previous_year = year

        # Format year_month and previous_year_month strings
        year_month = f"{year}{str(month).zfill(2)}"
        previous_year_month = f"{previous_year}{str(previous_month).zfill(2)}"

        print(f"Current Year-Month: {year_month}")
        print(f"Previous Year-Month: {previous_year_month}")

        if f'{View}'!='fieloeepoint_v': # This consition shoul be enabled only for full load
            partitions = pd.DataFrame([year_month, previous_year_month])
        ##----------
        ## Filter
        ##---------
        filter = '''\n where date_format({date1}, '%Y%m') = '''+"'{part}'"
    elif (period == 'monthload'):
        query=f"select distinct month"+f'({date1}) as '+f"{period}_date "+ "from"+f" crg_daas_{env}_business_aligned_db"+f"."+f'"{View}"'
        print(query)
        now = datetime.datetime.now()
        year = now.year
        month = now.month

        # Calculate the previous month and year
        if month == 1:
            previous_month = 12
            previous_year = year - 1
        else:
            previous_month = month - 1
            previous_year = year

        months = [((month - i - 1) % 12) + 1 for i in range(3)]
        partitions = pd.DataFrame(months)
        #partitions = pd.DataFrame([11, 12, 1, 2,3,4,5,6,7,8,9,10])


        filter = '\n where month'+'({date1}) = '+"{part}"
            #except:
            #    break  # Exit the loop if partitions is not empty
    elif (period == 'yearload'):
        partitions = pd.DataFrame()
        while partitions.empty:
            try:
                if f'{View}' == 'crg_store_inventory_view':
                    date1 = table.iloc[0][0].strip()
                    now = datetime.datetime.now()
                    month = now.month
                    partitions = pd.DataFrame([1,2,3,4,5,6,7,8,9,10,11,12])
                    print(partitions)
                elif f'{View}' == 'crg_op_sales_view_os':
                    sys.stderr.write('in loop')
                    date1 = table.iloc[0][0].strip()
                    date1 = f'"{date1}"'
                    now = datetime.datetime.now()
                    year = now.year
                    partitions = pd.DataFrame([1,2,3,4,5,6,7,8,9,10,11,12])
                    print(partitions)
                elif f'{View}' == 'crg_sales_detail':
                    now = datetime.datetime.now()
                    year = now.year
                    partitions = pd.DataFrame([year,year-1,year-2])
                    print(partitions)
                elif f'{View}'=='crg_op_sales_type':
                    now = datetime.datetime.now()
                    month = now.month
                    partitions = pd.DataFrame([month])
                    print(partitions)
                elif f'{View}'=='crg_ostv_sales_by_week':
                    now = datetime.datetime.now()
                    month = now.month
                    partitions = pd.DataFrame([month])
                    print(partitions)
                elif View =='crg_full_wh_inventory_view':
                    now = datetime.datetime.now()
                    year = now.year
                    partitions = pd.DataFrame([year,year-1,year-2, year-3])
                    print(partitions)
                else:
                    partitions = pd.DataFrame(aws.run_query_in_athena(db_name=database_name,
                            query=f"select distinct year"+f'({date1}) as '+f"{period}_date "+ "from"+f" crg_daas_{env}_business_aligned_db"+f"."+f'"{cview}_view"',
                            output_bucket=output_bucket_uri))
                
            except:
                break  # Exit the loop if partitions is not empty
                
            
        #partitions = partitions.sort_values(by=f"{period}_date", ascending=False).head(3)
        #print(sorted_partitions)
        if len(partitions) == 0:
            raise Exception("Query did not return any partitions after 5 attempts")
        if (f'{View}' == 'crg_store_inventory_view')|(f'{View}' == 'crg_op_sales_type')|(f'{View}' == 'crg_op_sales_view_os')|(f'{View}' == 'crg_ostv_sales_by_week')|(f'{View}' == 'crg_op_sales_type'):
            filter = ''
        else:
            filter = '\n where year'+'({date1}) = '+"{part}"
    else:
        filter = '\n where {period}'+'({date1}) = '+"{part}"
    return table,date1,period,now,partitions,filter


def ecs_function(database_name, output_bucket_uri, View, env, bucket, date1, period, now, partitions, file, i):
    client = boto3.client("sts")
    accountid = client.get_caller_identity()["Account"]
    manager = GlueTableManager(region='ap-southeast-2')
    query = file.read().replace('{env}', env).replace('{part}',f'{partitions.iloc[i,0]}').replace('{date1}',date1).replace('{period}', period)
    print(query)
    sys.stderr.write(f'\nload + {i}')
    for j,chunk in enumerate(wr.athena.read_sql_query(sql=query, database=database_name, s3_output=output_bucket_uri,chunksize=True)):
        s3bucket = f"s3://{bucket}/datasets/bamv/{View}/" 
        manager.define_table_definition(definition=f'Views/{View}/{View}.txt',view=f'{View}',s3bucket=f"s3://crg-daas-{env}-ap-southeast-2-{accountid}-snapshot/datasets/bamv/{View}/" ,env=f'{env}')
        file_path = f"s3://{bucket}/datasets/bamv/{View}/fullload/{period} {partitions.iloc[i,0]}/chunk {j}/{now.strftime('%Y%m%d%H%M%S')}.parquet" 
        s3 = boto3.client('s3')
        bucket_name = bucket
        path = f'datasets/bamv/{View}/fullload/{period} {partitions.iloc[i,0]}/chunk {j}/'
                            # List objects in the specified path
        response = s3.list_objects_v2(Bucket=bucket_name, Prefix=path)
                            
                            # Check if any objects were found
        if 'Contents' in response:
            sys.stderr.write(f'\nFiles exist in the specified path. for {file_path}')
            sys.stderr.write(f"\nFiles exist in the specified path.")
                                # Print the list of object keys (i.e., file names)
            for obj in response['Contents']:
                print(obj['Key'])
            sys.stderr.write(f'\nexecuting reload of the specified path. for {file_path}')
            df = chunk
            chunk_dtype(View, df)
        lists = f'datasets/bamv/{View}/fullload/{period} {partitions.iloc[i,0]}/chunk {j}/'
        files = []
        try:
                                # List all files in the specified bucket
            response = s3.list_objects_v2(Bucket=bucket,Prefix=lists)
            if 'Contents' in response:
                for item in response['Contents']:
                    print(item['Key'])
                    files.append(item['Key'])
        except Exception as e:
            sys.stderr.write(f"\nError listing files in bucket {bucket_name}: {e}")
        for file in files:
            print(file)
            s3.delete_object(Bucket=bucket_name, Key=file)
            sys.stderr.write(f'\nfiles found in the specified path. {file}')
        df = chunk
        chunk_dtype(View,df)
        wr.s3.to_parquet(df=chunk, path=file_path)
            
def glue_function(View, env, accountid, bucket, date1, partitions, file, i):
    manager = GlueTableManager(region='ap-southeast-2')
    query = file.read().replace('{env}', env).replace('{date1}',date1).replace('{part}',f'{partitions.iloc[i,0]}')
    sys.stderr.write(f'\nfull load') 
    bucket_name = bucket
    s3bucket = f"s3://crg-daas-{env}-ap-southeast-2-{accountid}-snapshot/datasets/bamv/{View}/" 
    athena_result_bucket = f"s3://crg-daas-{env}-ap-southeast-2-{accountid}-bamv-raw/datasets/bamv/{View}_csv/{partitions.iloc[i,0]}"
    try:    
        manager.define_table_definition(definition=f'Views/{View}/{View}.txt',view=f'{View}',s3bucket=f'{s3bucket}',env=f'{env}')  
    except:
        pass
    client = boto3.client('athena', region_name='ap-southeast-2')
    s3 = boto3.client('s3')
    lists = f'datasets/bamv/{View}_csv/{partitions.iloc[i,0]}/'
    files = []

    try:
        paginator = s3.get_paginator('list_objects_v2')
        page_iterator = paginator.paginate(Bucket=f"crg-daas-{env}-ap-southeast-2-{accountid}-bamv-raw", Prefix=lists)

        for page in page_iterator:
            if 'Contents' in page:
                for item in page['Contents']:
                    sys.stderr.write(f"{item['Key']} exists in bucket\n")
                    files.append(item['Key'])
    except Exception as e:
        sys.stderr.write(f"\nError listing files in bucket crg-daas-{env}-ap-southeast-2-{accountid}-bamv-raw: {e}")

    for file in files:
        try:
            s3.delete_object(Bucket=f"crg-daas-{env}-ap-southeast-2-{accountid}-bamv-raw", Key=file)
            sys.stderr.write(f"deleted {file}\n")
        except Exception as e:
            sys.stderr.write(f"\nError deleting file {file}: {e}")
    attempts = 0
    max_attempts = 30
    while attempts < max_attempts:
        sys.stderr.write(f"Attempt {attempts + 1}: DataFrame is empty. Waiting for data...")
        try:
            response = client.start_query_execution(
                                    QueryString=query,
                                    QueryExecutionContext={
                                        'Database': f'crg-daas-{env}-bamv-db'
                                    },
                                    ResultConfiguration={
                                        'OutputLocation': athena_result_bucket,
                                    }
                                )
        except Exception as e:
            sys.stderr.write(f"\nError querying data: {e}")
        sys.stderr.write(f'\nUploaded {partitions.iloc[i,0]}')
        query_execution_id=response["QueryExecutionId"]
        query_status = client.get_query_execution(QueryExecutionId=query_execution_id)
        query_state = query_status['QueryExecution']['Status']['State']
        # Monitor query status
        while True:
            query_status = client.get_query_execution(QueryExecutionId=query_execution_id)
            query_state = query_status['QueryExecution']['Status']['State']
            sys.stderr.write(f'\nQuery State: For Value {partitions.iloc[i,0]} {query_state}\n')

            if query_state in ['QUEUED', 'RUNNING']:
                time.sleep(10)
            else:
                break

        if query_state == 'SUCCEEDED':
            result_output_location = query_status['QueryExecution']['ResultConfiguration']['OutputLocation']
            sys.stderr.write(f"\nQuery Successful for Value {partitions.iloc[i, 0]}. Output location {result_output_location}")
            break # Exit out of loop
        elif query_state in ['FAILED', 'CANCELLED']:
            query_state = query_status['QueryExecution']['Status']['State']
            sys.stderr.write(f"Failed to execute on attempt {attempts + 1}")
        elif attempts ==30:
            break
        attempts += 1

    if query_state == 'SUCCEEDED':
        sys.stderr.write(f"\n{View} with f'{partitions.iloc[i,0]}' partition now has data:")
    else:
        sys.exit(f"No data after 5 attempts. for {View} Value {partitions.iloc[i, 0]}")

    s3 = boto3.client('s3')
    lists = f'datasets/bamv/{View}/'
    files = []

    try:
        paginator = s3.get_paginator('list_objects_v2')
        page_iterator = paginator.paginate(Bucket=f"crg-daas-{env}-ap-southeast-2-{accountid}-snapshot", Prefix=lists)
        version_list = []
        for page in page_iterator:
            if 'Contents' in page:
                for item in page['Contents']:
                    sys.stderr.write(f"{item['Key']} exists in bucket\n")
                    files.append(item['Key'])
        for object_response_itr in page_iterator:
            if 'Versions' in object_response_itr:
                for version in object_response_itr['Versions']:
                    version_list.append({'Key': version['Key'], 'VersionId': version['VersionId']})
        sys.stderr.write(version_list)
    except Exception as e:
        sys.stderr.write(f"\nError listing files in bucket crg-daas-{env}-ap-southeast-2-{accountid}-snapshot: {e}")

    for file in files:
        try:
            s3.delete_object(Bucket=f"crg-daas-{env}-ap-southeast-2-{accountid}-snapshot", Key=file)
            sys.stderr.write(f"deleted {file}\n")
        except Exception as e:
            sys.stderr.write(f"\nError deleting file {file}: {e}")
    for version in version_list:
        try:
            response = s3.delete_objects(
                    Bucket="crg-daas-{env}-ap-southeast-2-{accountid}-snapshot",
                    Delete={
                        'Objects': version,
                        'Quiet': True
                    }
                )
            sys.stderr.write(f"deleted version in s3 {version}\n")
        except Exception as e:
            sys.stderr.write(f"Error deleting file {file}: {e}\n")
            
def delete_unlisted_glue_tables(glue_client, database_name, views_folder_path):
    """
    Deletes tables from the specified Glue database that are not present in the Views folder.

    Parameters:
        glue_client (boto3.client): The boto3 Glue client.
        database_name (str): The name of the Glue database.
        views_folder_path (str): The path to the Views folder containing valid table names as subdirectories.
    """
    # Step 1: List all tables in the specified Glue database
    glue_tables = []
    paginator = glue_client.get_paginator('get_tables')
    for page in paginator.paginate(DatabaseName=database_name):
        glue_tables.extend(page['TableList'])

    glue_table_names = {table['Name'] for table in glue_tables}
    
    # Step 2: List all directories in the Views folder
    valid_table_names = {name for name in os.listdir(views_folder_path) if os.path.isdir(os.path.join(views_folder_path, name))}

    # Step 3: Find tables in Glue that are not in the Views folder
    tables_to_delete = glue_table_names - valid_table_names

    # Step 4: Delete the tables from Glue that are not in the Views folder
    for table_name in tables_to_delete:
        sys.stderr.write(f"\nDeleting table: {table_name}")
        glue_client.delete_table(DatabaseName=database_name, Name=table_name)
    
    sys.stderr.write(f"\nDeleted {len(tables_to_delete)} tables that were not present in the Views folder.\n")
    
def delete_athena_database(env,database_name, region_name):
    """
    Deletes an Athena database by running a DROP DATABASE query.
    :param database_name: Name of the Athena database to delete.
    :param region_name: AWS region where Athena is hosted.
    """
    # Initialize Athena client
    athena_client = boto3.client('athena', region_name=region_name)
    query = f"DROP DATABASE `{database_name}` CASCADE"

    try:
        # Start query execution
        response = athena_client.start_query_execution(
            QueryString=query,
            QueryExecutionContext={
                'Database': database_name  # Can use a different database for queries
            },
            ResultConfiguration={
                'OutputLocation': f's3://crg-daas-{env}-materialized-views/'
            }
        )
        query_execution_id = response['QueryExecutionId']
        print(f"Query Execution ID: {query_execution_id}")
        
        # Wait for the query to complete
        status = 'RUNNING'
        while status in ['QUEUED', 'RUNNING']:
            response = athena_client.get_query_execution(QueryExecutionId=query_execution_id)
            status = response['QueryExecution']['Status']['State']
            if status in ['FAILED', 'CANCELLED']:
                raise Exception(f"Query failed or was cancelled: {response['QueryExecution']['Status']['StateChangeReason']}")
            print(f"Query status: {status}")

        if status == 'SUCCEEDED':
            print(f"Database '{database_name}' deleted successfully.")
    except ClientError as e:
        print(f"Failed to delete database '{database_name}': {e}")
    
