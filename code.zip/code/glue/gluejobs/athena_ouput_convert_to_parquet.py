import sys
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from awsglue.context import GlueContext
from awsglue.job import Job
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, IntegerType, DoubleType, DecimalType, DateType, ShortType,TimestampType
import boto3
import configparser
import traceback
import re

def get_data_type(data_type_str):
    if data_type_str.startswith('DecimalType'):
        match = re.match(r"DecimalType\((\d+),\s*(\d+)\)", data_type_str)
        if match:
            precision = int(match.group(1))
            scale = int(match.group(2))
            return DecimalType(precision, scale)
        else:
            raise ValueError(f"Invalid DecimalType format: {data_type_str}")
    elif data_type_str == 'StringType':
        return StringType()
    elif data_type_str == 'IntegerType':
        return IntegerType()
    elif data_type_str == 'DoubleType':
        return DoubleType()
    elif data_type_str == 'ShortType':
        return ShortType()
    elif data_type_str == 'DateType':
        return DateType()
    elif data_type_str == 'TimestampType':
        return TimestampType()
    else:
        raise ValueError(f"Unsupported data type: {data_type_str}")

def main():
    try:    
        # Get job arguments
        args = getResolvedOptions(sys.argv, ['JOB_NAME', 'VIEW','SOURCE_BUCKET', 'SOURCE_PATH', 'TARGET_BUCKET', 'TARGET_PATH', 'config_file_name'])

        # Initialize Spark and Glue contexts
        sc = SparkContext.getOrCreate()
        glueContext = GlueContext(sc)
        spark = glueContext.spark_session
        job = Job(glueContext)
        job.init(args['JOB_NAME'], args)

        # Source and Target details
        source_bucket = args['SOURCE_BUCKET']
        source_path = args['SOURCE_PATH']
        target_bucket = args['TARGET_BUCKET']
        target_path = args['TARGET_PATH']
        config_file_name = args['config_file_name']
        view_name = args['VIEW']

        print('source_bucket :', source_bucket)
        print('source_path :', source_path)
        print('target_bucket :', target_bucket)
        print('target_path :', target_path)
        print('config_file_name :', config_file_name)
        print('view_name :', view_name)

        print("-----------Reading config file {} ---------".format(config_file_name))
        config = configparser.ConfigParser()
        config.read(config_file_name)

        print("Available sections in config:", config.sections())
        if view_name in config.sections():
            print(f"Items in section '{view_name}':")
            for key, value in config.items(view_name):
                print(f"  {key} = {value}")
        else:
            print(f"ERROR: Section '{view_name}' not found in config file!")
            print("Available sections:", list(config.sections()))
            raise Exception(f"View '{view_name}' not found in config file")

        # Construct the schema from the config file
        schema = StructType()
        for column, data_type_str in config.items(view_name):
            print(f"Column: {column}, Data Type: {data_type_str}")
            data_type = get_data_type(data_type_str)
            schema.add(StructField(column, data_type, True))
        print("----------- Schema constructed from .ini file -----------")
        print(schema)

        # Construct the S3 path for CSV files
        csv_file_path = f"s3://{source_bucket}/{source_path}"
        print('csv_file_path:', csv_file_path)

        # Debugging: List files in the S3 path
        s3_client = boto3.client('s3')
        response = s3_client.list_objects_v2(Bucket=source_bucket, Prefix=source_path)

        # Filter objects to get only .csv files
        # csv_objects = [obj['Key'] for obj in response.get('Contents', []) if obj['Key'].endswith('.csv')]

        csv_objects = [f"s3://{source_bucket}/{obj['Key']}" for obj in response.get('Contents', []) if obj['Key'].endswith('.csv')]
        print('csv_objects :',csv_objects)

        # Print the list of .csv files found
        for csv_file in csv_objects:
            print("CSV file found:", csv_file)

        if 'Contents' in response:
            print("Files in the source path:")
            for obj in response['Contents']:
                print(obj['Key'])
        else:
            print("No files found in the source path")

        # Check if the path is correct and files are available
        if 'Contents' not in response or len(response['Contents']) == 0:
            raise Exception(f"No files found in the specified S3 path: {csv_file_path}")

        print ("response[Contents] :", response['Contents'])

        # Read and print each CSV file to ensure data is being read correctly
        for csv_file in csv_objects:
            print(f"Reading file: {csv_file}")
            temp_df = spark.read.csv(csv_file, header=True, schema=schema)
            temp_df.show(5)  # Show a sample of the data read

            if temp_df.count() == 0:
                print(f"Warning: {csv_file} is empty or could not be read correctly.")
            else:
                # Combine data frames if not empty 
                if 'pyspark_df' not in locals():
                    pyspark_df = temp_df
                else:
                    pyspark_df = pyspark_df.union(temp_df)

        # Print schema and a few rows of the DataFrame to ensure data is read correctly 
        pyspark_df.printSchema()
        pyspark_df.show(5)

        # Write PySpark DataFrame to a Parquet file in S3
        parquet_file_path = f"s3://{target_bucket}/{target_path}"
        pyspark_df.write.mode("overwrite").parquet(parquet_file_path)

        # Commit the job
        job.commit()
    except Exception as e:
        traceback.print_exc()
        raise Exception("Exception occurred while running CRGInventoryAvailabilityComputationJob. {}".format(e))

if __name__ == "__main__":
    main()
