WITH
  cal_weeks_number AS (
   SELECT
     cal2."cal date"
   , cal2."weekday int"
   , cal2."Fin Year"
   , cal2."fin week int"
   , cal2."Fin Yearweek int"
   , cal2."week_number"
   , cal2."season identifier"
   , cal_ly."cal date" "Cal Date LY"
   , cal_ly."season identifier" "LY Season Identifier"
   , cal_ly."fin week int" "LY fin week int"
   , cal_ly."Fin Year" "LY Fin Year"
   , cal_ny."cal date" "Cal Date NY"
   , cal_ny."season identifier" "NY Season Identifier"
   , cal_ny."fin week int" "NY fin week int"
   , cal_ny."Fin Yearweek int" "NY Fin Yearweek int"
   , cal_ny."Fin Year" "NY Fin Year"
   FROM
     (((
      SELECT
        cal."cal date"
      , cal."weekday int"
      , cal."Fin Year"
      , cal."fin week int"
      , cal."Fin Yearweek int"
      , cal."Fin Period"
      , cal."Fin Week of Month Int"
      , cal."season identifier"
      , wknum."week_number"
      FROM
        "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal
      , (
         SELECT
           row_number() OVER (ORDER BY "cal date" ASC) week_number
         , "Fin Yearweek int"
         FROM
           "crg_daas_{env}_business_aligned_db"."crg_calendar_view"
         WHERE ("weekday int" = 1)
      )  wknum
      WHERE (cal."Fin Yearweek int" = wknum."Fin Yearweek int")
   )  cal2
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal_ly ON ((cal2."Fin Period" = cal_ly."Fin Period") AND (cal2."Fin Week of Month Int" = cal_ly."Fin Week of Month Int") AND (cal2."Weekday Int" = cal_ly."Weekday Int") AND (cal2."Fin Year" = (cal_ly."Fin Year" + 1))))
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal_ny ON ((cal2."Fin Period" = cal_ny."Fin Period") AND (cal2."Fin Week of Month Int" = cal_ny."Fin Week of Month Int") AND (cal2."Weekday Int" = cal_ny."Weekday Int") AND (cal2."Fin Year" = (cal_ny."Fin Year" - 1))))
) 
, COMP AS (
   SELECT
     scp."seasonid"
   , scp."compstatus"
   , concat('CRG - ', scp."storeid") "store key"
   FROM
     "crg_daas_{env}_mfpoutbound_db"."storecomp" scp
) 
, sales_by_week AS (
   SELECT
     sd."store key"
   , sd."sale date"
   , count(DISTINCT "transaction sequence number") count_of_trans
   , sum(sd."sales amount excl") Sum_sales_amt
   , sum(sd."sales quantity") Sum_QTY
   , sum(sd."margin") sum_margin
   , cal."Fin Year"
   , cal."fin week int"
   , cal."Fin Yearweek int"
   , cal."week_number"
   , cal."weekday int"
   , cal."Cal Date Ly"
   , cal."season identifier"
   , cal."LY Season Identifier"
   , cal."LY fin week int"
   , cal."LY Fin Year"
   , cal."Cal Date NY"
   , cal."NY Season Identifier"
   , cal."NY fin week int"
   , cal."NY Fin Yearweek int"
   , cal."NY Fin Year"
   , COALESCE(pd."Plan Division", concat('*', pd."subclass")) "Plan Division"
   , pd."Plan Division Code"
   , pd."brand"
   , pd."plan brand"
   , pd."plan brand code"
   , sto."plan channel code"
   , sto."plan channel"
   , sto."reporting channel"
   FROM
     "crg_daas_{env}_business_aligned_db"."crg_product_view" pd
   , cal_weeks_number cal
   , ((SELECT DISTINCT
    "Sale_Date" AS "Sale Date",
    "Business_Date" AS "Business Date",
    "Transaction_Sequence_Number" AS "Transaction Sequence Number",
    "Item_Sequence_Number" AS "Item Sequence Number",
    "TH_Tran_no" AS "TH Tran no",
    "SKU" AS "SKU",
    "SKU_Key" AS "SKU Key",
    "Store_Key" AS "Store Key",
    "Original_Store_Key" AS "Original Store Key",
    "Transaction_type" AS "Transaction type",
    "Salesperson" AS "Salesperson",
    CAST("Cashier" AS VARCHAR) AS "Cashier",
    "Item_Status" AS "Item Status",
    "Proof_of_Purchase" AS "Proof of Purchase",
    "Sales_Quantity" AS "Sales Quantity",
    "Retail_Amount" AS "Retail Amount",
    "Discount_Amount" AS "Discount Amount",
    "Sales_Amount" AS "Sales Amount",
    "Retail_Amount_Local" AS "Retail Amount Local",
    "Discount_Amount_Local" AS "Discount Amount Local",
    "Sales_Amount_Local" AS "Sales Amount Local",
    "Retail_Amount_Excl" AS "Retail Amount Excl",
    "Discount_Amount_Excl" AS "Discount Amount Excl",
    "Sales_Amount_Excl" AS "Sales Amount Excl",
    "Retail_Amount_Local_Excl" AS "Retail Amount Local Excl",
    "Discount_Amount_Local_Excl" AS "Discount Amount Local Excl",
    "Sales_Amount_Local_Excl" AS "Sales Amount Local Excl",
    "Return_Sales_Header_Key" AS "Return Sales Header Key",
    "Return_Sales_Detail_Key" AS "Return Sales Detail Key",
    "fReturnLine" AS "fReturnLine",
    "Original_Sale_From" AS "Original Sale From",
    "Currency_Code" AS "Currency Code",
    "Exchange_Rate" AS "Exchange Rate",
    "Tax_Rate" AS "Tax Rate",
    "Cost_Amount" AS "Cost Amount",
    "Cost_Amount_Local" AS "Cost Amount Local",
    "Margin" AS "Margin",
    "Margin_local" AS "Margin local",
    "Original_Sale_Sequence_Number" AS "Original Sale Sequence Number",
    "Original_Sale_Item_Sequence_Number" AS "Original Sale Item Sequence Number",
    "Reference_Number_07" AS "Reference Number 07"
FROM "crg_daas_{env}_bamv_db"."crg_sales_detail"
where month(date("Sale_Date")) = {part}) sd
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_store_MV" sto ON (sd."Store Key" = sto."Store Key"))
   WHERE ((sd."sku key" = pd."sku key") AND (cal."cal date" = sd."sale date") AND (pd."Plan Division" IS NOT NULL))
   GROUP BY sd."store key", sd."sale date", cal."fin week int", cal."Fin Year", cal."Fin Yearweek int", cal."week_number", cal."weekday int", cal."Cal Date Ly", cal."season identifier", cal."LY Season Identifier", cal."LY fin week int", cal."LY Fin Year", cal."Cal Date NY", cal."NY Season Identifier", cal."NY fin week int", cal."NY Fin Yearweek int", cal."NY Fin Year", COALESCE(pd."Plan Division", concat('*', pd."subclass")), pd."Plan Division Code", pd."brand", pd."plan brand", pd."plan brand code", sto."plan channel code", sto."plan channel", sto."reporting channel"
) 
, sales_ty_ly AS (
   SELECT
     COALESCE(sbw1."store key", sbw2."store key") "store key"
   , COALESCE(sbw1."sale date", sbw2."Cal Date NY") "sale date"
   , COALESCE(sbw1."count_of_trans", 0) "count_of_trans"
   , COALESCE(sbw1."Sum_sales_amt", 0) "Sum_sales_amt"
   , COALESCE(sbw1."Sum_QTY", 0) "Sum_QTY"
   , COALESCE(sbw1."sum_margin", 0) "sum_margin"
   , COALESCE(sbw1."Fin Year", sbw2."NY Fin Year") "Fin Year"
   , COALESCE(sbw1."fin week int", sbw2."NY fin week int") "fin week int"
   , COALESCE(sbw1."Fin Yearweek int", sbw2."NY Fin Yearweek int") "Fin Yearweek int"
   , COALESCE(sbw1."week_number", sbw2."week_number") "week_number"
   , COALESCE(sbw1."weekday int", sbw2."weekday int") "weekday int"
   , COALESCE(sbw1."Cal Date Ly", sbw2."sale date") "Cal Date Ly"
   , COALESCE(sbw1."season identifier", sbw2."NY Season Identifier") "season identifier"
   , COALESCE(sbw1."LY Season Identifier", sbw2."season identifier") "LY Season Identifier"
   , COALESCE(sbw1."LY fin week int", sbw2."fin week int") "LY fin week int"
   , COALESCE(sbw1."LY Fin Year", sbw2."Fin Year") "LY Fin Year"
   , COALESCE(sbw1."Plan Division", sbw2."Plan Division") "Plan Division"
   , COALESCE(sbw1."Plan Division Code", sbw2."Plan Division Code") "Plan Division Code"
   , COALESCE(sbw1."brand", sbw2."brand") "brand"
   , COALESCE(sbw1."plan brand", sbw2."plan brand") "plan brand"
   , COALESCE(sbw1."plan brand code", sbw2."plan brand code") "plan brand code"
   , COALESCE(sbw1."plan channel code", sbw2."plan channel code") "plan channel code"
   , COALESCE(sbw1."plan channel", sbw2."plan channel") "plan channel"
   , COALESCE(sbw1."reporting channel", sbw2."reporting channel") "reporting channel"
   FROM
     (sales_by_week sbw1
   FULL JOIN sales_by_week sbw2 ON ((sbw1."store key" = sbw2."store key") AND (sbw1."fin week int" = sbw2."fin week int") AND (sbw1."Fin Year" = (sbw2."Fin Year" + 1)) AND (sbw1."weekday int" = sbw2."weekday int") AND (sbw1."Plan Division Code" = sbw2."Plan Division Code")))
) 
SELECT
  'Plan Division' "Hierarchy"
, sbw1."store key"
, sbw1."Plan Division"
, sbw1."Plan Division Code"
, sbw1."sale date"
, sbw1."Cal Date Ly"
, sbw1."Fin Yearweek int"
, sbw1."fin week int"
, sbw1."Fin Year"
, cp."compstatus"
, sbw1."season identifier" "season id"
, sbw1."Sum_sales_amt"
, sbw1."sum_margin"
, CAST(null AS double) "Sum Of Moto Sales"
, CAST(null AS double) "Sum of ISAMS sales"
, CAST(null AS double) "Sum Non Merch Sales Amt"
, CAST(null AS bigint) "count_of_trans"
, CAST(null AS decimal(38, 4)) "Sum_QTY"
, CAST(null AS double) "ACP"
, CAST(null AS decimal(38, 4)) "UPT"
, sbw1."plan channel code"
, sbw1."plan channel"
, sbw1."reporting channel"
, CAST(null AS decimal(38, 2)) "MAT_Sum_sales_amt"
, sbw1."weekday int"
, sbw1."brand"
, sbw1."plan brand"
, sbw1."plan brand code"
, CAST(null AS bigint) "Store Entries"
, CAST(null AS bigint) "Store Exits"
, cp2."compstatus" "compstatus LY"
, sbw1."LY Season Identifier" "LY seasonid"
, CAST(null AS double) "LY Sum Of Moto Sales"
, CAST(null AS double) "LY Sum of ISAMS sales"
, sbw2."Sum_sales_amt" "LY Sum_sales_amt"
, sbw2."sum_margin" "LY Margin"
, CAST(null AS bigint) "LY count_of_trans"
, CAST(null AS decimal(38, 4)) "LY Sum_QTY"
, CAST(null AS double) "LY ACP"
, CAST(null AS decimal(38, 4)) "LY UPT"
, sbw1."LY fin week int" "LY fin week int"
, sbw1."LY Fin Year" "LY Fin Year"
, CAST(null AS bigint) "LY Store Entries"
, CAST(null AS bigint) "LY Store Exits"
, concat(concat(concat(concat(concat(concat('Plan Division', ' - '), sbw1."store key"), ' - '), CAST(sbw1."Plan Division Code" AS varchar)), ' - '), CAST(COALESCE(sbw1."sale date", "date_add"('year', -4, sbw1."Cal Date Ly")) AS varchar)) bamv_pk
FROM
  (((sales_ty_ly sbw1
LEFT JOIN comp cp ON ((cp."store key" = sbw1."store key") AND (cp."seasonid" = sbw1."season identifier")))
LEFT JOIN sales_by_week sbw2 ON ((sbw1."store key" = sbw2."store key") AND (sbw1."fin week int" = sbw2."fin week int") AND (sbw1."Fin Year" = (sbw2."Fin Year" + 1)) AND (sbw1."weekday int" = sbw2."weekday int") AND (sbw1."Plan Division Code" = sbw2."Plan Division Code")))
LEFT JOIN comp cp2 ON ((cp2."store key" = sbw2."store key") AND (cp2."seasonid" = sbw2."season identifier")))