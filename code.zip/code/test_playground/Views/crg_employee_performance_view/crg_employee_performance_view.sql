SELECT 
"Fin YearWeek Int" "Fin_YearWeek_Int",
"Fin Week of Month" "Fin_Week_of_Month",
"Sale Date" "Sale_Date",
"Store Key" "Store_Key",
"Salesperson",
"Employee",
"Total Sales" "Total_Sales",
"ACP Total" "ACP_Total",
"Total Transactions" "Total_Transactions",
"Total Units" "Total_Units",
"TotaL Units per Transaction" "TotaL_Units_per_Transaction",
"CRM Cards Issued" "CRM_Cards_Issued",
"Card Conversion %" "Card_Conversion_%",
"Missed Opportunity" "Missed_Opportunity",
"CRM Transaction %" "CRM_Transaction_%"
FROM "crg_daas_{env}_business_aligned_db"."crg_employee_performance_view"