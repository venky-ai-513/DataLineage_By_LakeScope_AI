SELECT
  sd."store key" AS "store_key",
  sd."sale date" AS "sale_date",
  count(DISTINCT "transaction sequence number") AS "count_of_trans",
  sum(sd."sales amount excl") AS "sum_sales_amt",
  sum(sd."sales quantity") AS "sum_qty",
  sum(sd."margin") AS "sum_margin",
  cal."Fin_Year" AS "fin_year",
  cal."fin_week_int" AS "fin_week_int",
  cal."Fin_Yearweek_int" AS "fin_yearweek_int",
  cal."week_number" AS "week_number",
  cal."weekday_int" AS "weekday_int",
  cal."Cal_Date_Ly" AS "cal_date_ly",
  cal."season_identifier" AS "season_identifier",
  cal."LY_Season_Identifier" AS "ly_season_identifier",
  cal."LY_fin_week_int" AS "ly_fin_week_int",
  cal."LY_Fin_Year" AS "ly_fin_year",
  cal."Cal_Date_NY" AS "cal_date_ny",
  cal."NY_Season_Identifier" AS "ny_season_identifier",
  cal."NY_fin_week_int" AS "ny_fin_week_int",
  cal."NY_Fin_Yearweek_int" AS "ny_fin_yearweek_int",
  cal."NY_Fin_Year" AS "ny_fin_year",
  COALESCE(pd."Plan Division", concat('*', pd."subclass")) AS "plan_division",
  pd."Plan Division Code" AS "plan_division_code",
  pd."brand" AS "brand",
  pd."plan brand" AS "plan_brand",
  pd."plan brand code" AS "plan_brand_code",
  sto."plan channel code" AS "plan_channel_code",
  sto."plan channel" AS "plan_channel",
  sto."reporting channel" AS "reporting_channel",
  COALESCE(ci."pc_type", 'Regular') AS "pc_type"
   FROM
     "crg_daas_{env}_business_aligned_db"."crg_product_view" pd
   , (SELECT
      cal2."cal date" AS "cal_date",
      cal2."weekday int" AS "weekday_int",
      cal2."Fin Year" AS "Fin_Year",
      cal2."fin week int" AS "fin_week_int",
      cal2."Fin Yearweek int" AS "Fin_Yearweek_int",
      cal2."week_number" AS "week_number",
      cal2."season identifier" AS "season_identifier",
      cal_ly."cal date" AS "Cal_Date_LY",
      cal_ly."season identifier" AS "LY_Season_Identifier",
      cal_ly."fin week int" AS "LY_fin_week_int",
      cal_ly."Fin Year" AS "LY_Fin_Year",
      cal_ny."cal date" AS "Cal_Date_NY",
      cal_ny."season identifier" AS "NY_Season_Identifier",
      cal_ny."fin week int" AS "NY_fin_week_int",
      cal_ny."Fin Yearweek int" AS "NY_Fin_Yearweek_int",
      cal_ny."Fin Year" AS "NY_Fin_Year"
   FROM
     (((
      SELECT
        cal."cal date"
      , cal."weekday int"
      , cal."Fin Year"
      , cal."fin week int"
      , cal."Fin Yearweek int"
      , cal."Fin Period"
      , cal."Fin Week of Month Int"
      , cal."season identifier"
      , wknum."week_number"
      FROM
        "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal
      , (
         SELECT
           row_number() OVER (ORDER BY "cal date" ASC) week_number
         , "Fin Yearweek int"
         FROM
           "crg_daas_{env}_business_aligned_db"."crg_calendar_view"
         WHERE ("weekday int" = 1)
      )  wknum
      WHERE (cal."Fin Yearweek int" = wknum."Fin Yearweek int")
   )  cal2
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal_ly ON ((cal2."Fin Period" = cal_ly."Fin Period") AND (cal2."Fin Week of Month Int" = cal_ly."Fin Week of Month Int") AND (cal2."Weekday Int" = cal_ly."Weekday Int") AND (cal2."Fin Year" = (cal_ly."Fin Year" + 1))))
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal_ny ON ((cal2."Fin Period" = cal_ny."Fin Period") AND (cal2."Fin Week of Month Int" = cal_ny."Fin Week of Month Int") AND (cal2."Weekday Int" = cal_ny."Weekday Int") AND (cal2."Fin Year" = (cal_ny."Fin Year" - 1))))) cal
   , (((
      SELECT
        det.*
      , pzg.zone_group_id
      , pzg.zone_id
      FROM
        ("crg_daas_{env}_business_aligned_db"."crg_sales_detail_view" det
      LEFT JOIN "crg_daas_{env}_rmsprd90_db"."price_zone_group_store" pzg ON (det."store key" = concat('CRG - ', CAST(pzg.store AS varchar))))
   )  sd
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_clearance_indicator_view" ci ON ((sd."sku key" = concat('CRG - ', CAST(ci."sku" AS varchar))) AND (sd."sale date" >= ci."pc start date") AND (sd."sale date" <= ci."pc end date") AND (sd.zone_group_id = ci.zone_group_id) AND (sd.zone_id = ci.zone_id)))
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_store_view" sto ON (sd."Store Key" = sto."Store Key"))
   WHERE ((sd."sku key" = pd."sku key") AND (cal."cal_date" = sd."sale date") AND (sd."sales amount" <> 0) AND (pd."Plan Division" IS NOT NULL))
   GROUP BY sd."store key", sd."sale date", cal."fin_week_int", cal."Fin_Year", cal."Fin_Yearweek_int", cal."week_number", cal."weekday_int", cal."Cal_Date_Ly", cal."season_identifier", cal."LY_Season_Identifier", cal."LY_fin_week_int", cal."LY_Fin_Year", cal."Cal_Date_NY", cal."NY_Season_Identifier", cal."NY_fin_week_int", cal."NY_Fin_Yearweek_int", cal."NY_Fin_Year", COALESCE(pd."Plan Division", concat('*', pd."subclass")), pd."Plan Division Code", pd."brand", pd."plan brand", pd."plan brand code", sto."plan channel code", sto."plan channel", sto."reporting channel", COALESCE(ci."pc_type", 'Regular')
