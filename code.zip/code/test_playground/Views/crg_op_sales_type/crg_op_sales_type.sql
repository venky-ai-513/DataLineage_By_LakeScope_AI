WITH
  cal_weeks_number AS (
   SELECT
     cal2."cal date"
   , cal2."weekday int"
   , cal2."Fin Year"
   , cal2."fin week int"
   , cal2."Fin Yearweek int"
   , cal2."week_number"
   , cal2."season identifier"
   , cal_ly."cal date" "Cal Date LY"
   , cal_ly."season identifier" "LY Season Identifier"
   , cal_ly."fin week int" "LY fin week int"
   , cal_ly."Fin Year" "LY Fin Year"
   , cal_ny."cal date" "Cal Date NY"
   , cal_ny."season identifier" "NY Season Identifier"
   , cal_ny."fin week int" "NY fin week int"
   , cal_ny."Fin Yearweek int" "NY Fin Yearweek int"
   , cal_ny."Fin Year" "NY Fin Year"
   FROM
     (((
      SELECT
        cal."cal date"
      , cal."weekday int"
      , cal."Fin Year"
      , cal."fin week int"
      , cal."Fin Yearweek int"
      , cal."Fin Period"
      , cal."Fin Week of Month Int"
      , cal."season identifier"
      , wknum."week_number"
      FROM
        "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal
      , (
         SELECT
           row_number() OVER (ORDER BY "cal date" ASC) week_number
         , "Fin Yearweek int"
         FROM
           "crg_daas_{env}_business_aligned_db"."crg_calendar_view"
         WHERE ("weekday int" = 1)
      )  wknum
      WHERE (cal."Fin Yearweek int" = wknum."Fin Yearweek int")
   )  cal2
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal_ly ON ((cal2."Fin Period" = cal_ly."Fin Period") AND (cal2."Fin Week of Month Int" = cal_ly."Fin Week of Month Int") AND (cal2."Weekday Int" = cal_ly."Weekday Int") AND (cal2."Fin Year" = (cal_ly."Fin Year" + 1))))
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal_ny ON ((cal2."Fin Period" = cal_ny."Fin Period") AND (cal2."Fin Week of Month Int" = cal_ny."Fin Week of Month Int") AND (cal2."Weekday Int" = cal_ny."Weekday Int") AND (cal2."Fin Year" = (cal_ny."Fin Year" - 1))))
) 
, COMP AS (
   SELECT
     scp."seasonid"
   , scp."compstatus"
   , concat('CRG - ', scp."storeid") "store key"
   FROM
     "crg_daas_{env}_mfpoutbound_db"."storecomp" scp
) 
, sales_by_week AS (
   SELECT
     sd."store key"
   , sd."sale date"
   , count(DISTINCT "transaction sequence number") count_of_trans
   , sum(sd."sales amount excl") Sum_sales_amt
   , sum(sd."sales quantity") Sum_QTY
   , sum(sd."margin") sum_margin
   , cal."Fin Year"
   , cal."fin week int"
   , cal."Fin Yearweek int"
   , cal."week_number"
   , cal."weekday int"
   , cal."Cal Date Ly"
   , cal."season identifier"
   , cal."LY Season Identifier"
   , cal."LY fin week int"
   , cal."LY Fin Year"
   , cal."Cal Date NY"
   , cal."NY Season Identifier"
   , cal."NY fin week int"
   , cal."NY Fin Yearweek int"
   , cal."NY Fin Year"
   , COALESCE(pd."Plan Division", concat('*', pd."subclass")) "Plan Division"
   , pd."Plan Division Code"
   , pd."brand"
   , pd."plan brand"
   , pd."plan brand code"
   , sto."plan channel code"
   , sto."plan channel"
   , sto."reporting channel"
   , COALESCE(ci."pc_type", 'Regular') "pc_type"
   FROM
     "crg_daas_{env}_business_aligned_db"."crg_product_view" pd
   , cal_weeks_number cal
   , (((
      SELECT
        det.*
      , (CASE WHEN (substr(det."store key", 1, 3) = 'POL') THEN 8000 ELSE pzg.zone_group_id END) "zone_group_id"
      , (CASE WHEN (substr(det."store key", 1, 3) = 'POL') THEN (CASE WHEN ("Country Code" = '1') THEN 8000 WHEN ("Country Code" = '13') THEN 8500 ELSE 0 END) ELSE pzg.zone_id END) "zone_id"
      FROM
        "crg_daas_{env}_business_aligned_db"."crg_store_MV" sto
      , ((Select * from "crg_daas_{env}_business_aligned_db"."crg_sales_detail_mv" where month({date1}) = {part}) det
      LEFT JOIN "crg_daas_{env}_rmsprd90_db"."price_zone_group_store" pzg ON (det."store key" = concat('CRG - ', CAST(pzg.store AS varchar))))
      WHERE (sto."store key" = det."store key")
   )  sd
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_clearance_indicator_view" ci ON ((sd."sku key" = ci."sku key") AND (sd."sale date" >= ci."pc start date") AND (sd."sale date" <= ci."pc end date") AND (sd.zone_group_id = ci.zone_group_id) AND (sd.zone_id = ci.zone_id)))
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_store_MV" sto ON (sd."Store Key" = sto."Store Key"))
   WHERE ((sd."sku key" = pd."sku key") AND (cal."cal date" = sd."sale date") AND (sd."sales amount" <> 0) AND (pd."Plan Division" IS NOT NULL))
   GROUP BY sd."store key", sd."sale date", cal."fin week int", cal."Fin Year", cal."Fin Yearweek int", cal."week_number", cal."weekday int", cal."Cal Date Ly", cal."season identifier", cal."LY Season Identifier", cal."LY fin week int", cal."LY Fin Year", cal."Cal Date NY", cal."NY Season Identifier", cal."NY fin week int", cal."NY Fin Yearweek int", cal."NY Fin Year", COALESCE(pd."Plan Division", concat('*', pd."subclass")), pd."Plan Division Code", pd."brand", pd."plan brand", pd."plan brand code", sto."plan channel code", sto."plan channel", sto."reporting channel", COALESCE(ci."pc_type", 'Regular')
) 
, sales_ty_ly AS (
   SELECT
     COALESCE(sbw1."store key", sbw2."store key") "store key"
   , COALESCE(sbw1."sale date", sbw2."Cal Date NY") "sale date"
   , COALESCE(sbw1."count_of_trans", 0) "count_of_trans"
   , COALESCE(sbw1."Sum_sales_amt", 0) "Sum_sales_amt"
   , COALESCE(sbw1."Sum_QTY", 0) "Sum_QTY"
   , COALESCE(sbw1."sum_margin", 0) "sum_margin"
   , COALESCE(sbw1."Fin Year", sbw2."NY Fin Year") "Fin Year"
   , COALESCE(sbw1."fin week int", sbw2."NY fin week int") "fin week int"
   , COALESCE(sbw1."Fin Yearweek int", sbw2."NY Fin Yearweek int") "Fin Yearweek int"
   , COALESCE(sbw1."week_number", sbw2."week_number") "week_number"
   , COALESCE(sbw1."weekday int", sbw2."weekday int") "weekday int"
   , COALESCE(sbw1."Cal Date Ly", sbw2."sale date") "Cal Date Ly"
   , COALESCE(sbw1."season identifier", sbw2."NY Season Identifier") "season identifier"
   , COALESCE(sbw1."LY Season Identifier", sbw2."season identifier") "LY Season Identifier"
   , COALESCE(sbw1."LY fin week int", sbw2."fin week int") "LY fin week int"
   , COALESCE(sbw1."LY Fin Year", sbw2."Fin Year") "LY Fin Year"
   , COALESCE(sbw1."Plan Division", sbw2."Plan Division") "Plan Division"
   , COALESCE(sbw1."Plan Division Code", sbw2."Plan Division Code") "Plan Division Code"
   , COALESCE(sbw1."brand", sbw2."brand") "brand"
   , COALESCE(sbw1."plan brand", sbw2."plan brand") "plan brand"
   , COALESCE(sbw1."plan brand code", sbw2."plan brand code") "plan brand code"
   , COALESCE(sbw1."plan channel code", sbw2."plan channel code") "plan channel code"
   , COALESCE(sbw1."plan channel", sbw2."plan channel") "plan channel"
   , COALESCE(sbw1."reporting channel", sbw2."reporting channel") "reporting channel"
   , COALESCE(sbw1."pc_type", sbw2."pc_type") "pc_type"
   FROM
     (sales_by_week sbw1
   FULL JOIN sales_by_week sbw2 ON ((sbw1."store key" = sbw2."store key") AND (sbw1."fin week int" = sbw2."fin week int") AND (sbw1."Fin Year" = (sbw2."Fin Year" + 1)) AND (sbw1."weekday int" = sbw2."weekday int") AND (sbw1."Plan Division Code" = sbw2."Plan Division Code") AND (sbw1."pc_type" = sbw2."pc_type")))
) 
, MAT_sales_by_week AS (
   SELECT
     CAST(sum(sc."Sum_sales_amt") AS decimal(38, 2)) "MAT_Sum_sales_amt"
   , sb."store key"
   , sb."fin week int"
   , sb."weekday int"
   , sb."Plan Division Code"
   , sb."week_number"
   , sb."pc_type"
   FROM
     sales_by_week sb
   , sales_by_week sc
   WHERE ((sc."week_number" < sb."week_number") AND (sc."week_number" >= (sb."week_number" - 53)) AND (sc."store key" = sb."store key") AND (sc."weekday int" = sb."weekday int") AND (sc."Plan Division Code" = sb."Plan Division Code") AND (sc."pc_type" = sb."pc_type"))
   GROUP BY sb."store key", sb."fin week int", sb."weekday int", sb."Plan Division Code", sb."week_number", sb."pc_type"
) 
SELECT
  concat(concat(concat(concat('Plan Division', '&'), rpad(COALESCE(sbw1."pc_type", 'unknown'), 20, ' ')), '%'), rpad(COALESCE(sbw2."pc_type", 'unknown'), 20, ' ')) "Hierarchy"
, sbw1."store key"
, sbw1."Plan Division"
, CAST(sbw1."Plan Division Code" as VARCHAR) "Plan Division Code"
, CAST(CAST(sbw1."sale date" AS VARCHAR) AS DATE) "sale date"
, CAST(sbw1."Cal Date Ly" AS VARCHAR) "Cal Date Ly"
, CAST(CAST(sbw1."Fin Yearweek int" AS VARCHAR)AS BIGINT) "Fin Yearweek int"
, CAST(CAST(sbw1."fin week int" AS VARCHAR) AS BIGINT) "fin week int"
, CAST(CAST(sbw1."Fin Year" AS VARCHAR) AS BIGINT) "Fin Year"
, cp."compstatus"
, sbw1."season identifier" "season id"
, sbw1."Sum_sales_amt"
, sbw1."sum_margin"
, CAST(null AS double) "Sum Of Moto Sales"
, CAST(null AS double) "Sum of ISAMS sales"
, CAST(null AS double) "Sum Non Merch Sales Amt"
, CAST(null AS bigint) "count_of_trans"
, CAST(null AS decimal(38, 4)) "Sum_QTY"
, CAST(null AS double) "ACP"
, CAST(null AS decimal(38, 4)) "UPT"
, sbw1."plan channel code"
, sbw1."plan channel"
, sbw1."reporting channel"
, ms."MAT_Sum_sales_amt"
, sbw1."weekday int"
, sbw1."brand"
, sbw1."plan brand"
, sbw1."plan brand code"
, CAST(null AS bigint) "Store Entries"
, CAST(null AS bigint) "Store Exits"
, cp2."compstatus" "compstatus LY"
, sbw1."LY Season Identifier" "LY seasonid"
, CAST(null AS double) "LY Sum Of Moto Sales"
, CAST(null AS double) "LY Sum of ISAMS sales"
, sbw2."Sum_sales_amt" "LY Sum_sales_amt"
, sbw2."sum_margin" "LY Margin"
, CAST(null AS bigint) "LY count_of_trans"
, CAST(null AS decimal(38, 4)) "LY Sum_QTY"
, CAST(null AS double) "LY ACP"
, CAST(null AS decimal(38, 4)) "LY UPT"
, sbw1."LY fin week int" "LY fin week int"
, sbw1."LY Fin Year" "LY Fin Year"
, CAST(null AS bigint) "LY Store Entries"
, CAST(null AS bigint) "LY Store Exits"
FROM
  ((((sales_ty_ly sbw1
LEFT JOIN MAT_sales_by_week ms ON ((sbw1."store key" = ms."store key") AND (sbw1."fin week int" = ms."fin week int") AND (sbw1."week_number" = ms."week_number") AND (sbw1."weekday int" = ms."weekday int") AND (sbw1."Plan Division Code" = ms."Plan Division Code") AND (sbw1."pc_type" = ms."pc_type")))
LEFT JOIN comp cp ON ((cp."store key" = sbw1."store key") AND (cp."seasonid" = sbw1."season identifier")))
LEFT JOIN sales_by_week sbw2 ON ((sbw1."store key" = sbw2."store key") AND (sbw1."fin week int" = sbw2."fin week int") AND (sbw1."Fin Year" = (sbw2."Fin Year" + 1)) AND (sbw1."weekday int" = sbw2."weekday int") AND (sbw1."Plan Division Code" = sbw2."Plan Division Code") AND (sbw1."pc_type" = sbw2."pc_type")))
LEFT JOIN comp cp2 ON ((cp2."store key" = sbw2."store key") AND (cp2."seasonid" = sbw2."season identifier")))
