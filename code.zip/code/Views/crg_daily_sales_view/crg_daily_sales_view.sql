SELECT 
"Source Table"	"Source_Table",	
"Store Code" "Store_Code",	
"Store Key"	"Store_Key",	
"sku",
"SKU Key" "SKU_Key",
"Sale Date" "Sale_Date",
"Sales Amount" "Sales_Amount",
"Cost Amount" "Cost_Amount",
"Profit Amount" "Profit_Amount",
"Sales Quantity" "Sales_Quantity",
"Currency Code" "Currency_Code",
"Exchange Rate"	 "Exchange_Rate",
"Tax Rate" "Tax_Rate",
"Comp Status" "Comp_Status",
"zone_group_id",
"zone_id",
"item_type"
FROM "crg_daas_{env}_business_aligned_db"."crg_daily_sales_view"