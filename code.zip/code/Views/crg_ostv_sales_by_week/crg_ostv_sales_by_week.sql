WITH
  cal_weeks_number AS (
   SELECT
     cal2."cal date"
   , cal2."weekday int"
   , cal2."Fin Year"
   , cal2."fin week int"
   , cal2."Fin Yearweek int"
   , cal2."week_number"
   , cal2."season identifier"
   , cal_ly."cal date" "Cal Date LY"
   , cal_ly."season identifier" "LY Season Identifier"
   , cal_ly."fin week int" "LY fin week int"
   , cal_ly."Fin Year" "LY Fin Year"
   , cal_ny."cal date" "Cal Date NY"
   , cal_ny."season identifier" "NY Season Identifier"
   , cal_ny."fin week int" "NY fin week int"
   , cal_ny."Fin Yearweek int" "NY Fin Yearweek int"
   , cal_ny."Fin Year" "NY Fin Year"
   FROM
     (((
      SELECT
        cal."cal date"
      , cal."weekday int"
      , cal."Fin Year"
      , cal."fin week int"
      , cal."Fin Yearweek int"
      , cal."Fin Period"
      , cal."Fin Week of Month Int"
      , cal."season identifier"
      , wknum."week_number"
      FROM
        "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal
      , (
         SELECT
           row_number() OVER (ORDER BY "cal date" ASC) week_number
         , "Fin Yearweek int"
         FROM
           "crg_daas_{env}_business_aligned_db"."crg_calendar_view"
         WHERE ("weekday int" = 1)
      )  wknum
      WHERE (cal."Fin Yearweek int" = wknum."Fin Yearweek int")
   )  cal2
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal_ly ON ((cal2."Fin Period" = cal_ly."Fin Period") AND (cal2."Fin Week of Month Int" = cal_ly."Fin Week of Month Int") AND (cal2."Weekday Int" = cal_ly."Weekday Int") AND (cal2."Fin Year" = (cal_ly."Fin Year" + 1))))
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal_ny ON ((cal2."Fin Period" = cal_ny."Fin Period") AND (cal2."Fin Week of Month Int" = cal_ny."Fin Week of Month Int") AND (cal2."Weekday Int" = cal_ny."Weekday Int") AND (cal2."Fin Year" = (cal_ny."Fin Year" - 1))))
) 
, COMP AS (
   SELECT
     scp."seasonid"
   , scp."compstatus"
   , concat('CRG - ', scp."storeid") "store key"
   FROM
     "crg_daas_{env}_mfpoutbound_db"."storecomp" scp
) 
SELECT
    sd."store key" "store_key"
, sd."sale date"
, count(DISTINCT "transaction sequence number") count_of_trans
, sum(sd."sales amount excl") Sum_sales_amt
, sum(sd."sales quantity") Sum_QTY
, sum(sd."margin") sum_margin
, cal."Fin Year" "Fin_Year"
, cal."fin week int" "fin_week_int"
, cal."Fin Yearweek int" "Fin_Yearweek_int"
, cal."week_number"
, cal."weekday int" "weekday_int"
, cal."Cal Date Ly" "Cal_Date_Ly"
, cal."season identifier" "season_identifier"
, cal."LY Season Identifier" "LY_Season_Identifier"
, cal."LY fin week int" "LY_fin_week_int"
, cal."LY Fin Year" "LY_Fin_Year"
, cal."Cal Date NY" "Cal_Date_NY"
, cal."NY Season Identifier" "NY_Season_Identifier"
, cal."NY fin week int" "NY_fin_week_int"
, cal."NY Fin Yearweek int" "NY_Fin_Yearweek_int"
, cal."NY Fin Year" "NY_Fin_Year"
, COALESCE(pd."Plan Division", concat('*', pd."subclass")) "Plan_Division"
, pd."Plan Division Code" "Plan_Division_Code"
, pd."brand"
, pd."plan brand" "plan_brand"
, pd."plan brand code" "plan_brand_code"
, sto."plan channel code" "plan_channel_code"
, sto."plan channel" "plan_channel"
, sto."reporting channel" "reporting_channel"
, COALESCE(ci."pc_type", 'Regular') "pc_type"
FROM
    "crg_daas_{env}_business_aligned_db"."crg_product_view" pd
, cal_weeks_number cal
, (((
    SELECT
    det.*
    , (CASE WHEN (substr(det."store key", 1, 3) = 'POL') THEN 8000 ELSE pzg.zone_group_id END) "zone_group_id"
    , (CASE WHEN (substr(det."store key", 1, 3) = 'POL') THEN (CASE WHEN ("Country Code" = '1') THEN 8000 WHEN ("Country Code" = '13') THEN 8500 ELSE 0 END) ELSE pzg.zone_id END) "zone_id"
    FROM
    "crg_daas_{env}_business_aligned_db"."crg_store_MV" sto
    , ((Select * from "crg_daas_{env}_business_aligned_db"."crg_sales_detail_mv" where month({date1}) = {part} ) det
    LEFT JOIN "crg_daas_{env}_rmsprd90_db"."price_zone_group_store" pzg ON (det."store key" = concat('CRG - ', CAST(pzg.store AS varchar))))
    WHERE (sto."store key" = det."store key")
)  sd
LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_clearance_indicator_view" ci ON ((sd."sku key" = ci."sku key") AND (sd."sale date" >= ci."pc start date") AND (sd."sale date" <= ci."pc end date") AND (sd.zone_group_id = ci.zone_group_id) AND (sd.zone_id = ci.zone_id)))
LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_store_MV" sto ON (sd."Store Key" = sto."Store Key"))
WHERE ((sd."sku key" = pd."sku key") AND (cal."cal date" = sd."sale date") AND (sd."sales amount" <> 0) AND (pd."Plan Division" IS NOT NULL))
GROUP BY sd."store key", sd."sale date", cal."fin week int", cal."Fin Year", cal."Fin Yearweek int", cal."week_number", cal."weekday int", cal."Cal Date Ly", cal."season identifier", cal."LY Season Identifier", cal."LY fin week int", cal."LY Fin Year", cal."Cal Date NY", cal."NY Season Identifier", cal."NY fin week int", cal."NY Fin Yearweek int", cal."NY Fin Year", COALESCE(pd."Plan Division", concat('*', pd."subclass")), pd."Plan Division Code", pd."brand", pd."plan brand", pd."plan brand code", sto."plan channel code", sto."plan channel", sto."reporting channel", COALESCE(ci."pc_type", 'Regular')
