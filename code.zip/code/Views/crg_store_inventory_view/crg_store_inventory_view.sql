SELECT
"store",
"store key",
"sku",
"sku key",
"style",
"stock_on_hand",
"in_transit_qty",
"Total Stock",
"unit_cost_local",
"unit_cost",
"av_cost_local",
"av_cost",
"unit_retail_local",
"unit_retail",
"eff_start_date",
COALESCE( "date_add"('day',-1 ,"lag"(eff_start_date) OVER (PARTITION BY store, sku ORDER BY eff_start_date DESC)                                 )
        ,CURRENT_DATE)                                                  AS "eff_end_date", 
"Currency Code",
"Chain",
"unit_cost_local_incl",
"unit_cost_incl",
"av_cost_local_incl",
"av_cost_incl",
"unit_retail_local_incl",
"unit_retail_incl",
"tsf_reserved_qty",
"Net SOH"
FROM 
( 
SELECT
  soh."store",
  'CRG - '||cast(soh."store" as varchar)                                  AS "store key",
  soh."sku",
  'CRG - '||cast(soh."sku" as varchar)                                    AS "sku key",
  soh."style",
  soh."stock_on_hand",
  soh."tsf_reserved_qty",
  soh."stock_on_hand" - soh."tsf_reserved_qty"                            AS "Net SOH",
  soh."in_transit_qty",
  soh."stock_on_hand" + soh."in_transit_qty"                              AS "Total Stock",
  soh."unit_cost" / coalesce(str."Tax Rate",1)                            AS unit_cost_local,
  (soh."unit_cost" / str."Exchange Rate") / coalesce(str."Tax Rate",1)    AS unit_cost,
  soh."av_cost" / coalesce(str."Tax Rate",1)                              AS av_cost_local,
  (soh."av_cost" / str."Exchange Rate") / coalesce(str."Tax Rate",1)      AS av_cost,
  soh."unit_retail" / coalesce(str."Tax Rate",1)                          AS unit_retail_local,
  (soh."unit_retail" / str."Exchange Rate") / coalesce(str."Tax Rate",1)  AS unit_retail,
  soh."unit_cost"                                                         AS unit_cost_local_incl,
  (soh."unit_cost" / str."Exchange Rate")                                 AS unit_cost_incl,
  soh."av_cost"                                                           AS av_cost_local_incl,
  (soh."av_cost" / str."Exchange Rate")                                   AS av_cost_incl,
  soh."unit_retail"                                                       AS unit_retail_local_incl,
  (soh."unit_retail" / str."Exchange Rate")                               AS unit_retail_incl,
  soh."inventory_date"                                                    AS eff_start_date,
  sort_seq,
  case
    when
      lead( soh."stock_on_hand" )OVER (PARTITION BY soh.store,soh.sku, soh."unit_retail" ORDER BY soh.inventory_date DESC) = soh."stock_on_hand"  
      and
      lead( soh."in_transit_qty" )OVER (PARTITION BY soh.store,soh.sku, soh."unit_retail" ORDER BY soh.inventory_date DESC) = soh."in_transit_qty"  
  then 'no change'
  else 'change'
  end                                                                     AS "changed",
  str."currency code"                                                     AS "Currency Code",
  str."chain"                                                             AS "Chain"
FROM
(  SELECT
    store,
    'CRG - '||cast("store" as varchar) as "store key",
    sku,
    style,
    stock_on_hand,
    in_transit_qty,
    tsf_reserved_qty,
    unit_cost,
    av_cost,
    unit_retail,
    inventory_date ,
    ROW_NUMBER() OVER (PARTITION BY sku,store,inventory_date
                        ORDER BY "timestamp" DESC ,"dms_ar_h_stream_position" DESC
                        ) AS sort_seq
  FROM (
        SELECT
         "timestamp",
          DATE(DATE_PARSE("timestamp", '%Y-%m-%d %H:%i:%s.%f')) as inventory_date,
          sku,
          style,
          store,
          stock_on_hand,
          in_transit_qty,
          tsf_reserved_qty,
          unit_cost,
          av_cost,
          unit_retail,
         "dms_ar_h_stream_position"
        FROM
            "crg_daas_{env}_rmsprd90_staging_db"."rag_skus_st"
        WHERE (SUBSTR(CAST("store" as varchar),1,1)  = '{part}')
        AND "year" >= '2022'
     )
) soh,
(SELECT
 ST."store",
 ST."store key" "store key",
 ST."currency code",
 ST."chain",
 CASE ST."currency code"
    WHEN 'AUD' THEN 1
    WHEN 'NZD' THEN 1.2
    WHEN 'ZAR' THEN 11
    ELSE 1
    END                        AS "Exchange Rate",
 CASE ST."currency code"
    WHEN 'AUD' THEN 1.1E0
    WHEN 'NZD' THEN 1.15E0
    WHEN 'ZAR' THEN 1.15E0 END AS "Tax Rate"
FROM
  "crg_daas_{env}_business_aligned_db"."crg_store_mv" ST) STR
WHERE sort_seq=1
AND soh."store key" = str."store key"
) WHERE  "changed" = 'change' 
