WITH
 COMP AS (
   SELECT
     scp."seasonid"
   , scp."compstatus"
   , concat('CRG - ', scp."storeid") "store key"
   FROM
     "crg_daas_{env}_mfpoutbound_db"."storecomp" scp
) 
, sales_by_week AS (
   SELECT 
   "store_key" AS "store key",
       "sale_date" AS "sale date",
       "count_of_trans",
       "Sum_sales_amt",
       "Sum_QTY",
       "sum_margin",
       "Fin_Year" AS "Fin Year",
       "fin_week_int" AS "fin week int",
       "Fin_Yearweek_int" AS "Fin Yearweek int",
       "week_number",
       "weekday_int" AS "weekday int",
       "Cal_Date_Ly" AS "Cal Date Ly",
       "season_identifier" AS "season identifier",
       "LY_Season_Identifier" AS "LY Season Identifier",
       "LY_fin_week_int" AS "LY fin week int",
       "LY_Fin_Year" AS "LY Fin Year",
       "Cal_Date_NY" AS "Cal Date NY",
       "NY_Season_Identifier" AS "NY Season Identifier",
       "NY_fin_week_int" AS "NY fin week int",
       "NY_Fin_Yearweek_int" AS "NY Fin Yearweek int",
       "NY_Fin_Year" AS "NY Fin Year",
       "Plan_Division" AS "Plan Division",
       "Plan_Division_Code" AS "Plan Division Code",
       "brand" AS "brand",
       "plan_brand" AS "plan brand",
       "plan_brand_code" AS "plan brand code",
       "plan_channel_code" AS "plan channel code",
       "plan_channel" AS "plan channel",
       "reporting_channel" AS "reporting channel",
       "pc_type" from "crg_daas_{env}_bamv_db"."crg_ostv_sales_by_week" where month(date({date1})) = {part})

, sales_ty_ly AS (
   SELECT
     COALESCE(sbw1."store key", sbw2."store key") "store key"
   , COALESCE(sbw1."sale date", sbw2."Cal Date NY") "sale date"
   , COALESCE(sbw1."count_of_trans", 0) "count_of_trans"
   , COALESCE(sbw1."Sum_sales_amt", 0) "Sum_sales_amt"
   , COALESCE(sbw1."Sum_QTY", 0) "Sum_QTY"
   , COALESCE(sbw1."sum_margin", 0) "sum_margin"
   , COALESCE(sbw1."Fin Year", sbw2."NY Fin Year") "Fin Year"
   , COALESCE(sbw1."fin week int", sbw2."NY fin week int") "fin week int"
   , COALESCE(sbw1."Fin Yearweek int", sbw2."NY Fin Yearweek int") "Fin Yearweek int"
   , COALESCE(sbw1."week_number", sbw2."week_number") "week_number"
   , COALESCE(sbw1."weekday int", sbw2."weekday int") "weekday int"
   , COALESCE(sbw1."Cal Date Ly", sbw2."sale date") "Cal Date Ly"
   , COALESCE(sbw1."season identifier", sbw2."NY Season Identifier") "season identifier"
   , COALESCE(sbw1."LY Season Identifier", sbw2."season identifier") "LY Season Identifier"
   , COALESCE(sbw1."LY fin week int", sbw2."fin week int") "LY fin week int"
   , COALESCE(sbw1."LY Fin Year", sbw2."Fin Year") "LY Fin Year"
   , COALESCE(sbw1."Plan Division", sbw2."Plan Division") "Plan Division"
   , COALESCE(sbw1."Plan Division Code", sbw2."Plan Division Code") "Plan Division Code"
   , COALESCE(sbw1."brand", sbw2."brand") "brand"
   , COALESCE(sbw1."plan brand", sbw2."plan brand") "plan brand"
   , COALESCE(sbw1."plan brand code", sbw2."plan brand code") "plan brand code"
   , COALESCE(sbw1."plan channel code", sbw2."plan channel code") "plan channel code"
   , COALESCE(sbw1."plan channel", sbw2."plan channel") "plan channel"
   , COALESCE(sbw1."reporting channel", sbw2."reporting channel") "reporting channel"
   , COALESCE(sbw1."pc_type", sbw2."pc_type") "pc_type"
   FROM
     (sales_by_week sbw1
   FULL JOIN sales_by_week sbw2 ON ((sbw1."store key" = sbw2."store key") AND (sbw1."fin week int" = sbw2."fin week int") AND (sbw1."Fin Year" = (sbw2."Fin Year" + 1)) AND (sbw1."weekday int" = sbw2."weekday int") AND (sbw1."Plan Division Code" = sbw2."Plan Division Code") AND (sbw1."pc_type" = sbw2."pc_type")))
) 
, MAT_sales_by_week AS (
   SELECT
     CAST(sum(sc."Sum_sales_amt") AS decimal(38, 2)) "MAT_Sum_sales_amt"
   , sb."store key"
   , sb."fin week int"
   , sb."weekday int"
   , sb."Plan Division Code"
   , sb."week_number"
   , sb."pc_type"
   FROM
     sales_by_week sb
   , sales_by_week sc
   WHERE ((sc."week_number" < sb."week_number") AND (sc."week_number" >= (sb."week_number" - 53)) AND (sc."store key" = sb."store key") AND (sc."weekday int" = sb."weekday int") AND (sc."Plan Division Code" = sb."Plan Division Code") AND (sc."pc_type" = sb."pc_type"))
   GROUP BY sb."store key", sb."fin week int", sb."weekday int", sb."Plan Division Code", sb."week_number", sb."pc_type"
) 
SELECT
  concat(concat(concat(concat('Plan Division', '&'), rpad(COALESCE(sbw1."pc_type", 'unknown'), 20, ' ')), '%'), rpad(COALESCE(sbw2."pc_type", 'unknown'), 20, ' ')) "Hierarchy"
, sbw1."store key"
, sbw1."Plan Division"
, CAST(sbw1."Plan Division Code" as VARCHAR) "Plan Division Code"
, CAST(CAST(sbw1."sale date" AS VARCHAR) AS DATE) "sale date"
, CAST(sbw1."Cal Date Ly" AS VARCHAR) "Cal Date Ly"
, CAST(CAST(sbw1."Fin Yearweek int" AS VARCHAR)AS BIGINT) "Fin Yearweek int"
, CAST(CAST(sbw1."fin week int" AS VARCHAR) AS BIGINT) "fin week int"
, CAST(CAST(sbw1."Fin Year" AS VARCHAR) AS BIGINT) "Fin Year"
, cp."compstatus"
, sbw1."season identifier" "season id"
, sbw1."Sum_sales_amt"
, sbw1."sum_margin"
, CAST(null AS double) "Sum Of Moto Sales"
, CAST(null AS double) "Sum of ISAMS sales"
, CAST(null AS double) "Sum Non Merch Sales Amt"
, CAST(null AS bigint) "count_of_trans"
, CAST(null AS decimal(38, 4)) "Sum_QTY"
, CAST(null AS double) "ACP"
, CAST(null AS decimal(38, 4)) "UPT"
, sbw1."plan channel code"
, sbw1."plan channel"
, sbw1."reporting channel"
, ms."MAT_Sum_sales_amt"
, sbw1."weekday int"
, sbw1."brand"
, sbw1."plan brand"
, sbw1."plan brand code"
, CAST(null AS bigint) "Store Entries"
, CAST(null AS bigint) "Store Exits"
, cp2."compstatus" "compstatus LY"
, sbw1."LY Season Identifier" "LY seasonid"
, CAST(null AS double) "LY Sum Of Moto Sales"
, CAST(null AS double) "LY Sum of ISAMS sales"
, sbw2."Sum_sales_amt" "LY Sum_sales_amt"
, sbw2."sum_margin" "LY Margin"
, CAST(null AS bigint) "LY count_of_trans"
, CAST(null AS decimal(38, 4)) "LY Sum_QTY"
, CAST(null AS double) "LY ACP"
, CAST(null AS decimal(38, 4)) "LY UPT"
, sbw1."LY fin week int" "LY fin week int"
, sbw1."LY Fin Year" "LY Fin Year"
, CAST(null AS bigint) "LY Store Entries"
, CAST(null AS bigint) "LY Store Exits"
FROM
  ((((sales_ty_ly sbw1
LEFT JOIN MAT_sales_by_week ms ON ((sbw1."store key" = ms."store key") AND (sbw1."fin week int" = ms."fin week int") AND (sbw1."week_number" = ms."week_number") AND (sbw1."weekday int" = ms."weekday int") AND (sbw1."Plan Division Code" = ms."Plan Division Code") AND (sbw1."pc_type" = ms."pc_type")))
LEFT JOIN comp cp ON ((cp."store key" = sbw1."store key") AND (cp."seasonid" = sbw1."season identifier")))
LEFT JOIN sales_by_week sbw2 ON ((sbw1."store key" = sbw2."store key") AND (sbw1."fin week int" = sbw2."fin week int") AND (sbw1."Fin Year" = (sbw2."Fin Year" + 1)) AND (sbw1."weekday int" = sbw2."weekday int") AND (sbw1."Plan Division Code" = sbw2."Plan Division Code") AND (sbw1."pc_type" = sbw2."pc_type")))
LEFT JOIN comp cp2 ON ((cp2."store key" = sbw2."store key") AND (cp2."seasonid" = sbw2."season identifier")))
