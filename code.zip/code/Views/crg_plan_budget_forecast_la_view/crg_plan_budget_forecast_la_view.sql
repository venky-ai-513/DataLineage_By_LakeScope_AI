SELECT
"Sales corporate forecast apportion by day" "Sales_corporate_forecast_apportion_by_day", 
"Sales budget apportion by day" "Sales_budget_apportion_by_day", 
"pcent used" "pcent_used", 
"pcent source" "pcent_source", 
"Store Key" "Store_Key", 
"Division" "Division", 
"Plan Channel Code" "Plan_Channel_Code", 
"Plan Brand" "Plan_Brand", 
"Plan Brand Code" "Plan_Brand_Code", 
"Day of Week" "Day_of_Week", 
"Forecast Date" "Forecast_Date", 
"Weekly Forecast" "Weekly_Forecast", 
"Weekly Budget" "Weekly_Budget", 
"Fin YearMonth" "Fin_YearMonth", 
"Fin YearPeriod Int" "Fin_YearPeriod_Int", 
"Fin YearWeek Int" "Fin_YearWeek_Int", 
"Comp Status" "Comp_Status"
FROM "crg_daas_{env}_business_aligned_db"."crg_plan_budget_forecast_location_apportion_view";