SELECT        
"hierarchy" as "hierarchy",
"store key" as "store_key",
"plan division" as "plan_division",
COALESCE("plan division code",0) as "plan_division_code",
"sale date" as "sale_date",
"LY sale date" as "cal_date_ly",
CAST(COALESCE("fin yearweek int",0) AS VARCHAR) as "fin_yearweek_int",
CAST(COALESCE("fin week int",0) AS VARCHAR) as "fin_week_int",
CAST(COALESCE("fin year",0) AS VARCHAR) as "fin_year",
"compstatus" as "compstatus",
"season identifier" as "season_id",
COALESCE("Sum sales amount excl",0) as "sum_sales_amt",
COALESCE("sum margin",0) as "sum_margin",
COALESCE("sum of moto sales",0) as "sum_of_moto_sales",
COALESCE("sum of isams sales",0) as "sum_of_isams_sales",
COALESCE("sum non merch sales amt",0) as "sum_non_merch_sales_amt",
COALESCE("Number of Transactions",0) as "count_of_trans",
COALESCE("Number of Units",0) as "sum_qty",
COALESCE("acp",0) as "acp",
COALESCE("upt",0) as "upt",
COALESCE("plan channel code",0) as "plan_channel_code",
"plan channel" as "plan_channel",
"reporting channel" as "reporting_channel",
COALESCE("MAT sales amt",0) as "mat_sum_sales_amt",
COALESCE("weekday int",0) as "weekday_int",
"brand" as "brand",
"plan brand" as "plan_brand",
COALESCE("plan brand code",0) as "plan_brand_code",
COALESCE("store entries",0) as "store_entries",
COALESCE("store exits",0) as "store_exits",
"compstatus ly" as "compstatus_ly",
"ly seasonid" as "ly_seasonid",
COALESCE("ly sum of moto sales",0) as "ly_sum_of_moto_sales",
COALESCE("ly sum of isams sales",0) as "ly_sum_of_isams_sales",
COALESCE("LY Sum sales amount excl",0) as "ly_sum_sales_amt",
COALESCE("ly sum margin",0) as "ly_margin",
COALESCE("LY Number of Transactions",0) as "ly_count_of_trans",
COALESCE("LY Number of Units",0) as "ly_sum_qty",
COALESCE("ly acp",0) as "ly_acp",
COALESCE("ly upt",0) as "ly_upt",
COALESCE("ly fin week int",0) as "ly_fin_week_int",
COALESCE("ly fin year",0) as "ly_fin_year",
COALESCE("ly store entries",0) as "ly_store_entries",
COALESCE("ly store exits",0) as "ly_store_exits"
, "Store name" AS "Store_name"
, "Traffic Date" AS "Traffic_Date"
, "currency"
, "duration"
, "Passerby Traffic (Trading Hours)"            AS "Passerby_Traffic_Trading_Hours"
, "Passerby Traffic (Non Trading Hours)"        AS "Passerby_Traffic_Non_Trading_Hours"
, "Total Passerby Traffic"                      AS "Total_Passerby_Traffic"
, "Active Shoppers"                             AS "Active_Shoppers"
, "Shopfront Conversion %"                      AS "Shopfront_Conversion_Pct"
, "Dwell Time"                                  AS "Dwell_Time"
, "Fitting Room Visits"                         AS "Fitting_Room_Visits"
, "Fitting Room Conversion %"                   AS "Fitting_Room_Conversion_Pct"
, "Transactions"                                AS "Transactions"
, "Sales Conversion %"                          AS "Sales_Conversion_Pct"
, "Average Transaction Value"                   AS "Average_Transaction_Value"
, "Average Active Shopper Value"                AS "Average_Active_Shopper_Value"
, "UPT Kepler"                                  AS "UPT_Kepler"
, "Total Sales Kepler"                          AS "Total_Sales_Kepler"
, "Total Sales Target Kepler"                   AS "Total_Sales_Target_Kepler"
, "Total Sales Variance to Target Kepler"       AS "Total_Sales_Variance_to_Target_Kepler"
, "Total Sales % Variance to Target Kepler"     AS "Total_Sales_Pct_Variance_to_Target_Kepler"
, "Bounce Rate (60s) %"                         AS "Bounce_Rate_60s_Pct"
, "Bounce Rate (120s) %"                        AS "Bounce_Rate_120s_Pct"
, "Store name LY" AS "Store_name_LY"
, "Traffic Date LY" AS "Traffic_Date_LY"
, "currency LY" AS "currency_LY"
, "duration LY" AS "duration_LY"
, "Passerby Traffic (Trading Hours) LY"         AS "Passerby_Traffic_Trading_Hours_LY"
, "Passerby Traffic (Non Trading Hours) LY"     AS "Passerby_Traffic_Non_Trading_Hours_LY"
, "Total Passerby Traffic LY"                   AS "Total_Passerby_Traffic_LY"
, "Active Shoppers LY"                          AS "Active_Shoppers_LY"
, "Shopfront Conversion % LY"                   AS "Shopfront_Conversion_Pct_LY"
, "Dwell Time LY"                               AS "Dwell_Time_LY"
, "Fitting Room Visits LY"                      AS "Fitting_Room_Visits_LY"
, "Fitting Room Conversion % LY"                AS "Fitting_Room_Conversion_Pct_LY"
, "Transactions LY"                             AS "Transactions_LY"
, "Sales Conversion % LY"                       AS "Sales_Conversion_Pct_LY"
, "Average Transaction Value LY"                AS "Average_Transaction_Value_LY"
, "Average Active Shopper Value LY"             AS "Average_Active_Shopper_Value_LY"
, "UPT Kepler LY"                               AS "UPT_Kepler_LY"
, "Total Sales Kepler LY"                       AS "Total_Sales_Kepler_LY"
, "Total Sales Target Kepler LY"                AS "Total_Sales_Target_Kepler_LY"
, "Total Sales Variance to Target Kepler LY"    AS "Total_Sales_Variance_to_Target_Kepler_LY"
, "Total Sales % Variance to Target Kepler LY"  AS "Total_Sales_Pct_Variance_to_Target_Kepler_LY"
, "Bounce Rate (60s) % LY"                      AS "Bounce_Rate_60s_Pct_LY"
, "Bounce Rate (120s) % LY"                     AS "Bounce_Rate_120s_Pct_LY"
FROM "crg_daas_{env}_business_aligned_db"."crg_op_store_day_cmb_view"