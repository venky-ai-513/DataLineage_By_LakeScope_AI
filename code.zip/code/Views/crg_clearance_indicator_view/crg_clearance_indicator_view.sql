SELECT
"Rownum2",
"Price_Change",
"Reason",
"Unit_Retail",
"PC_Type",
"PC Start Date"    "PC_Start_Date",
"PC End Date"   "PC_End_Date",
"Sku",
"Sku Key"    "Sku_Key",
"Style",
"Colour",
"Colour_Desc",
"Zone_Group_Id",
"Zone_Id"
FROM "crg_daas_{env}_business_aligned_db"."crg_clearance_indicator_view"