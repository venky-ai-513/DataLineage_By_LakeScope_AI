SELECT
"Total Records" "Total_Records", 
"Store Key" "Store_Key", 
"Sale Date" "Sale_Date", 
"cal date ly" "cal_date_ly", 
"New Sign Up" "New_Sign_Up", 
"Existing Customer" "Existing_Customer", 
"No Customer" "No_Customer", 
"LY Total Records" "LY_Total_Records", 
"LY Store Key" "LY_Store_Key", 
"LY Sale Date" "LY_Sale_Date", 
"LY New Sign Up" "LY_New_Sign_Up", 
"LY Existing Customer" "LY_Existing_Customer", 
"LY No Customer" "LY_No_Customer"
FROM "crg_daas_{env}_business_aligned_db"."crg_sign_up_view";