SELECT
"Plan Channel Code"	"Plan_Channel_Code",
"Division ID"	"Division_ID",
"Fin YearWeek Int"	"Fin_YearWeek_Int",
"Store key"	"Store_key",
"Sales Budget"	"Sales_Budget",
"Sales Budget BGP"	"Sales_Budget_BGP",
"Sales Corporate Forecast"	"Sales_Corporate_Forecast",
"Sales Corporate Forecast BGP"	"Sales_Corporate_Forecast_BGP"
FROM "crg_daas_{env}_business_aligned_db"."crg_plan_budget_forecast_location_view"