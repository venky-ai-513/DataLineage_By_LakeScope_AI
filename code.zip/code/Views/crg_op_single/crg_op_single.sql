SELECT
    "hierarchy",
    "store_key",
    "plan_division",
    "plan_division_code",
    "sale_date",
    "cal_date_ly",
    CAST(CAST("fin_yearweek_int" AS VARCHAR) AS BIGINT) "fin_yearweek_int",
    CAST(CAST("fin_week_int" AS VARCHAR) AS BIGINT) "fin_week_int",
    CAST(CAST("fin_year" AS VARCHAR) AS BIGINT) "fin_year",
    "compstatus",
    "season_id",
    "sum_sales_amt",
    "sum_margin",
    "sum_of_moto_sales",
    "sum_of_isams_sales",
    "sum_non_merch_sales_amt",
    CAST(CAST("count_of_trans" AS VARCHAR) AS BIGINT) "count_of_trans",
    "sum_qty" "sum_qty",
    "acp",
    "upt",
    "plan_channel_code",
    "plan_channel",
    "reporting_channel",
    "mat_sum_sales_amt",
    CAST(CAST("weekday_int" AS VARCHAR) AS BIGINT) "weekday_int",
    "brand",
    "plan_brand",
    "plan_brand_code",
    CAST(CAST("store_entries" AS VARCHAR) AS BIGINT) "store_entries",
    CAST(CAST("store_exits" AS VARCHAR) AS BIGINT) "store_exits",
    "compstatus_ly",
    "ly_seasonid",
    "ly_sum_of_moto_sales",
    "ly_sum_of_isams_sales",
    "ly_sum_sales_amt",
    "ly_margin",
    CAST(CAST("ly_count_of_trans" AS VARCHAR) AS BIGINT) "ly_count_of_trans",
    "ly_sum_qty",
    "ly_acp",
    "ly_upt",
    CAST(CAST("ly_fin_week_int" AS VARCHAR) AS BIGINT) "ly_fin_week_int",
    CAST(CAST("ly_fin_year" AS VARCHAR) AS BIGINT) "ly_fin_year",
    CAST(CAST("ly_store_entries" AS VARCHAR) AS BIGINT) "ly_store_entries",
    CAST(CAST("ly_store_exits" AS VARCHAR) AS BIGINT) "ly_store_exits"
    ,Store_name
    ,Traffic_Date
    ,currency
    ,duration
    ,Passerby_Traffic_Trading_Hours
    ,Passerby_Traffic_Non_Trading_Hours
    ,Total_Passerby_Traffic
    ,Active_Shoppers
    ,Shopfront_Conversion_Pct
    ,Dwell_Time
    ,Fitting_Room_Visits
    ,Fitting_Room_Conversion_Pct
    ,Transactions
    ,Sales_Conversion_Pct
    ,Average_Transaction_Value
    ,Average_Active_Shopper_Value
    ,UPT_Kepler
    ,Total_Sales_Kepler
    ,Total_Sales_Target_Kepler
    ,Total_Sales_Variance_to_Target_Kepler
    ,Total_Sales_Pct_Variance_to_Target_Kepler
    ,Bounce_Rate_60s_Pct
    ,Bounce_Rate_120s_Pct
    ,Store_name_LY
    ,Traffic_Date_LY
    ,currency_LY
    ,duration_LY
    ,Passerby_Traffic_Trading_Hours_LY
    ,Passerby_Traffic_Non_Trading_Hours_LY
    ,Total_Passerby_Traffic_LY
    ,Active_Shoppers_LY
    ,Shopfront_Conversion_Pct_LY
    ,Dwell_Time_LY
    ,Fitting_Room_Visits_LY
    ,Fitting_Room_Conversion_Pct_LY
    ,Transactions_LY
    ,Sales_Conversion_Pct_LY
    ,Average_Transaction_Value_LY
    ,Average_Active_Shopper_Value_LY
    ,UPT_Kepler_LY
    ,Total_Sales_Kepler_LY
    ,Total_Sales_Target_Kepler_LY
    ,Total_Sales_Variance_to_Target_Kepler_LY
    ,Total_Sales_Pct_Variance_to_Target_Kepler_LY
    ,Bounce_Rate_60s_Pct_LY
    ,Bounce_Rate_120s_Pct_LY
FROM "crg_daas_{env}_bamv_db"."crg_op_sales_view_os"
UNION ALL
SELECT
    "hierarchy",
    "store_key",
    "plan_division",
    "plan_division_code",
    "sale_date",
    "cal_date_ly",
    CAST(CAST("fin_yearweek_int" AS VARCHAR) AS BIGINT) "fin_yearweek_int",
    CAST(CAST("fin_week_int" AS VARCHAR) AS BIGINT) "fin_week_int",
    CAST(CAST("fin_year" AS VARCHAR) AS BIGINT) "fin_year",
    "compstatus",
    "season_id",
    "sum_sales_amt",
    "sum_margin",
    "sum_of_moto_sales",
    "sum_of_isams_sales",
    "sum_non_merch_sales_amt",
    CAST(CAST("count_of_trans" AS VARCHAR) AS BIGINT) "count_of_trans",
    "sum_qty" "sum_qty",
    "acp",
    "upt",
    "plan_channel_code",
    "plan_channel",
    "reporting_channel",
    "mat_sum_sales_amt",
    CAST(CAST("weekday_int" AS VARCHAR) AS BIGINT) "weekday_int",
    "brand",
    "plan_brand",
    "plan_brand_code",
    CAST(CAST("store_entries" AS VARCHAR) AS BIGINT) "store_entries",
    CAST(CAST("store_exits" AS VARCHAR) AS BIGINT) "store_exits",
    "compstatus_ly",
    "ly_seasonid",
    "ly_sum_of_moto_sales",
    "ly_sum_of_isams_sales",
    "ly_sum_sales_amt",
    "ly_margin",
    CAST(CAST("ly_count_of_trans" AS VARCHAR) AS BIGINT) "ly_count_of_trans",
    "ly_sum_qty",
    "ly_acp",
    "ly_upt",
    CAST(CAST("ly_fin_week_int" AS VARCHAR) AS BIGINT) "ly_fin_week_int",
    CAST(CAST("ly_fin_year" AS VARCHAR) AS BIGINT) "ly_fin_year",
    CAST(CAST("ly_store_entries" AS VARCHAR) AS BIGINT) "ly_store_entries",
    CAST(CAST("ly_store_exits" AS VARCHAR) AS BIGINT) "ly_store_exits"
    ,Store_name
    ,Traffic_Date
    ,currency
    ,duration
    ,Passerby_Traffic_Trading_Hours
    ,Passerby_Traffic_Non_Trading_Hours
    ,Total_Passerby_Traffic
    ,Active_Shoppers
    ,Shopfront_Conversion_Pct
    ,Dwell_Time
    ,Fitting_Room_Visits
    ,Fitting_Room_Conversion_Pct
    ,Transactions
    ,Sales_Conversion_Pct
    ,Average_Transaction_Value
    ,Average_Active_Shopper_Value
    ,UPT_Kepler
    ,Total_Sales_Kepler
    ,Total_Sales_Target_Kepler
    ,Total_Sales_Variance_to_Target_Kepler
    ,Total_Sales_Pct_Variance_to_Target_Kepler
    ,Bounce_Rate_60s_Pct
    ,Bounce_Rate_120s_Pct
    ,Store_name_LY
    ,Traffic_Date_LY
    ,currency_LY
    ,duration_LY
    ,Passerby_Traffic_Trading_Hours_LY
    ,Passerby_Traffic_Non_Trading_Hours_LY
    ,Total_Passerby_Traffic_LY
    ,Active_Shoppers_LY
    ,Shopfront_Conversion_Pct_LY
    ,Dwell_Time_LY
    ,Fitting_Room_Visits_LY
    ,Fitting_Room_Conversion_Pct_LY
    ,Transactions_LY
    ,Sales_Conversion_Pct_LY
    ,Average_Transaction_Value_LY
    ,Average_Active_Shopper_Value_LY
    ,UPT_Kepler_LY
    ,Total_Sales_Kepler_LY
    ,Total_Sales_Target_Kepler_LY
    ,Total_Sales_Variance_to_Target_Kepler_LY
    ,Total_Sales_Pct_Variance_to_Target_Kepler_LY
    ,Bounce_Rate_60s_Pct_LY
    ,Bounce_Rate_120s_Pct_LY
FROM "crg_daas_{env}_bamv_db"."crg_op_store_day_cmb_view";