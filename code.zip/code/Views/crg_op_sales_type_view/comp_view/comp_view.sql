SELECT DISTINCT
     cal."Season Identifier" AS "seasonid"
   , replace(ps."h1_comp", ' ', '') AS "compstatus"
   , concat('POL - ', ps.number) AS "store_key"
   FROM
     "crg_daas_{env}_daily_sales_manual_uploads_db"."politix_store" ps
   , "crg_daas_{env}_business_aligned_db"."crg_calendar_all_view" cal
   WHERE ((ps."fin_week" = CAST(cal."Fin YearWeek Int" AS varchar)) AND (cal."Weekday Int" = 1))
UNION ALL    SELECT
     scp."seasonid"
   , scp."compstatus"
   , concat('CRG - ', scp."storeid") "store_key"
   FROM
     "crg_daas_{env}_mfpoutbound_db"."storecomp" scp