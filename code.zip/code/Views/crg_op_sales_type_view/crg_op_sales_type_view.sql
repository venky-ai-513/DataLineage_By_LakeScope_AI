WITH
  cal_weeks_number AS (
   SELECT * FROM cal_weeks_number_view
) 
, sales_ty_ly AS (
SELECT
  CAST(CASE WHEN sbw1."store_key" IS NOT NULL THEN sbw1."store_key" ELSE sbw2."store_key"END AS VARCHAR) AS "store_key",
  CASE WHEN sbw1."sale_date" IS NOT NULL THEN sbw1."sale_date" ELSE sbw2."cal_date_ny" END AS "sale_date",
  CASE WHEN sbw1."count_of_trans" IS NOT NULL THEN sbw1."count_of_trans" ELSE 0 END AS "count_of_trans",
  CASE WHEN sbw1."sum_sales_amt" IS NOT NULL THEN sbw1."sum_sales_amt" ELSE 0 END AS "sum_sales_amt",
  CASE WHEN sbw1."sum_qty" IS NOT NULL THEN sbw1."sum_qty" ELSE 0 END AS "Sum_qty",
  CASE WHEN sbw1."sum_margin" IS NOT NULL THEN sbw1."sum_margin" ELSE 0 END AS "sum_margin",
  CAST(CASE WHEN sbw1."fin_year" IS NOT NULL THEN sbw1."fin_year" ELSE sbw2."ny_fin_year" END AS INTEGER) AS "fin_year",
 CAST(CASE WHEN sbw1."fin_week_int" IS NOT NULL THEN sbw1."fin_week_int" ELSE sbw2."ny_fin_week_int" END AS BIGINT) AS "fin_week_int",
  CASE WHEN sbw1."fin_yearweek_int" IS NOT NULL THEN sbw1."fin_yearweek_int" ELSE sbw2."ny_fin_yearweek_int" END AS "fin_yearweek_int",
  CASE WHEN sbw1."week_number" IS NOT NULL THEN sbw1."week_number" ELSE sbw2."week_number" END AS "week_number",
  CAST(CASE WHEN sbw1."weekday_int" IS NOT NULL THEN sbw1."weekday_int" ELSE sbw2."weekday_int" END AS BIGINT) AS "weekday_int",
  CASE WHEN sbw1."cal_date_ly" IS NOT NULL THEN sbw1."cal_date_ly" ELSE sbw2."sale_date" END AS "cal_date_ly",
  CAST(CASE WHEN sbw1."season_identifier" IS NOT NULL THEN sbw1."season_identifier" ELSE sbw2."ny_season_identifier" END AS VARCHAR) AS "season_identifier",
  CASE WHEN sbw1."ly_season_identifier" IS NOT NULL THEN sbw1."ly_season_identifier" ELSE sbw2."season_identifier" END AS "ly_season_identifier",
  CASE WHEN sbw1."ly_fin_week_int" IS NOT NULL THEN sbw1."ly_fin_week_int" ELSE sbw2."fin_week_int" END AS "ly_fin_week_int",
  CASE WHEN sbw1."ly_fin_year" IS NOT NULL THEN sbw1."ly_fin_year" ELSE sbw2."fin_year" END AS "ly_fin_year",
  CASE WHEN sbw1."plan_division" IS NOT NULL THEN sbw1."plan_division" ELSE sbw2."plan_division" END AS "plan_division",
 CASE WHEN sbw1."plan_division_code" IS NOT NULL THEN sbw1."plan_division_code" ELSE sbw2."plan_division_code" END AS "plan_division_code",
  CASE WHEN sbw1."brand" IS NOT NULL THEN sbw1."brand" ELSE sbw2."brand" END AS "brand",
 CASE WHEN sbw1."plan_brand" IS NOT NULL THEN sbw1."plan_brand" ELSE sbw2."plan_brand" END AS "plan_brand",
  CASE WHEN sbw1."plan_brand_code" IS NOT NULL THEN sbw1."plan_brand_code" ELSE sbw2."plan_brand_code" END AS "plan_brand_code",
  CASE WHEN sbw1."plan_channel_code" IS NOT NULL THEN sbw1."plan_channel_code" ELSE sbw2."plan_channel_code" END AS "plan_channel_code",
  CASE WHEN sbw1."plan_channel" IS NOT NULL THEN sbw1."plan_channel" ELSE sbw2."plan_channel" END AS "plan_channel",
  CASE WHEN sbw1."reporting_channel" IS NOT NULL THEN sbw1."reporting_channel" ELSE sbw2."reporting_channel" END AS "reporting_channel",
 CASE WHEN sbw1."pc_type" IS NOT NULL THEN sbw1."pc_type" ELSE sbw2."pc_type" END AS "pc_type"
FROM sales_by_week_view AS sbw1
LEFT JOIN sales_by_week_view AS sbw2 ON 
  sbw1."store_key" = sbw2."store_key" AND 
  sbw1."fin_week_int" = sbw2."fin_week_int" AND
  sbw1."fin_year" = (sbw2."fin_year" + 1) AND
  sbw1."weekday_int" = sbw2."weekday_int" AND
  sbw1."plan_division_code" = sbw2."plan_division_code" AND 
  sbw1."pc_type" = sbw2."pc_type"

UNION 

SELECT
  CAST(CASE WHEN sbw1."store_key" IS NOT NULL THEN sbw1."store_key" ELSE sbw2."store_key" END AS VARCHAR) AS "store_key",
  CASE WHEN sbw1."sale_date" IS NOT NULL THEN sbw1."sale_date" ELSE sbw2."cal_date_ny" END AS "sale_date",
  CASE WHEN sbw1."count_of_trans" IS NOT NULL THEN sbw1."count_of_trans" ELSE 0 END AS "count_of_trans",
  CASE WHEN sbw1."sum_sales_amt" IS NOT NULL THEN sbw1."sum_sales_amt" ELSE 0 END AS "sum_sales_amt",
  CASE WHEN sbw1."sum_qty" IS NOT NULL THEN sbw1."sum_qty" ELSE 0 END AS "sum_qty",
  CASE WHEN sbw1."sum_margin" IS NOT NULL THEN sbw1."sum_margin" ELSE 0 END AS "sum_margin",
  CAST(CASE WHEN sbw1."fin_year" IS NOT NULL THEN sbw1."fin_year" ELSE sbw2."ny_fin_year" END AS INTEGER) AS "fin_year",
  CAST(CASE WHEN sbw1."fin_week_int" IS NOT NULL THEN sbw1."fin_week_int" ELSE sbw2."ny_fin_week_int" END AS BIGINT) AS "fin_week_int",
  CASE WHEN sbw1."fin_yearweek_int" IS NOT NULL THEN sbw1."fin_yearweek_int" ELSE sbw2."ny_fin_yearweek_int" END AS "fin_yearweek_int",
  CASE WHEN sbw1."week_number" IS NOT NULL THEN sbw1."week_number" ELSE sbw2."week_number" END AS "week_number",
  CAST(CASE WHEN sbw1."weekday_int" IS NOT NULL THEN sbw1."weekday_int" ELSE sbw2."weekday_int" END AS BIGINT) "weekday_int",
  CASE WHEN sbw1."cal_date_ly" IS NOT NULL THEN sbw1."cal_date_ly" ELSE sbw2."sale_date" END AS "cal_date_ly",
  CAST(CASE WHEN sbw1."season_identifier" IS NOT NULL THEN sbw1."season_identifier" ELSE sbw2."ny_season_identifier" END AS VARCHAR) AS "season_identifier",
  CASE WHEN sbw1."ly_season_identifier" IS NOT NULL THEN sbw1."ly_season_identifier" ELSE sbw2."season_identifier" END AS "ly_season_identifier",
  CASE WHEN sbw1."ly_fin_week_int" IS NOT NULL THEN sbw1."ly_fin_week_int" ELSE sbw2."fin_week_int" END AS "ly_fin_week_int",
  CASE WHEN sbw1."ly_fin_year" IS NOT NULL THEN sbw1."ly_fin_year" ELSE sbw2."fin_year" END AS "ly_fin_year",
 CASE WHEN sbw1."plan_division" IS NOT NULL THEN sbw1."plan_division" ELSE sbw2."plan_division" END AS "plan_division",
  CASE WHEN sbw1."plan_division_code" IS NOT NULL THEN sbw1."plan_division_code" ELSE sbw2."plan_division_code" END AS "plan_division_code",
  CASE WHEN sbw1."brand" IS NOT NULL THEN sbw1."brand" ELSE sbw2."brand" END AS "brand",
  CASE WHEN sbw1."plan_brand" IS NOT NULL THEN sbw1."plan_brand" ELSE sbw2."plan_brand" END AS "plan_brand",
  CASE WHEN sbw1."plan_brand_code" IS NOT NULL THEN sbw1."plan_brand_code" ELSE sbw2."plan_brand_code" END AS "plan_brand_code",
  CASE WHEN sbw1."plan_channel_code" IS NOT NULL THEN sbw1."plan_channel_code" ELSE sbw2."plan_channel_code" END AS "plan_channel_code",
  CASE WHEN sbw1."plan_channel" IS NOT NULL THEN sbw1."plan_channel" ELSE sbw2."plan_channel" END AS "plan_channel",
  CASE WHEN sbw1."reporting_channel" IS NOT NULL THEN sbw1."reporting_channel" ELSE sbw2."reporting_channel" END AS "reporting_channel",
  CASE WHEN sbw1."pc_type" IS NOT NULL THEN sbw1."pc_type" ELSE sbw2."pc_type" END AS "pc_type"
FROM sales_by_week_view AS sbw2
LEFT JOIN sales_by_week_view AS sbw1 ON 
  sbw1."store_key" = sbw2."store_key" AND 
  sbw1."fin_week_int" = sbw2."fin_week_int" AND  
  sbw1."fin_year" = (sbw2."fin_year" + 1) AND
  sbw1."weekday_int" = sbw2."weekday_int"  AND
  sbw1."plan_division_code" = sbw2."plan_division_code" AND 
  sbw1."pc_type" = sbw2."pc_type"
)
, MAT_sales_by_week AS (
   SELECT
     CAST(sum(sc."sum_sales_amt") AS decimal(38, 2)) AS "mat_sum_sales_amt"
   , CAST(sb."store_key" AS VARCHAR) AS "store_key"
   , CAST(sb."fin_week_int" AS BIGINT) AS "fin_week_int"
   , CAST(sb."weekday_int"AS BIGINT) AS "weekday_int"
   , CAST(sb."plan_division_code"AS INTEGER) AS "plan_division_code"
   , CAST(sb."week_number"AS BIGINT) AS "week_number" 
   , CAST(sb."pc_type"AS VARCHAR) AS "pc_type"
   FROM
     sales_by_week_view sb
   , sales_by_week_view sc
   WHERE ((sc."week_number" < sb."week_number") AND (sc."week_number" >= (sb."week_number" - 53)) AND (sc."store_key" = sb."store_key") AND (sc."weekday_int" = sb."weekday_int") AND (sc."plan_division_code" = sb."plan_division_code") AND (sc."pc_type" = sb."pc_type"))
   GROUP BY sb."store_key", sb."fin_week_int", sb."weekday_int", sb."plan_division_code", sb."week_number", sb."pc_type"
)

SELECT
--  "plan_division" || '&' || SUBSTRING(CONCAT(CASE WHEN sbw1."pc_type" IS NOT NULL THEN sbw1."pc_type" ELSE 'unknown' END, ' '), 1, 20) || '%' || SUBSTRING(CONCAT(CASE WHEN sbw2."pc_type" IS NOT NULL THEN sbw2."pc_type" ELSE 'unknown' END, ' '), 1, 20) AS "hierarchy",
  sbw1."store_key" AS "store_key",
  sbw1."plan_division" AS "plan_Division",
  sbw1."plan_division_code" AS "plan_division_code",
  sbw1."sale_date" AS "sale_date",
  sbw1."cal_date_ly" AS "cal_date_ly",
  sbw1."fin_yearweek_int" AS "fin_yearweek_int",
  sbw1."fin_week_int" AS "fin_week_int",
  sbw1."fin_year" AS "fin_year",
  cp."compstatus" AS "compstatus",
  sbw1."season_identifier" AS "season_id",
  sbw1."sum_sales_amt" AS "sum_sales_amt",
  sbw1."sum_margin" AS "sum_margin",
  CAST(null AS BIGINT) AS "sum_of_moto_sales",
  CAST(null AS BIGINT) AS "sum_of_isams_sales",
  CAST(null AS BIGINT) AS "sum_non_merch_sales_amt",
  CAST(null AS bigint) AS "count_of_trans",
  CAST(null AS FLOAT) AS "sum_qty",
  CAST(null AS BIGINT) AS "acp",
  CAST(null AS FLOAT) AS "upt",
  sbw1."plan_channel_code" AS "plan_channel_code",
  sbw1."plan_channel" AS "plan_channel",
  sbw1."reporting_channel" AS "reporting_channel",
  ms."mat_sum_sales_amt" AS "mat_sum_sales_amt",
  sbw1."weekday_int" AS "weekday_int",
  sbw1."brand" AS "brand",
  sbw1."plan_brand" AS "plan_brand",
  sbw1."plan_brand_code" AS "plan_brand_code",
  CAST(null AS bigint) AS "store_entries",
  CAST(null AS bigint) AS "store_exits",
  cp2."compstatus" AS "compstatus_ly",
  sbw1."ly_season_identifier" AS "ly_seasonid",
  CAST(null AS BIGINT) AS "ly_sum_of_moto_sales",
  CAST(null AS BIGINT) AS "ly_sum_of_isams_sales",
  sbw2."sum_sales_amt" AS "ly_sum_sales_amt",
  sbw2."sum_margin" AS "ly_margin",
  CAST(null AS bigint) AS "ly_count_of_trans",
  CAST(null AS FLOAT) AS "ly_sum_qty",
  CAST(null AS bigint) AS "ly_acp",
  CAST(null AS FLOAT) AS "ly_upt",
  sbw1."ly_fin_week_int" AS "ly_fin_week_int",
  sbw1."ly_fin_year" AS "ly_fin_year",
  CAST(null AS bigint) AS "ly_store_entries",
  CAST(null AS bigint) AS "ly_store_exits"
FROM
  (sales_ty_ly AS sbw1
  LEFT JOIN MAT_sales_by_week AS ms ON (sbw1."store_key" = ms."store_key") AND (sbw1."fin_week_int" = ms."fin_week_int") AND (sbw1."week_number" = ms."week_number") AND (sbw1."weekday_int" = ms."weekday_int") AND (sbw1."plan_division_code" = ms."plan_division_code") AND (sbw1."pc_type" = ms."pc_type")
  LEFT JOIN comp_view AS cp ON ((CAST(cp."store_key" AS VARCHAR) = CAST(sbw1."store_key" AS VARCHAR)) AND (CAST(cp."seasonid" AS VARCHAR) = CAST(sbw1."season_identifier" AS VARCHAR)))
  LEFT JOIN sales_by_week_view AS sbw2 ON ((sbw1."store_key" = sbw2."store_key") AND (sbw1."fin_week_int" = sbw2."fin_week_int") AND (sbw1."fin_year" = (sbw2."fin_year" + 1)) AND (sbw1."weekday_int" = sbw2."weekday_int") AND (sbw1."plan_division_code" = sbw2."plan_division_code") AND (sbw1."pc_type" = sbw2."pc_type"))
  LEFT JOIN comp_view AS cp2 ON ((CAST(cp2."store_key" AS VARCHAR) = CAST(sbw2."store_key" AS VARCHAR)) AND (CAST(cp2."seasonid" AS VARCHAR) = CAST(sbw2."season_identifier" AS VARCHAR))))