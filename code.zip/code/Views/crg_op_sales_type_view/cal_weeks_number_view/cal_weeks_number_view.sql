SELECT
      cal2."cal date" AS "cal_date",
      cal2."weekday int" AS "weekday_int",
      cal2."Fin Year" AS "Fin_Year",
      cal2."fin week int" AS "fin_week_int",
      cal2."Fin Yearweek int" AS "Fin_Yearweek_int",
      cal2."week_number" AS "week_number",
      cal2."season identifier" AS "season_identifier",
      cal_ly."cal date" AS "Cal_Date_LY",
      cal_ly."season identifier" AS "LY_Season_Identifier",
      cal_ly."fin week int" AS "LY_fin_week_int",
      cal_ly."Fin Year" AS "LY_Fin_Year",
      cal_ny."cal date" AS "Cal_Date_NY",
      cal_ny."season identifier" AS "NY_Season_Identifier",
      cal_ny."fin week int" AS "NY_fin_week_int",
      cal_ny."Fin Yearweek int" AS "NY_Fin_Yearweek_int",
      cal_ny."Fin Year" AS "NY_Fin_Year"
   FROM
     (((
      SELECT
        cal."cal date"
      , cal."weekday int"
      , cal."Fin Year"
      , cal."fin week int"
      , cal."Fin Yearweek int"
      , cal."Fin Period"
      , cal."Fin Week of Month Int"
      , cal."season identifier"
      , wknum."week_number"
      FROM
        "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal
      , (
         SELECT
           row_number() OVER (ORDER BY "cal date" ASC) week_number
         , "Fin Yearweek int"
         FROM
           "crg_daas_{env}_business_aligned_db"."crg_calendar_view"
         WHERE ("weekday int" = 1)
      )  wknum
      WHERE (cal."Fin Yearweek int" = wknum."Fin Yearweek int")
   )  cal2
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal_ly ON ((cal2."Fin Period" = cal_ly."Fin Period") AND (cal2."Fin Week of Month Int" = cal_ly."Fin Week of Month Int") AND (cal2."Weekday Int" = cal_ly."Weekday Int") AND (cal2."Fin Year" = (cal_ly."Fin Year" + 1))))
   LEFT JOIN "crg_daas_{env}_business_aligned_db"."crg_calendar_view" cal_ny ON ((cal2."Fin Period" = cal_ny."Fin Period") AND (cal2."Fin Week of Month Int" = cal_ny."Fin Week of Month Int") AND (cal2."Weekday Int" = cal_ny."Weekday Int") AND (cal2."Fin Year" = (cal_ny."Fin Year" - 1))))