SELECT 
"inventoryline_branchno",
"inventoryline_inventorydate",
"inventoryline_sku",
"inventoryline_stockintransit",
"inventoryline_stockonhand",
"inventoryline_weightedaveragecost",
"timestamp"
"inventoryline_statisticalperiod",
"inventoryline_statisticalperiodno"
FROM "crg_daas_{env}_politix_db"."politix_inventory_v"
