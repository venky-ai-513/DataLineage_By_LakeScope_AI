SELECT
  "fore_mnth_seq_no" AS "fore_mnth_seq_no",
  "weekday int" AS "weekday_int",
  "Cal Date" AS "cal_date",
  "store key" AS "store_key",
  "division" AS "division",
  "sum_budget" AS "sum_budget",
  "sum_forecast" AS "sum_forecast",
  "plan channel code" AS "plan_channel_code",
  "Fin YearMonth" AS "fin_yearmonth",
  "Fin YearPeriod Int" AS "fin_yearperiod_int",
  "Fin YearWeek Int" AS "fin_yearweek_int",
  "sum_budget bgp" AS "sum_budget_bgp",
  "sum_forecast bgp" AS "sum_forecast_bgp"
FROM "crg_daas_{env}_business_aligned_db"."crg_plan_budget_forecast_loc_daily_view";