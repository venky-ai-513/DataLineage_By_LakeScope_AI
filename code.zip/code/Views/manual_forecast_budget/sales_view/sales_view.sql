SELECT 
"day_sales_pcent" AS "day_sales_pcent",
"profit_sales_pcent" AS "profit_sales_pcent",
"Fin YearMonth" AS "fin_yearmonth",
"Fin YearPeriod Int" AS "fin_yearperiod_int",
"month_seq_no" AS "month_seq_no",
"weekday int" AS "weekday_int",
"store key" AS "store_key",
"plan division code" AS "plan_division_code",
"plan brand" AS "plan_brand",
"plan brand code" AS "plan_brand_code",
"sales amount" AS "sales_amount",
"profit amount" AS "profit_amount"
FROM "crg_daas_{env}_business_aligned_db"."crg_plan_budget_forecast_salesvalue_view";