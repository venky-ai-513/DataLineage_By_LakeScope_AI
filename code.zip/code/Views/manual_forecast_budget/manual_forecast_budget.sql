SELECT
(Cast("pcent_value" as float) * Cast("sum_forecast" as float) / 100) AS "Sales_corporate_forecast_apportion_by_day",
(Cast("pcent_value" as float) * Cast("sum_budget" as float) / 100) AS "Sales_budget_apportion_by_day",
"pcent_value" "pcent_used",
(CASE WHEN ("pcent_value" IS NULL) THEN 'USE THE CHANNEL DATA' ELSE "pcent_source" END) "pcent_source",
"store_key",
"division",
"plan_channel_code",
"plan_brand",
"plan_brand_code",
"day_of_week",
"cal_date" "Forecast_Date",
"sum_forecast" "Weekly_Forecast",
"sum_budget" "Weekly_Budget",
"fin_yearmonth",
"fin_yearperiod_int",
"fin_yearweek_int",
(Cast("pcent_value" as float) * Cast("sum_forecast_bgp" as float) / 100) AS "Sales_corporate_forecast_bgp_apportion_by_day",
(Cast("pcent_value" as float) * Cast("sum_budget_bgp" as float) / 100) AS "Sales_budget_bgp_apportion_by_day",
"sum_forecast_bgp" "Weekly_Forecast_BGP",
"sum_budget_bgp" "Weekly_Budget_BGP"
FROM
(
SELECT
    (CASE WHEN (BF."fore_mnth_seq_no" > mdp."month_seq_no") THEN mdp."day_sales_pcent" ELSE dp."day_sales_pcent" END) "pcent_value",
    (CASE WHEN (BF."fore_mnth_seq_no" > mdp."month_seq_no") THEN 'MAX used' ELSE 'DAY PCENT used' END) "pcent_source",
    BF."store_key" "store_key",
    BF."division" "division",
    (CASE WHEN (BF."fore_mnth_seq_no" > mdp."month_seq_no") THEN MDP."plan_brand" ELSE DP."plan_brand" END) "plan_brand",
    (CASE WHEN (BF."fore_mnth_seq_no" > mdp."month_seq_no") THEN MDP."plan_brand_code" ELSE DP."plan_brand_code" END) "plan_brand_code",
    BF."plan_channel_code" "plan_channel_code",
    BF."weekday_int" "day_of_week",
    BF."cal_date",
    BF."sum_forecast",
    BF."sum_budget",
    BF."fin_yearmonth",
    BF."fin_yearperiod_int",
    BF."fin_yearweek_int",
    BF."sum_forecast_bgp",
    BF."sum_budget_bgp"
FROM
    loc_daily_view
    BF

LEFT JOIN sales_view dp 
ON 
dp."store_key" = BF."store_key" 
AND dp."fin_yearperiod_int" = BF."fin_yearperiod_int" 
AND dp."weekday_int" = BF."weekday_int" 
AND dp."plan_division_code" = BF."division"

LEFT JOIN (SELECT
    "store_key",
    "day_sales_pcent",
    "weekday_int",
    "plan_division_code",
    "plan_brand",
    "plan_brand_code",
    "month_seq_no"
FROM
    sales_view
WHERE  month_seq_no =  
(SELECT "max"(month_seq_no) FROM sales_view)
) mdp 
ON  mdp."store_key" = BF."store_key" 
AND mdp."weekday_int" = BF."weekday_int"
AND mdp."plan_division_code" = BF."division"
);