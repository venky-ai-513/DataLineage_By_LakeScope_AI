import boto3
import json
import urllib3

SUCCESS = "SUCCESS"
FAILED = "FAILED"

http = urllib3.PoolManager()

def send_response(event, context, response_status, response_data, physical_resource_id=None, no_echo=False):
    """
    Send a response to CloudFormation to indicate the status of the custom resource.
    """
    response_url = event['ResponseURL']

    response_body = {
        'Status': response_status,
        'Reason': 'See the details in CloudWatch Log Stream: ' + context.log_stream_name,
        'PhysicalResourceId': physical_resource_id or context.log_stream_name,
        'StackId': event['StackId'],
        'RequestId': event['RequestId'],
        'LogicalResourceId': event['LogicalResourceId'],
        'NoEcho': no_echo,
        'Data': response_data
    }

    json_response_body = json.dumps(response_body)

    headers = {
        'content-type': '',
        'content-length': str(len(json_response_body))
    }

    try:
        response = http.request(
            'PUT',
            response_url,
            body=json_response_body,
            headers=headers
        )
        print("Status code: ", response.status)
    except Exception as e:
        print("send_response failed executing http.request: ", str(e))

def lambda_handler(event, context):
    """
    Main Lambda handler function.
    """
    try:
        print('Event:', event)
        ecr = boto3.client('ecr')
        repository_name = event['ResourceProperties']['RepositoryName']
        
        if event['RequestType'] == 'Create':
            print(f"Create request received for {repository_name}. No action needed.")
            response_data = {"Message": "Create request received. No action needed."}
            send_response(event, context, SUCCESS, response_data)

        elif event['RequestType'] == 'Update':
            print(f"Update request received for {repository_name}. No action needed.")
            response_data = {"Message": "Update request received. No action needed."}
            send_response(event, context, SUCCESS, response_data)

        elif event['RequestType'] in ['Delete']:
            print(f"Update or Delete request received for {repository_name}")
            try:
                response = ecr.describe_repositories(repositoryNames=[repository_name])
                ecr.delete_repository(repositoryName=repository_name, force=True)
                print(f"Deleted repository: {repository_name}")
                response_data = {"Message": f"Deleted repository: {repository_name}"}
                send_response(event, context, SUCCESS, response_data)
            except ecr.exceptions.RepositoryNotFoundException:
                print(f"Repository {repository_name} does not exist.")
                response_data = {"Message": f"Repository {repository_name} does not exist."}
                send_response(event, context, SUCCESS, response_data)
            except Exception as e:
                print(f"Error deleting repository: {str(e)}")
                response_data = {"Message": f"Error deleting repository: {str(e)}"}
                send_response(event, context, FAILED, response_data)

    except Exception as e:
        print(f"General error: {str(e)}")
        response_data = {"Message": f"General error: {str(e)}"}
        send_response(event, context, FAILED, response_data)
