/* Create an Athena View, given a query string

This Lambda implements a Custom Resource for Cloudformation to create an AWS Athena View.

Properties

	ViewName
		An Athena-compatible name to be used when creating the view. Names
		must start with an ASCII character, consist of letters, numbers,
		and underscores only, and be less than 128 characters long.

		Required: Yes
		Type: String
		Minimum: 1
		Maximum: 128
		Update requires: Replacement

	QueryString
		An Athena-compatible SQL query to use when executing the view.

		Required: Yes
		Type: String
		Minimum: 1
		Maximum: 256K (262144 bytes)
		Update requires: No interruption

Return Values

	Ref
		the implementation returns a cloudformation name-compatible version
		of the view name as the physical resource ID. Underscores in the view
		name are replaced with hyphens, per the name constraints described at
		https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-properties-name.html

	Fn::GetAtt
		ViewName
			The actual name of the Athena view as created, underscores are
			not replaced with hyphens
*/
package main

import (
	"context"
	"errors"
	"fmt"
	"log"
	"os"
	"strings"
	"time"

	"github.com/aws/aws-lambda-go/cfn"
	"github.com/aws/aws-lambda-go/lambda"
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/athena"
	"github.com/mitchellh/mapstructure"
)

/*
Example CFN event (from Lambda console test events):

{
  "RequestType": "Create",
  "ResponseURL": "http://pre-signed-S3-url-for-response",
  "StackId": "arn:aws:cloudformation:ap-southeast-2:123456789012:stack/MyStack/guid",
  "RequestId": "unique id for this create request",
  "ResourceType": "Custom::TestResource",
  "LogicalResourceId": "MyTestResource",
  "ResourceProperties": {
    "StackName": "MyStack",
    "List": [
      "1",
      "2",
      "3"
    ]
  }
}

*/

// The actual properties that we'll be using to create the View
type AthenaViewProperties struct {
	ViewName       string `json:"ViewName"`
	QueryString    string `json:"QueryString"` // should just be "SELECT ..."
	OutputLocation string `json:"OutputLocation"`
	Database       string `json:"Database"`
}

type CreatedViewResponse struct {
	QueryExecutionId string `json:"QueryExecutionId"`
	Status           string `json:"Status"`
	Reason           string `json:"Reason"`
}

type AthenaClient interface {
	StartQueryExecution(*athena.StartQueryExecutionInput) (*athena.StartQueryExecutionOutput, error)
	GetQueryExecution(*athena.GetQueryExecutionInput) (*athena.GetQueryExecutionOutput, error)
}

var globalAthenaClient *athena.Athena

const QUERY_RETRIES int = 5        // how many times to retry a failed query where a permissions error is the cause
const QUERY_BACKOFF_FACTOR int = 2 // double the time between retries each time

// The init function is executed when the handler is loaded, and
// is used to set up once-off things during cold start.
func init() {
	region := os.Getenv("AWS_REGION")
	session, err := session.NewSession(&aws.Config{
		Region: aws.String(region),
	})
	if err != nil {
		log.Fatalln("Could not get session: ", err)
	}
	globalAthenaClient = athena.New(session)
}

func QueryAthena(athenaClient AthenaClient, outputBucketURI, database, query string) (string, error) {
	// Special case, which is horrid: if the status contains a
	// LakeFormation permissions error, retry the query a few times
	// with backoff. There appears to be a latency in permissions
	// actually being applied, so this attempts to cater for that
	// race condition

	var lastError string

	queryBackoff := 1
	for attempt := 0; attempt < QUERY_RETRIES; attempt++ {
		executionInput := &athena.StartQueryExecutionInput{
			QueryExecutionContext: &athena.QueryExecutionContext{
				Database: &database,
			},
			QueryString: &query,
			ResultConfiguration: &athena.ResultConfiguration{
				OutputLocation: &outputBucketURI,
			},
		}

		executionOutput, err := athenaClient.StartQueryExecution(executionInput)

		if err != nil {
			log.Println("ERROR executing athena query: ", err)
			if strings.Contains(err.Error(), "ThrottlingException") {
				lastError = err.Error()
				queryBackoff = queryBackoff * QUERY_BACKOFF_FACTOR
				log.Printf("Detected rate limiting, waiting %d seconds to retry ...\n", queryBackoff)
				time.Sleep(time.Second * time.Duration(queryBackoff))
				continue
			}
		}

		status, err := WaitForQueryCompletion(athenaClient, *executionOutput.QueryExecutionId)

		if err != nil {
			log.Println("Error waiting for query completion: ", err)
			// check the status to see if it was a permissions error
			if strings.Contains(*status.StateChangeReason, "Insufficient Lake Formation permission(s)") {
				lastError = *status.StateChangeReason
				queryBackoff = queryBackoff * QUERY_BACKOFF_FACTOR
				log.Printf("Detected permissions error, waiting %d seconds to retry ...\n", queryBackoff)
				time.Sleep(time.Second * time.Duration(queryBackoff))
				continue
			}
			return "", err
		}

		return *executionOutput.QueryExecutionId, nil
	}
	log.Printf("Exceeded max number of query retries, failing; last error: %s\n", lastError)
	return "", fmt.Errorf("Max number of query retries exceeded; last error: %s", lastError)
}

func CreateOrUpdateAthenaView(athenaClient AthenaClient, props AthenaViewProperties) (CreatedViewResponse, error) {
	log.Println("Creating or updating Athena view:", props.ViewName)
	createQuery := "CREATE OR REPLACE VIEW " + props.ViewName + " AS " + props.QueryString
	queryId, err := QueryAthena(
		athenaClient,
		props.OutputLocation,
		props.Database,
		createQuery,
	)

	if err != nil {
		return CreatedViewResponse{
			Status: "FAILED",
			Reason: err.Error(),
		}, err
	}

	return CreatedViewResponse{
		QueryExecutionId: queryId,
		Status:           "SUCCEEDED",
		Reason:           "Success",
	}, nil
}

func DeleteAthenaView(athenaClient AthenaClient, props AthenaViewProperties) (CreatedViewResponse, error) {
	log.Println("Deleting Athena view:", props.ViewName)
	deleteQuery := "DROP VIEW IF EXISTS " + props.ViewName
	queryId, err := QueryAthena(
		athenaClient,
		props.OutputLocation,
		props.Database,
		deleteQuery,
	)

	if err != nil {
		return CreatedViewResponse{
			Status: "FAILED",
			Reason: err.Error(),
		}, err
	}

	return CreatedViewResponse{
		QueryExecutionId: queryId,
		Status:           "SUCCEEDED",
	}, nil
}

func WaitForQueryCompletion(athenaClient AthenaClient, queryId string) (*athena.QueryExecutionStatus, error) {
	log.Println("Query " + queryId + " submitted, waiting for completion ...")
	for {
		status, err := CheckRunningAthenaQuery(athenaClient, queryId)
		if err != nil {
			log.Println("Error checking running query:", err)
			return nil, err
		}
		switch *status.State {
		case "FAILED":
			log.Printf("Query %s has FAILED: %+v\n", queryId, status)
			return status, errors.New("Query failed: " + *status.StateChangeReason)
		case "CANCELLED":
			log.Printf("Query %s has been CANCELLED: %+v\n", queryId, status)
			return status, errors.New("Query cancelled: " + *status.StateChangeReason)
		case "SUCCEEDED":
			log.Printf("Query %s has COMPLETED: %+v\n", queryId, status)
			return status, nil
		default:
			log.Printf("Query %s has status : %+v\n", queryId, status)
			time.Sleep(time.Second * 1)
		}
	}
}

func CheckRunningAthenaQuery(athenaClient AthenaClient, queryId string) (*athena.QueryExecutionStatus, error) {
	queryInput := &athena.GetQueryExecutionInput{
		QueryExecutionId: &queryId,
	}
	queryOutput, err := athenaClient.GetQueryExecution(queryInput)
	if err != nil {
		return nil, err
	}

	return queryOutput.QueryExecution.Status, nil
}

// The Handler must return (string, map[string]interface{}, error) in order to be
// compatible with LambdaWrap
func Handler(ctx context.Context, cfnEvent cfn.Event) (string, map[string]interface{}, error) {
	response := make(map[string]interface{})
	var result CreatedViewResponse
	var err error

	log.Printf("Got a CFN event: %+v\n", cfnEvent)

	// While LambdaWrap is handy, it presents us with the cfnEvent containing a map[string]interface{}
	// which is annoying, so we convert it to our specific type

	var resourceProperties AthenaViewProperties
	mapstructure.Decode(cfnEvent.ResourceProperties, &resourceProperties)
	var physicalResourceId = strings.Replace(resourceProperties.ViewName, "_", "-", -1)

	switch cfnEvent.RequestType {
	case cfn.RequestCreate:
		result, err = CreateOrUpdateAthenaView(globalAthenaClient, resourceProperties)
	case cfn.RequestUpdate:
		result, err = CreateOrUpdateAthenaView(globalAthenaClient, resourceProperties)
	case cfn.RequestDelete:
		result, err = DeleteAthenaView(globalAthenaClient, resourceProperties)
	default:
		log.Fatalf("Cannot proceed: don't know how to handle request type %s\n", cfnEvent.RequestType)
	}

	response["QueryExecutionId"] = result.QueryExecutionId
	response["Status"] = result.Status
	response["Reason"] = result.Reason
	response["PhysicalResourceId"] = physicalResourceId

	// Add in the Fn::GetAtt elements
	response["ViewName"] = resourceProperties.ViewName

	if err != nil {
		log.Println("Error processing request:", err)
		log.Printf("Returning response %+v\n", response)
		return physicalResourceId, response, err
	}

	log.Printf("Returning physical resource ID %s\nresponse %# v\n", physicalResourceId, response)

	return physicalResourceId, response, err
}

func main() {
	log.Println("Athena View Creator custom resource")
	lambda.Start(cfn.LambdaWrap(Handler))
}
