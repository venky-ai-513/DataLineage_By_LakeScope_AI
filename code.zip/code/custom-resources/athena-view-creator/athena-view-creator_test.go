package main

import (
	"github.com/aws/aws-sdk-go/service/athena"
	"github.com/stretchr/testify/assert"
	"testing"
	"time"
)

type testAthenaClient struct {
	startOutput *athena.StartQueryExecutionOutput
	getOutput   *athena.GetQueryExecutionOutput
	err         error
}

func (ac *testAthenaClient) StartQueryExecution(*athena.StartQueryExecutionInput) (*athena.StartQueryExecutionOutput, error) {
	return ac.startOutput, ac.err
}

func (ac *testAthenaClient) GetQueryExecution(*athena.GetQueryExecutionInput) (*athena.GetQueryExecutionOutput, error) {
	return ac.getOutput, ac.err
}

type FakeError struct {
	message string
}

func (fe *FakeError) Error() string {
	return fe.message
}

func TestDeleteView(t *testing.T) {
	fakeExecutionId := "abcd-1234-abcd-1234"
	props := AthenaViewProperties{
		ViewName:       "testView",
		QueryString:    "SELECT * FROM banana",
		OutputLocation: "s3://somewhere/",
		Database:       "db_name_here",
	}

	state := "SUCCEEDED"

	ac := &testAthenaClient{
		startOutput: &athena.StartQueryExecutionOutput{
			QueryExecutionId: &fakeExecutionId,
		},
		getOutput: &athena.GetQueryExecutionOutput{
			QueryExecution: &athena.QueryExecution{
				QueryExecutionId: &fakeExecutionId,
				Status: &athena.QueryExecutionStatus{
					State: &state,
				},
			},
		},
	}

	response, err := DeleteAthenaView(ac, props)

	assert.Nil(t, err, "Should be no errors")
	assert.Equal(t, response.QueryExecutionId, fakeExecutionId, "response should return execution ID "+fakeExecutionId)
}

func TestLongRunningQuery(t *testing.T) {
	fakeExecutionId := "abcd-1234-abcd-1234"
	props := AthenaViewProperties{
		ViewName:       "testView",
		QueryString:    "SELECT * FROM banana",
		OutputLocation: "s3://somewhere/",
		Database:       "db_name_here",
	}

	state := "QUEUED"

	ac := &testAthenaClient{
		startOutput: &athena.StartQueryExecutionOutput{
			QueryExecutionId: &fakeExecutionId,
		},
		getOutput: &athena.GetQueryExecutionOutput{
			QueryExecution: &athena.QueryExecution{
				QueryExecutionId: &fakeExecutionId,
				Status: &athena.QueryExecutionStatus{
					State: &state,
				},
			},
		},
	}

	// run a goroutine to switch the client to different states after some
	// time to validate the poll/wait logic
	// Since we poll every 5 seconds, this should set the state after the second poll
	go func(client *testAthenaClient) {
		t.Log("Waiting 2 seconds to set state to SUCCEEDED")
		time.Sleep(time.Second * 2)
		t.Log("Setting state to SUCCEEDED")
		*client.getOutput.QueryExecution.Status.State = "SUCCEEDED"
	}(ac)

	response, err := CreateOrUpdateAthenaView(ac, props)

	assert.Nil(t, err, "Should be no errors")
	assert.Equal(t, response.QueryExecutionId, fakeExecutionId, "response should return execution ID "+fakeExecutionId)
}

func TestCreateView(t *testing.T) {
	fakeExecutionId := "abcd-1234-abcd-1234"
	props := AthenaViewProperties{
		ViewName:       "testView",
		QueryString:    "SELECT * FROM banana",
		OutputLocation: "s3://somewhere/",
		Database:       "db_name_here",
	}

	state := "SUCCEEDED"

	ac := &testAthenaClient{
		startOutput: &athena.StartQueryExecutionOutput{
			QueryExecutionId: &fakeExecutionId,
		},
		getOutput: &athena.GetQueryExecutionOutput{
			QueryExecution: &athena.QueryExecution{
				QueryExecutionId: &fakeExecutionId,
				Status: &athena.QueryExecutionStatus{
					State: &state,
				},
			},
		},
	}

	response, err := CreateOrUpdateAthenaView(ac, props)

	assert.Nil(t, err, "Should be no errors")
	assert.Equal(t, response.QueryExecutionId, fakeExecutionId, "response should return execution ID "+fakeExecutionId)
}

func TestCheckRunningQuery(t *testing.T) {
	t.Log("Testing check running query")
	fakeExecutionId := "abcd-1234-abcd-1234"
	state := "BANANA"
	ac := &testAthenaClient{
		getOutput: &athena.GetQueryExecutionOutput{
			QueryExecution: &athena.QueryExecution{
				QueryExecutionId: &fakeExecutionId,
				Status: &athena.QueryExecutionStatus{
					State: &state,
				},
			},
		},
	}

	response, err := CheckRunningAthenaQuery(ac, fakeExecutionId)
	assert.Equal(t, *response.State, "BANANA", "Should have the expected state")
	assert.Nil(t, err, "Should be no error response")
}
