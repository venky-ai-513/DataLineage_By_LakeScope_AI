module bitbucket.org/country-road-group/crg-business-aligned-athena-views/materialized-views/custom-resources/athena-view-creator

go 1.15

require (
	github.com/aws/aws-lambda-go v1.20.0
	github.com/aws/aws-sdk-go v1.36.5
	github.com/mitchellh/mapstructure v1.4.0
	github.com/stretchr/testify v1.6.1
)
