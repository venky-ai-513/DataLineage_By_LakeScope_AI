#!/usr/bin/env python
"""
Custom image copier cfn response module.

This function implements a custom resource for CloudFormation
that copies a Docker image from one repository to another.
It assumes that all required authentication tokens are
provided automatically via environment variables, and makes
use of "skopeo" to do the actual copying

Example cloudformation Create request:
{
 "RequestType": "Create",
 "ResponseURL": "http://pre-signed-S3-url-for-response",
 "StackId": "arn:aws:cloudformation:us-east-1:123456789012:stack/MyStack/guid",
 "RequestId": "unique id for this create request",
 "ResourceType": "Custom::TestResource",
 "LogicalResourceId": "MyTestResource",
 "ResourceProperties": {
   "StackName": "MyStack",
   "List": [
     "1",
     "2",
     "3"
   ]
 }
}
"""

# pylint: skip-file

# This copied from https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/cfn-lambda-function-code-cfnresponsemodule.html
# --- begin copy and paste ---
# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0

import urllib3
import json

SUCCESS = "SUCCESS"
FAILED = "FAILED"

http = urllib3.PoolManager()


def send(
    event,
    context,
    responseStatus,
    responseData,
    physicalResourceId=None,
    noEcho=False,
    reason=None,
):
    """cfn-response module copied from above url."""
    responseUrl = event["ResponseURL"]

    print(responseUrl)

    responseBody = {
        "Status": responseStatus,
        "Reason": reason
        or "See the details in CloudWatch Log Stream: {}".format(
            context.log_stream_name
        ),
        "PhysicalResourceId": physicalResourceId or context.log_stream_name,
        "StackId": event["StackId"],
        "RequestId": event["RequestId"],
        "LogicalResourceId": event["LogicalResourceId"],
        "NoEcho": noEcho,
        "Data": responseData,
    }

    json_responseBody = json.dumps(responseBody)

    print("Response body:")
    print(json_responseBody)

    headers = {
        "content-type": "",
        "content-length": str(len(json_responseBody)),
    }

    try:
        response = http.request(
            "PUT", responseUrl, headers=headers, body=json_responseBody
        )
        print("Status code:", response.status)

    except Exception as e:

        print("send(..) failed executing http.request(..):", e)


# --- end copy and paste ---

import base64
import os
import subprocess

import boto3

region = os.getenv("AWS_REGION")
ecr = boto3.client("ecr")


class ECRClient:
    """ECR client class."""

    def __init__(self, repo, image, tag):
        self.repo = repo
        self.image = image
        self.tag = tag
        self.registry_id = self.repo.split(".")[0]
        self.creds = ""
        self.registry = ""

    def authenticate(self):
        """ECR authentication function."""
        print(f"Getting authentication token for registry {self.registry_id}")
        token = ecr.get_authorization_token(registryIds=[self.registry_id])

        print(f"token: {token}")
        self.registry = token["authorizationData"][0]["proxyEndpoint"]

        # We need to decode the token to get the username and password pair
        self.creds = base64.standard_b64decode(
            token["authorizationData"][0]["authorizationToken"]
        ).decode("utf-8")
        
    def image_name(self):
        """Return ECR image name."""
        if ":" in self.image:
            return f"{self.repo}/{self.image}"

        return f"{self.repo}/{self.image}:{self.tag}"

    def get_creds(self):
        """Return ECR credentials."""
        return self.creds


def copy_image(src, dest):
    """Use skopeo binary file to copy ecr images."""
    cmd = [
        "./skopeo",
        "--debug",
        "--insecure-policy",
        "copy",
        "--src-creds",
        src.get_creds(),
        "--dest-creds",
        dest.get_creds(),
        f"docker://{src.image_name()}",
        f"docker://{dest.image_name()}",
    ]
    print(f"Executing: {cmd}")

    # pylint: disable=subprocess-run-check
    copier = subprocess.run(cmd, capture_output=True)
    if copier.returncode != 0:
        return copier.stderr.decode("utf-8"), False

    return dest.image_name(), True


def lambda_handler(event, context):
    """Lambda handler to copy image from source location to dest location."""
    print(f"Received event: {event}")

    if "RequestType" not in event:
        print("Cannot understand received event, exiting")
        msg = "Cannot process received event"
        send(event, context, "FAILED", {}, None, None, msg)
        return

    if event["RequestType"] == "Delete":
        print(f"Not processing a Delete event: {event['RequestType']}")
        msg = "Don't need to process delete"
        send(event, context, "SUCCESS", {}, None, None, msg)
        return

    source_tag = event["ResourceProperties"].get("DockerTag")
    source_account = event["ResourceProperties"].get("SourceAccount")
    image_name = event["ResourceProperties"].get("ImageName")
    dest_account = event["ResourceProperties"].get("DestAccount")

    if not all([source_tag, source_account, image_name, dest_account]):
        msg = (
            "Missing parameters: "
            + f"source_tag={source_tag}"
            + f"source_account={source_account}"
            + f"image_name={image_name}"
            + f"dest_account={dest_account}"
        )
        send(event, context, "FAILED", {}, None, None, msg)
        return

    src = ECRClient(
        f"{source_account}.dkr.ecr.{region}.amazonaws.com",
        image_name,
        source_tag,
    )

    dest = ECRClient(
        f"{dest_account}.dkr.ecr.{region}.amazonaws.com",
        image_name,
        source_tag,
    )

    try:
        src.authenticate()
    except Exception as e:
        msg = f"Could not authenticate to source repo: {e}"
        send(event, context, "FAILED", {}, None, None, msg)
        return

    try:
        dest.authenticate()
    except Exception as e:
        msg = f"Could not authenticate to destination repo: {e}"
        send(event, context, "FAILED", {}, None, None, msg)
        return

    response, ok = copy_image(src, dest)
    if not ok:
        msg = f"Could not copy image: {response}"
        send(event, context, "FAILED", {}, None, None, msg)
        return

    send(event, context, "SUCCESS", {}, response, None, "Copied image")
