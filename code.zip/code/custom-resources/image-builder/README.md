# Image copier

This Lambda is a custom resource responsible for copying a Docker
image from one ECR repository to another. It makes use of
[skopeo](https://github.com/containers/skopeo) to do so, which
can stream the image from one repo to another without having
to save it locally.

To build a new `skopeo` binary for this repo:

1. Clone the [skopeo](https://github.com/containers/skopeo) repo somewhere on a Linux machine
1. Install development dependencies (this might require trying to build it, seeing how it fails,
   and installing additional dependencies each time; alternatively, you could try reading the
   instructions
1. Build a statically-linked binary using the following command:
    ```shell
    GOOS=linux CGO_ENABLED=0 EXTRA_LDFLAGS="-w" DISABLE_CGO=1 make bin/skopeo
    ```
1. Copy the resulting `bin/skopeo` binary into the current directory.
