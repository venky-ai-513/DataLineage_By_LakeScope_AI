package main

// import "encoding/json"

type DMSSNSPayload struct {
	EventId                      string			`json:"Event ID"`
	IdentifierLink               string			`json:"Identifier Link"`
	EventTime                    string			`json:"Event Time"`
	EventSource                  string			`json:"Event Source"`
	SourceId                     string			`json:"SourceId"`
	EventMessage                 string			`json:"Event Message"`
}
