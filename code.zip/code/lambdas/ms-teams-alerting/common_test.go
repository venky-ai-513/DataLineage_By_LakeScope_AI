package main

import (
	"bytes"
	"encoding/json"
	"io/ioutil"
)

func LoadTestEvent(filename string) *json.RawMessage {
	eventBytes, err := ioutil.ReadFile(filename)
	if err != nil {
		panic(err)
	}

	var raw json.RawMessage = eventBytes

	return &raw
}

func readLogBuffer(buffer *bytes.Buffer) string {
	logBytes := make([]byte, buffer.Len())
	buffer.Read(logBytes)
	return string(logBytes)
}
