package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"log"
	"net/http"
	"os"

	"github.com/aws/aws-lambda-go/lambda"
)

type HTTPClient interface {
	Post(url, contentType string, body io.Reader) (resp *http.Response, err error)
}

type Notifier struct {
	webhookUrl string
	httpClient HTTPClient
	logger     *log.Logger
}

func main() {
	notifier := &Notifier{
		webhookUrl: os.Getenv("TEAMS_ALERTING_WEBHOOKSURL"),
		httpClient: &http.Client{},
		logger:     log.New(os.Stdout, "", log.LstdFlags),
	}

	lambda.Start(notifier.HandleEvent)
}

func (n *Notifier) HandleEvent(event *json.RawMessage) error {
	// Attempt to unmarshal the incoming event as different types
	// n.logger.Printf("EVENT: %s\n", event)
	handled, err := n.AttemptEventBridgeEvent(event)
	if err != nil {
		return err
	}
	if handled {
		return nil
	}

	handled, err = n.AttemptDMSSubscriptionEvent(event)
	if err != nil {
		return err
	}
	if handled {
		return nil
	}

	handled, err = n.AttemptAppFLowSubscriptionEvent(event)
	if err != nil {
		return err
	}
	if handled {
		return nil
	}

	handled, err = n.AttemptCloudWatchAlarmEvent(event)
	if err != nil {
		return err
	}
	if handled {
		return nil
	}

	n.logger.Printf("Cannot determine how to process event: %# v\n", string(*event))
	return nil
}

func (n *Notifier) AttemptEventBridgeEvent(event *json.RawMessage) (bool, error) {
	ebevent, err := UnmarshalEventbridge(event)
	if err != nil {
		return false, err
	}

	// this was not an ebevent, so it hasn't been handled yet
	if ebevent == nil {
		return false, nil
	}

	// the event isn't one we want to send, but it was a valid eventbridge event
	// so we don't need to process any further
	if !ebevent.IsSendable() {
		return true, nil
	}

	card, err := ebevent.CreateMessageCard()
	if err != nil {
		return true, err
	}
	return true, n.SendNotification(card)
}

func (n *Notifier) AttemptCloudWatchAlarmEvent(event *json.RawMessage) (bool, error) {
	cwevent, err := UnmarshalCloudwatchAlarm(event)
	if err != nil {
		return false, err
	}

	if cwevent == nil {
		return false, nil
	}

	if !cwevent.IsSendable() {
		return true, nil
	}

	card, err := cwevent.CreateMessageCard()
	if err != nil {
		return true, err
	}
	return true, n.SendNotification(card)
}

func (n *Notifier) AttemptDMSSubscriptionEvent(event *json.RawMessage) (bool, error) {
	dmsevent, err := UnmarshalDMSSNSEvent(event)
	if err != nil {
		return false, err
	}

	if dmsevent == nil {
		return false, nil
	}

	if !dmsevent.IsSendable() {
		return true, nil
	}

	card, err := dmsevent.CreateMessageCard()
	if err != nil {
		return true, err
	}
	return true, n.SendNotification(card)
}

func (n *Notifier) AttemptAppFLowSubscriptionEvent(event *json.RawMessage) (bool, error) {
	appflowevent, err := UnmarshalAppFlowSNSEvent(event)
	if err != nil {
		return false, err
	}

	if appflowevent == nil {
		return false, nil
	}

	if !appflowevent.IsSendable() {
		return true, nil
	}

	card, err := appflowevent.CreateMessageCard()
	if err != nil {
		return true, err
	}
	return true, n.SendNotification(card)
}


func (n *Notifier) SendNotification(card *MessageCard) error {
	// n.logger.Printf("Notification to Post: %v\n", card)
	body, err := card.FormatMessage()
	if err != nil {
		n.logger.Printf("Error formatting message: %v\n", err)
		return err
	}

	resp, err := n.httpClient.Post(n.webhookUrl, "application/json", bytes.NewBuffer(body))
	if err != nil {
		n.logger.Printf("Could not POST message: %v\n", err)
		return err
	}

	if resp.StatusCode != http.StatusOK {
		n.logger.Printf("Received unexpected response from Teams: %# v\n", resp)
		return errors.New("unexpected response from Teams")
	}

	return nil
}
