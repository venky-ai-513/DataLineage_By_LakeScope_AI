package main

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestUnmarshalAppFlowSNSEvent(t *testing.T) {
	t.Run("it correctly unmarshals a Appflow SNS event", func(t *testing.T) {
		// arrange
		testMsg := LoadTestEvent("testdata/sns-alert-appflow.json")

		// act
		event, err := UnmarshalAppFlowSNSEvent(testMsg)

		// assert
		assert.NoError(t, err)
		assert.Equal(t, "crg-dev-Asset-DataLake-Incremental-Flow", event.Records[0].SNS.Message.Detail.FlowName)
	})
}

func TestAppFlowEventSendability(t *testing.T) {
	t.Run("it marks all events as sendable", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-appflow.json")

		event, _ := UnmarshalAppFlowSNSEvent(testMsg)
		sendable := event.IsSendable()

		assert.True(t, sendable)
	})
}

func TestCreateAppFlowEventMessageCard(t *testing.T) {
	t.Run("it creates a message card", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-appflow.json")

		event, _ := UnmarshalAppFlowSNSEvent(testMsg)
		card, err := event.CreateMessageCard()

		assert.NoError(t, err)
		assert.NotNil(t, card)
	})
}
