package main

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestUnmarshalCloudWatchAlarm(t *testing.T) {
	t.Run("it correctly unmarshals a cloudwatch SNS alarm event", func(t *testing.T) {
		// arrange
		testMsg := LoadTestEvent("testdata/sns-alert-single.json")

		// act
		event, err := UnmarshalCloudwatchAlarm(testMsg)

		// assert
		assert.NoError(t, err)
		assert.Equal(t, "djrms-stepfunction-fail-a", event.Records[0].SNS.Message.AlarmName)
	})

	t.Run("it correctly returns nil unmarshalling a non-cloudwatch SNS alarm event", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/eventbridge-event.json")

		event, err := UnmarshalCloudwatchAlarm(testMsg)

		assert.NoError(t, err)
		assert.Nil(t, event)
	})

	t.Run("it correctly fails unmarshalling a badly-formatted quoted JSON string", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-single-bad-message.json")

		event, err := UnmarshalCloudwatchAlarm(testMsg)

		assert.Error(t, err)
		assert.Nil(t, event)
	})
}

func TestSendability(t *testing.T) {
	t.Run("it marks all events as sendable", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-single.json")

		event, _ := UnmarshalCloudwatchAlarm(testMsg)
		sendable := event.IsSendable()

		assert.True(t, sendable)
	})
}

func TestCreateMessageCard(t *testing.T) {
	t.Run("it creates a message card", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-single.json")

		event, _ := UnmarshalCloudwatchAlarm(testMsg)
		card, err := event.CreateMessageCard()

		assert.NoError(t, err)
		assert.NotNil(t, card)
	})

	t.Run("it returns an error when parsing a bad time", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-single-bad-time.json")

		event, _ := UnmarshalCloudwatchAlarm(testMsg)

		card, err := event.CreateMessageCard()

		assert.Error(t, err)
		assert.Nil(t, card)
		assert.Contains(t, err.Error(), "cannot parse")
	})

	t.Run("it chooses the correct colour for an ALARM card", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-single.json")

		event, _ := UnmarshalCloudwatchAlarm(testMsg)

		card, err := event.CreateMessageCard()

		assert.NoError(t, err)
		assert.NotNil(t, card)
		assert.Equal(t, COLOR_ALARM, card.ThemeColor)
	})

	t.Run("it chooses the correct colour for an INSUFFICIENT_DATA card", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-single-insufficient.json")

		event, _ := UnmarshalCloudwatchAlarm(testMsg)

		card, err := event.CreateMessageCard()

		assert.NoError(t, err)
		assert.NotNil(t, card)
		assert.Equal(t, COLOR_INSUFFICIENT_DATA, card.ThemeColor)
	})

	t.Run("it chooses the correct colour for an OK card", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-single-ok.json")

		event, _ := UnmarshalCloudwatchAlarm(testMsg)

		card, err := event.CreateMessageCard()

		assert.NoError(t, err)
		assert.NotNil(t, card)
		assert.Equal(t, COLOR_OK, card.ThemeColor)
	})

	t.Run("it returns an error for an unknown alarm state", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-single-unknown-state.json")

		event, _ := UnmarshalCloudwatchAlarm(testMsg)

		card, err := event.CreateMessageCard()

		assert.Error(t, err)
		assert.Nil(t, card)
		assert.Contains(t, err.Error(), "Received unknown status value for alarm:")
	})

	t.Run("it handles parsing an out of range hour", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-single-time-bad-hour.json")

		event, _ := UnmarshalCloudwatchAlarm(testMsg)

		card, err := event.CreateMessageCard()

		assert.NoError(t, err)
		assert.NotNil(t, card)
		assert.Contains(t, card.Summary, "2022-02-28T19:43:43.280+0000")
	})

	t.Run("it correctly parses the alarm region from the alarm ARN", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-single.json")

		event, _ := UnmarshalCloudwatchAlarm(testMsg)

		card, err := event.CreateMessageCard()

		assert.NoError(t, err)
		assert.NotNil(t, card)
		assert.Equal(t, card.Sections[0].Facts[1].Value, "ap-southeast-2")
	})
}
