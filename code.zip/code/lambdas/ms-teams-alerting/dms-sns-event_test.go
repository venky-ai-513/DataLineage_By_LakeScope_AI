package main

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestUnmarshalDMSSNSEvent(t *testing.T) {
	t.Run("it correctly unmarshals a cloudwatch SNS alarm event", func(t *testing.T) {
		// arrange
		testMsg := LoadTestEvent("testdata/sns-alert-replication-task.json")

		// act
		event, err := UnmarshalDMSSNSEvent(testMsg)

		// assert
		assert.NoError(t, err)
		assert.Equal(t, "dms-djrms-alloc-detail", event.Records[0].SNS.Message.SourceId)
	})

	// t.Run("it correctly returns nil unmarshalling a non-cloudwatch SNS alarm event", func(t *testing.T) {
	// 	testMsg := LoadTestEvent("testdata/eventbridge-event.json")

	// 	event, err := UnmarshalCloudwatchAlarm(testMsg)

	// 	assert.NoError(t, err)
	// 	assert.Nil(t, event)
	// })

	// t.Run("it correctly fails unmarshalling a badly-formatted quoted JSON string", func(t *testing.T) {
	// 	testMsg := LoadTestEvent("testdata/sns-alert-single-bad-message.json")

	// 	event, err := UnmarshalCloudwatchAlarm(testMsg)

	// 	assert.Error(t, err)
	// 	assert.Nil(t, event)
	// })
}

func TestDMSSendability(t *testing.T) {
	t.Run("it marks all events as sendable", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-replication-task.json")

		event, _ := UnmarshalDMSSNSEvent(testMsg)
		sendable := event.IsSendable()

		assert.True(t, sendable)
	})
}

func TestCreateDMSMessageCard(t *testing.T) {
	t.Run("it creates a message card", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/sns-alert-replication-task.json")

		event, _ := UnmarshalDMSSNSEvent(testMsg)
		card, err := event.CreateMessageCard()

		assert.NoError(t, err)
		assert.NotNil(t, card)
	})
}
