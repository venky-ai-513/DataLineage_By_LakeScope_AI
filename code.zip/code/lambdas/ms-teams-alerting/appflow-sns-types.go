package main

import (
	// "encoding/json"
	// "time"
)

type AppFlowEventDetail struct {
	FlowName		string	`json:"flow-name"`
	FlowARN			string	`json:"flow-arn"`
	SourceObject	string	`json:"source-object"`
	TriggerType		string	`json:"trigger-type"`
	DataProcessed	string	`json:"data-processed"`
	Status			string	`json:"status"`
}

type AppFlowSNSPayload struct {
	Account			string				`json:"account"`
	DetailType		string				`json:"detail-type"`
	EventSource		string				`json:"source"`
	EventTime		string				`json:"time"`
	Resources		[]string			`json:"resources"`
	Detail			AppFlowEventDetail	`json:"detail"`
}
