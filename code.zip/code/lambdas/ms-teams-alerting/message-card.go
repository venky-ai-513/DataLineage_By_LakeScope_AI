package main

import (
	"encoding/json"
)

// The payload format is defined in https://docs.microsoft.com/en-us/outlook/actionable-messages/message-card-reference
// The "Type" and "Context" are specific and should not be changed

// Represents the MessageCard payload defined in
// https://docs.microsoft.com/en-us/outlook/actionable-messages/message-card-reference
type MessageCard struct {
	Type             string               `json:"@type"`
	Context          string               `json:"@context"`
	CorrelationId    string               `json:"correlationId"`
	Summary          string               `json:"summary"`
	ThemeColor       string               `json:"themeColor"` // yes, American spelling
	Title            string               `json:"title"`
	Text             string               `json:"text"`
	Sections         []MessageCardSection `json:"sections,omitempty"`
	PotentialActions []MessageCardAction  `json:"potentialAction,omitempty"`
}

type MessageCardSection struct {
	Title            string              `json:"title,omitempty"`
	StartGroup       bool                `json:"startGroup,omitempty"`
	ActivityImage    string              `json:"activityImage,omitempty"`
	ActivityTitle    string              `json:"activityTitle,omitempty"`
	ActivitySubTitle string              `json:"activitySubtitle,omitempty"`
	ActivityText     string              `json:"activityText,omitempty"`
	Text             string              `json:"text,omitempty"`
	Facts            []MessageCardFacts  `json:"facts,omitempty"`
	Images           []MessageCardImage  `json:"images,omitempty"`
	PotentialActions []MessageCardAction `json:"potentialAction,omitempty"` // yes, singular
}

type MessageCardFacts struct {
	Name  string `json:"name"`
	Value string `json:"value"`
}

type MessageCardAction struct {
	Type    string                     `json:"@type"`
	Name    string                     `json:"name"`
	Targets []MessageCardActionTargets `json:"targets"`
}

type MessageCardActionTargets struct {
	OS  string `json:"os"`
	URI string `json:"uri"`
}

type MessageCardImage struct {
	Image string `json:"image"`
	Title string `json:"title,omitempty"`
}

const MESSAGE_CARD_TYPE = "MessageCard"
const MESSAGE_CARD_CONTEXT = "https://schema.org/extensions"

func NewMessageCard() *MessageCard {
	return &MessageCard{
		Type:    MESSAGE_CARD_TYPE,
		Context: MESSAGE_CARD_CONTEXT,
	}
}

func (m *MessageCard) FormatMessage() ([]byte, error) {
	card, err := json.Marshal(m)
	if err != nil {
		return nil, err
	}
	return card, nil
}
