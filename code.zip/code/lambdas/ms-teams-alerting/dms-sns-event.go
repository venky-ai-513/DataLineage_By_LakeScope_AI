package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	"github.com/aws/aws-lambda-go/events"
)

type DMSSNSEvent struct {
	Records []DMSSNSEventRecord `json:"Records"`
}

type DMSSNSEventRecord struct {
	events.SNSEventRecord
	SNS DMSSNSEntity `json:"Sns"`
}

type DMSSNSEntity struct {
	events.SNSEntity
	RawMessage json.RawMessage	`json:"Message"`
	Message DMSSNSPayload	`json:"-"`
	// Message    events.CloudWatchAlarmSNSPayload `json:"-"` // ignore this when unmarshalling first
}

// We don't filter out any events at the moment
func (d *DMSSNSEvent) IsSendable() bool {
	return true
}

func (d *DMSSNSEvent) CreateMessageCard() (*MessageCard, error){
	alarmEvent := d.Records[0].SNS.Message

	card := NewMessageCard()
	card.Summary = fmt.Sprintf(
		"Alarm %s at %s in %s with message %s",
		alarmEvent.EventSource,
		alarmEvent.EventTime,
		alarmEvent.SourceId,
		alarmEvent.EventMessage,
	)
	card.ThemeColor = "FF0000"

	region := strings.Split(string(d.Records[0].SNS.TopicArn), ":")[3]
	
	card.Title = fmt.Sprintf("%s: %s", alarmEvent.EventSource, alarmEvent.SourceId)
	card.Text =  alarmEvent.EventMessage

	card.Sections = []MessageCardSection{
		{
			Title: "Event Details",
			Facts: []MessageCardFacts{
				{Name: "Source", Value: alarmEvent.EventSource},
				{Name: "Message", Value: alarmEvent.EventMessage},
				{Name: "Region", Value: region},
			},
		},
	}

	card.PotentialActions = []MessageCardAction{
		{
			Type: "OpenUri",
			Name: "View this task in DMS",
			Targets: []MessageCardActionTargets{
				{
					OS: "default",
					URI: fmt.Sprintf(
						alarmEvent.IdentifierLink,
					)},
			},
		},
	}

	return card, nil
}


func UnmarshalDMSSNSEvent(msg *json.RawMessage) (*DMSSNSEvent, error) {
	var dmsEvent DMSSNSEvent

	// Attempt to unmarshal to a DMS SNS event
	decoder := json.NewDecoder(bytes.NewReader(*msg))
	decoder.DisallowUnknownFields()

	if err := decoder.Decode(&dmsEvent); err != nil {
		if strings.Contains(err.Error(), "json: unknown field") {
			return nil, nil
		}

		return nil, err
	}

	// If sns subject is not DMS notification event, do not continue
	if dmsEvent.Records[0].SNS.Subject != "DMS Notification Message" {
		return nil, nil
	}

	var payload DMSSNSPayload
	unquoted, err := strconv.Unquote(string(dmsEvent.Records[0].SNS.RawMessage))
	// fmt.Println(unquoted)
	if err != nil {
		return nil, err
	}

	if err := json.Unmarshal([]byte(unquoted), &payload); err != nil {
		return nil, err
	}
	dmsEvent.Records[0].SNS.Message = payload

	return &dmsEvent, nil
}
