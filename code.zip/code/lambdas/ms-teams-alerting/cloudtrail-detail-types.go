package main

import "encoding/json"

type CloudTrailSessionIssuer struct {
	Type        string `json:"type"`
	PrincipalId string `json:"principalId"`
	ARN         string `json:"arn"`
	AccountId   string `json:"accountId"`
	UserName    string `json:"userName"`
}

type CloudTrailSessionContextAttributes struct {
	CreationDate     string `json:"creationDate"`
	MFAAuthenticated string `json:"mfaAuthenticated"`
}

type CloudTrailSessionContext struct {
	SessionIssuer       CloudTrailSessionIssuer            `json:"sessionIssuer"`
	WebIdFederationData *json.RawMessage                   `json:"webIdFederationData"`
	Attributes          CloudTrailSessionContextAttributes `json:"attributes"`
}

type CloudTrailUserIdentity struct {
	Type           string                   `json:"type"`
	PrincipalId    string                   `json:"principalId"`
	ARN            string                   `json:"arn"`
	AccountId      string                   `json:"accountId"`
	AccessKeyId    string                   `json:"accessKeyId"`
	UserName       string                   `json:"userName"`
	SessionContext CloudTrailSessionContext `json:"sessionContext"`
	InvokedBy      string                   `json:"invokedBy"`
}

type CloudTrailResource struct {
	Type      string `json:"type"`
	ARN       string `json:"ARN"`
	AccountId string `json:"accountId"`
}

type CloudTrailDetail struct {
	EventVersion                 string                 `json:"eventVersion"`
	EventId                      string                 `json:"eventID"`
	UserIdentity                 CloudTrailUserIdentity `json:"userIdentity"`
	EventTime                    string                 `json:"eventTime"`
	EventSource                  string                 `json:"eventSource"`
	EventName                    string                 `json:"eventName"`
	Region                       string                 `json:"awsRegion"`
	SourceIP                     string                 `json:"sourceIPAddress"`
	UserAgent                    string                 `json:"userAgent"`
	ErrorCode                    string                 `json:"errorCode"`
	ErrorMessage                 string                 `json:"errorMessage"`
	ReadOnly                     bool                   `json:"readOnly"`
	ManagementEvent              bool                   `json:"managementEvent"`
	RecipientAccountId           string                 `json:"recipientAccountId"`
	EventCategory                string                 `json:"eventCategory"`
	RequestParameters            *json.RawMessage       `json:"requestParameters"`
	AdditionalEventData          *json.RawMessage       `json:"additionalEventData"`
	ResponseElements             *json.RawMessage       `json:"responseElements"`
	RequestId                    string                 `json:"requestId"`
	Resources                    []CloudTrailResource   `json:"resources"`
	EventType                    string                 `json:"eventType"`
	SharedEventId                string                 `json:"sharedEventId"`
	TlsDetails                   *json.RawMessage       `json:"tlsDetails"`
	ApiVersion                   string                 `json:"apiVersion"`
	SessionCredentialFromConsole string                 `json:"sessionCredentialFromConsole"`
}
