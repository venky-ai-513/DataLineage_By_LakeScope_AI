package main

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestFormatMessage(t *testing.T) {
	t.Run("it correctly marshals itself", func(t *testing.T) {
		card := &MessageCard{}

		resp, err := card.FormatMessage()

		assert.NoError(t, err)
		assert.NotNil(t, resp)
	})
}
