module bitbucket.org/aws_daas/daas-datalake-platform/notifications/lambdas/ms-teams-alerting

go 1.16

require (
	github.com/aws/aws-lambda-go v1.32.0
	github.com/stretchr/testify v1.7.4
)
