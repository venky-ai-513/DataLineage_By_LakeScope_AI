package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/aws/aws-lambda-go/events"
)

// used to fake a correlation ID since cloudwatch alarms don't provide one
// we want this to be obviously fake
const NO_SUCH_UUID = "deadbeef-feed-cafe-face-facedbeeface"

const (
	COLOR_ALARM             = "FF0000" // Red
	COLOR_INSUFFICIENT_DATA = "CFCF00" // Orange
	COLOR_OK                = "00FF00" // Green
)

type CloudWatchAlarmSNSEvent struct {
	Records []CloudWatchAlarmSNSEventRecord `json:"Records"`
}

type CloudWatchAlarmSNSEventRecord struct {
	events.SNSEventRecord
	SNS CloudWatchAlarmSNSEntity `json:"Sns"`
}

type CloudWatchAlarmSNSEntity struct {
	events.SNSEntity
	RawMessage json.RawMessage                  `json:"Message"`
	Message    events.CloudWatchAlarmSNSPayload `json:"-"` // ignore this when unmarshalling first
}

// We don't filter out any events at the moment
func (c *CloudWatchAlarmSNSEvent) IsSendable() bool {
	return true
}

func (c *CloudWatchAlarmSNSEvent) CreateMessageCard() (*MessageCard, error) {
	alarmEvent := c.Records[0].SNS.Message
	card := NewMessageCard()
	time, err := time.Parse("2006-01-02T15:04:05.999-0700", alarmEvent.StateChangeTime)
	if err != nil {
		return nil, err
	}

	card.Summary = fmt.Sprintf(
		"Alarm %s at %s in account %s %s at %s",
		alarmEvent.AlarmName,
		time.String(),
		alarmEvent.AWSAccountID,
		alarmEvent.NewStateValue,
		alarmEvent.StateChangeTime)

	// Set the severity based on the alarm state
	switch alarmEvent.NewStateValue {
	case "ALARM":
		card.ThemeColor = COLOR_ALARM
	case "INSUFFICIENT_DATA":
		card.ThemeColor = COLOR_INSUFFICIENT_DATA
	case "OK":
		card.ThemeColor = COLOR_OK
	default:
		return nil, errors.New("Received unknown status value for alarm: " + alarmEvent.NewStateValue)
	}

	// The Region here is the human-readable version (eg "Asia Pacific (Sydney)")
	// which then can't be used in a URL, and doesn't line up with the alerting from
	// eventbridge/cloudtrail events either. We pull the region of the alarm from
	// the AlarmArn because the SNS topic ARN could be cross-region
	region := strings.Split(alarmEvent.AlarmARN, ":")[3]

	card.Title = fmt.Sprintf("%s %s", alarmEvent.AlarmName, alarmEvent.NewStateValue)
	card.Text = alarmEvent.NewStateReason

	card.Sections = []MessageCardSection{
		{
			Title: "Event Details",
			Facts: []MessageCardFacts{
				{Name: "Description", Value: alarmEvent.AlarmDescription},
				{Name: "Region", Value: region},
				{Name: "Metric", Value: alarmEvent.Trigger.MetricName},
			},
		},
	}

	card.PotentialActions = []MessageCardAction{
		{
			Type: "OpenUri",
			Name: "View this alarm in CloudWatch",
			Targets: []MessageCardActionTargets{
				{
					OS: "default",
					URI: fmt.Sprintf(
						"https://%s.console.aws.amazon.com/cloudwatch/home?region=%s#alarmsV2:alarm/%s",
						region,
						region,
						alarmEvent.AlarmName,
					)},
			},
		},
	}
	return card, nil
}

// Attempt to unmarshal first as an SNS-delivered record; if that works,
// try unmarshalling the record contents (the "Message") as a "raw"
// CloudWatch alarm
func UnmarshalCloudwatchAlarm(msg *json.RawMessage) (*CloudWatchAlarmSNSEvent, error) {
	var snsEvent CloudWatchAlarmSNSEvent

	decoder := json.NewDecoder(bytes.NewReader(*msg))
	decoder.DisallowUnknownFields()

	// I'm not 100% happy about this; I feel there should be a nicer way of
	// determining whether this is an unknown field without having to inspect
	// the string
	if err := decoder.Decode(&snsEvent); err != nil {
		if strings.Contains(err.Error(), "json: unknown field") {
			return nil, nil
		}

		return nil, err
	}

	// We must now unmarshal the RawMessage field (a json.RawMessage) into the Message field
	// This double-shuffle is because json.Unmarshal can't unmarshal a quoted string
	// into a struct
	var payload events.CloudWatchAlarmSNSPayload
	unquoted, err := strconv.Unquote(string(snsEvent.Records[0].SNS.RawMessage))
	if err != nil {
		return nil, err
	}

	if err := json.Unmarshal([]byte(unquoted), &payload); err != nil {
		return nil, err
	}
	snsEvent.Records[0].SNS.Message = payload
	return &snsEvent, nil
}
