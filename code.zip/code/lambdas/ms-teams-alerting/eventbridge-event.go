package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strings"

	"github.com/aws/aws-lambda-go/events"
)

// We compose the existing type into our own type in the package,
// so that we still have access to any functions defined on the
// external type but can also add our own functions locally
// see https://stackoverflow.com/a/44412899 for more detail
type EventBridgeEvent struct {
	events.CloudWatchEvent
	Detail CloudTrailDetail `json:"detail"`
}

// AWS event sources
const (
	SOURCE_S3				= "s3.amazonaws.com"
	SOURCE_LOGS				= "logs.amazonaws.com"
	SOURCE_ATHENA			= "athena.amazonaws.com"
	SOURCE_DMS				= "dms.amazonaws.com"
	SOURCE_STEP_FUNCTION	= "states.amazonaws.com"
)

const ERROR_ACCESS_DENIED = "AccessDenied"

func (e *EventBridgeEvent) CreateMessageCard() (*MessageCard, error) {
	card := NewMessageCard()
	var userName string

	switch e.Detail.UserIdentity.Type {
	case "IAMUser":
		userName = e.Detail.UserIdentity.UserName
	case "AssumedRole":
		userName = strings.Split(e.Detail.UserIdentity.PrincipalId, ":")[1]
	}

	card.Title = fmt.Sprintf("%s invoked %s:%s",
		userName,
		strings.TrimSuffix(e.Detail.EventSource, ".amazonaws.com"),
		e.Detail.EventName)
	card.Text = "Read/Write API call made by an identity that was not an AWS service"

	// CloudTrail can all just be blue for now
	card.ThemeColor = "0000FF"

	// Fill in a section for the event detail (containing identity information)
	card.Sections = []MessageCardSection{
		{
			Title: "Event Details",
			Facts: []MessageCardFacts{
				{Name: "IdentityType", Value: e.Detail.UserIdentity.Type},
				{Name: "Principal", Value: e.Detail.UserIdentity.PrincipalId},
				{Name: "Source IP", Value: e.Detail.SourceIP},
				{Name: "User Agent", Value: e.Detail.UserAgent},
				{Name: "API Call", Value: e.Detail.EventName},
				{Name: "Service", Value: e.Detail.EventSource},
				{Name: "Region", Value: e.Detail.Region},
			},
		},
	}

	card.PotentialActions = []MessageCardAction{
		{
			Type: "OpenUri",
			Name: "View this event in CloudTrail (may take time to appear)",
			Targets: []MessageCardActionTargets{
				{
					OS: "default",
					URI: fmt.Sprintf(
						"https://%s.console.aws.amazon.com/cloudtrail/home?region=%s#/events/%s",
						e.Detail.Region,
						e.Detail.Region,
						e.Detail.EventId,
					)},
			},
		},
	}

	return card, nil
}

// Filter out any unwanted Events
// Determine whether or not we should send this particular event to the
// notification endpoint
func (c *EventBridgeEvent) IsSendable() bool {
	// Note that the Detail field is somewhat arbitrary in its shape, and
	// may not contain the fields that we're looking for
	// Ignore events that are read-only (they cannot change the account)
	if c.Detail.ReadOnly {
		return false
	}

	// If it's any kind of event that begins with "List", "Get", "Describe",
	// ignore it
	if strings.HasPrefix(c.Detail.EventName, "Get") || strings.HasPrefix(c.Detail.EventName, "List") || strings.HasPrefix(c.Detail.EventName, "Describe") {
		return false
	}

	// It is a cloudtrail-logged API call
	// If this is an S3 event, and it wasn't denied, ignore it
	if c.Detail.EventSource == SOURCE_S3 && c.Detail.ErrorCode != ERROR_ACCESS_DENIED {
		return false
	}

	apiCall := c.Detail.EventSource + ":" + c.Detail.EventName

	switch apiCall {
	case SOURCE_LOGS + ":StartQuery",
		SOURCE_LOGS + ":StopQuery",
		SOURCE_ATHENA + ":StartQueryExecution",
		SOURCE_ATHENA + ":StopQueryExecution",
		SOURCE_DMS + ":StartReplicationTask",
		SOURCE_STEP_FUNCTION + ":StartExecution":
		return false
	}

	// by this point, it's a read-write event or, if it came from S3,
	// it was access denied, so we would like to know about it
	return true
}

func UnmarshalEventbridge(msg *json.RawMessage) (*EventBridgeEvent, error) {
	var ebEvent EventBridgeEvent

	// Attempt to unmarshal to a cloudwatch event
	decoder := json.NewDecoder(bytes.NewReader(*msg))
	decoder.DisallowUnknownFields()

	if err := decoder.Decode(&ebEvent); err != nil {
		if strings.Contains(err.Error(), "json: unknown field") {
			return nil, nil
		}

		return nil, err
	}

	return &ebEvent, nil
}
