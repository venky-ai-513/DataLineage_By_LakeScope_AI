package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"strconv"
	"strings"

	"github.com/aws/aws-lambda-go/events"
)

type AppFlowSNSEvent struct {
	Records []AppFlowSNSEventRecord `json:"Records"`
}

type AppFlowSNSEventRecord struct {
	events.SNSEventRecord
	SNS AppFlowSNSEntity `json:"Sns"`
}

type AppFlowSNSEntity struct {
	events.SNSEntity
	RawMessage json.RawMessage	`json:"Message"`
	Message AppFlowSNSPayload	`json:"-"`
	// Message    events.CloudWatchAlarmSNSPayload `json:"-"` // ignore this when unmarshalling first
}

// We don't filter out any events at the moment
func (d *AppFlowSNSEvent) IsSendable() bool {
	return true
}

func (d *AppFlowSNSEvent) CreateMessageCard() (*MessageCard, error){
	alarmEvent := d.Records[0].SNS.Message

	card := NewMessageCard()
	card.Summary = fmt.Sprintf(
		"Alarm %s at %s in %s with message %s",
		alarmEvent.EventSource,
		alarmEvent.EventTime,
		alarmEvent.Account,
		alarmEvent.DetailType,
	)
	card.ThemeColor = "FF0000"

	region := strings.Split(string(d.Records[0].SNS.TopicArn), ":")[3]
	
	card.Title = fmt.Sprintf("%s: %s", alarmEvent.Detail.FlowName, alarmEvent.Detail.Status)
	card.Text =   alarmEvent.DetailType

	card.Sections = []MessageCardSection{
		{
			Title: "Event Details",
			Facts: []MessageCardFacts{
				{Name: "Source", Value: alarmEvent.EventSource},
				{Name: "Source Object", Value: alarmEvent.Detail.SourceObject},
				{Name: "Flow ARN", Value: alarmEvent.Detail.FlowARN},
				{Name: "Time", Value: alarmEvent.EventTime},
				{Name: "Status", Value: alarmEvent.Detail.Status},
				{Name: "Trigger Type", Value: alarmEvent.Detail.TriggerType},
				{Name: "Data Processed", Value: alarmEvent.Detail.DataProcessed},
				{Name: "Region", Value: region},
			},
		},
	}

	card.PotentialActions = []MessageCardAction{
		{
			Type: "OpenUri",
			Name: "View this task in AppFlow",
			Targets: []MessageCardActionTargets{
				{
					OS: "default",
					URI: fmt.Sprintf(
						alarmEvent.Detail.FlowARN,
					)},
			},
		},
	}

	return card, nil
}


func UnmarshalAppFlowSNSEvent(msg *json.RawMessage) (*AppFlowSNSEvent, error) {
	var appflowEvent AppFlowSNSEvent

	// Attempt to unmarshal to a AppFlow SNS event
	decoder := json.NewDecoder(bytes.NewReader(*msg))
	decoder.DisallowUnknownFields()

	if err := decoder.Decode(&appflowEvent); err != nil {
		if strings.Contains(err.Error(), "json: unknown field") {
			return nil, nil
		}

		return nil, err
	}

	var payload AppFlowSNSPayload
	unquoted, err := strconv.Unquote(string(appflowEvent.Records[0].SNS.RawMessage))
	fmt.Println("Unquoted message: ", unquoted)
	if err != nil {
		return nil, err
	}

	if err := json.Unmarshal([]byte(unquoted), &payload); err != nil {
		return nil, err
	}
	appflowEvent.Records[0].SNS.Message = payload
	// If source is not aws.appflow, do not continue
	if appflowEvent.Records[0].SNS.Message.EventSource != "aws.appflow" {
		return nil, nil
	}

	return &appflowEvent, nil
}
