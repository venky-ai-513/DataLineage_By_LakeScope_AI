package main

import (
	"bytes"
	"errors"
	"fmt"
	"io"
	"log"
	"net/http"
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestSendNotification(t *testing.T) {
	t.Run("it handles http send errors", func(t *testing.T) {
		logBuffer := &bytes.Buffer{}
		notifier := &Notifier{
			httpClient: &FakeHttpClient{
				err: errors.New("some error"),
			},
			logger: log.New(logBuffer, "TEST: ", 0),
		}

		err := notifier.SendNotification(&MessageCard{})

		assert.Error(t, err)
		assert.Equal(t, "TEST: Could not POST message: some error\n", readLogBuffer(logBuffer))
	})

	t.Run("it handles unexpected HTTP response codes", func(t *testing.T) {
		logBuffer := &bytes.Buffer{}
		badResponse := &http.Response{StatusCode: 403}
		notifier := &Notifier{
			httpClient: &FakeHttpClient{
				resp: badResponse,
			},
			logger: log.New(logBuffer, "TEST: ", 0),
		}
		expectedLog := fmt.Sprintf("TEST: Received unexpected response from Teams: %# v\n", badResponse)

		err := notifier.SendNotification(&MessageCard{})

		assert.Error(t, err)
		assert.Equal(t, expectedLog, readLogBuffer(logBuffer))
	})

	t.Run("it successfully sends a valid card", func(t *testing.T) {
		logBuffer := &bytes.Buffer{}
		notifier := &Notifier{
			logger: log.New(logBuffer, "TEST: ", 0),
			httpClient: &FakeHttpClient{
				resp: &http.Response{StatusCode: http.StatusOK},
			},
		}

		err := notifier.SendNotification(&MessageCard{})

		assert.NoError(t, err)
		assert.Empty(t, logBuffer)

	})
}

func TestEventBridgeEvent(t *testing.T) {
	t.Run("it sends a notification for a valid eventbridge event", func(t *testing.T) {
		logBuffer := &bytes.Buffer{}
		httpClient := &FakeHttpClient{
			resp: &http.Response{StatusCode: http.StatusOK},
		}
		notifier := &Notifier{
			logger:     log.New(logBuffer, "TEST: ", 0),
			httpClient: httpClient,
		}

		testMsg := LoadTestEvent("testdata/eventbridge-event.json")
		handled, err := notifier.AttemptEventBridgeEvent(testMsg)

		assert.NoError(t, err)
		assert.True(t, handled)
		assert.Equal(t, httpClient.postCount, 1)
	})

	t.Run("it correctly returns errors for events that cause parsing errors", func(t *testing.T) {
		notifier := &Notifier{}
		testMsg := LoadTestEvent("testdata/eventbridge-event-bad-json.json")

		handled, err := notifier.AttemptEventBridgeEvent(testMsg)

		assert.Error(t, err)
		assert.False(t, handled)
	})

	t.Run("it correctly returns handled for events that are not sendable", func(t *testing.T) {
		notifier := &Notifier{}
		testMsg := LoadTestEvent("testdata/eventbridge-event-readonly.json")

		handled, err := notifier.AttemptEventBridgeEvent(testMsg)

		assert.NoError(t, err)
		assert.True(t, handled)
	})
}

func TestCloudWatchAlarmEvent(t *testing.T) {
	t.Run("it sends a notification for a valid cloudwatch alarm event", func(t *testing.T) {
		logBuffer := &bytes.Buffer{}
		httpClient := &FakeHttpClient{
			resp: &http.Response{StatusCode: http.StatusOK},
		}
		notifier := &Notifier{
			logger:     log.New(logBuffer, "TEST: ", 0),
			httpClient: httpClient,
		}

		testMsg := LoadTestEvent("testdata/sns-alert-single.json")
		handled, err := notifier.AttemptCloudWatchAlarmEvent(testMsg)

		assert.NoError(t, err)
		assert.True(t, handled)
		assert.Equal(t, httpClient.postCount, 1)
	})

	t.Run("it correctly returns errors for events that cause parsing errors", func(t *testing.T) {
		notifier := &Notifier{}
		testMsg := LoadTestEvent("testdata/sns-alert-single-bad-message.json")

		handled, err := notifier.AttemptCloudWatchAlarmEvent(testMsg)

		assert.Error(t, err)
		assert.False(t, handled)
	})

	t.Run("it correctly returns a handled error when failing to create a card", func(t *testing.T) {
		notifier := &Notifier{}
		testMsg := LoadTestEvent("testdata/sns-alert-single-bad-time.json")

		handled, err := notifier.AttemptCloudWatchAlarmEvent(testMsg)

		assert.Error(t, err)
		assert.True(t, handled)
	})
}

func TestDMSSubscriptionEvent(t *testing.T) {
	t.Run("it sends a notification for a valid DMS event subscription", func(t *testing.T) {
		logBuffer := &bytes.Buffer{}
		httpClient := &FakeHttpClient{
			resp: &http.Response{StatusCode: http.StatusOK},
		}
		notifier := &Notifier{
			logger:     log.New(logBuffer, "TEST: ", 0),
			httpClient: httpClient,
		}

		testMsg := LoadTestEvent("testdata/sns-alert-replication-task.json")
		handled, err := notifier.AttemptDMSSubscriptionEvent(testMsg)

		assert.NoError(t, err)
		assert.True(t, handled)
		assert.Equal(t, httpClient.postCount, 1)
	})
}

func TestAppFlowSNSEvent(t *testing.T) {
	t.Run("it sends a notification for a valid AppFLow event subscription", func(t *testing.T) {
		logBuffer := &bytes.Buffer{}
		httpClient := &FakeHttpClient{
			resp: &http.Response{StatusCode: http.StatusOK},
		}
		notifier := &Notifier{
			logger:     log.New(logBuffer, "TEST: ", 0),
			httpClient: httpClient,
		}

		testMsg := LoadTestEvent("testdata/sns-alert-appflow.json")
		handled, err := notifier.AttemptAppFLowSubscriptionEvent(testMsg)

		assert.NoError(t, err)
		assert.True(t, handled)
		assert.Equal(t, httpClient.postCount, 1)
	})
}

func TestUnknownEvent(t *testing.T) {
	t.Run("it complains that it cannot handle an unknown event", func(t *testing.T) {
		logBuffer := &bytes.Buffer{}
		notifier := &Notifier{
			logger: log.New(logBuffer, "TEST: ", 0),
			httpClient: &FakeHttpClient{
				resp: &http.Response{StatusCode: http.StatusOK},
			},
		}

		testMsg := LoadTestEvent("testdata/alarm-message.json")
		expectedLog := "TEST: Cannot determine how to process event: "

		err := notifier.HandleEvent(testMsg)

		assert.NoError(t, err)
		assert.Contains(t, readLogBuffer(logBuffer), expectedLog)
	})

	t.Run("it doesn't complain for an event it should be able to handle", func(t *testing.T) {
		logBuffer := &bytes.Buffer{}
		notifier := &Notifier{
			logger: log.New(logBuffer, "TEST: ", 0),
			httpClient: &FakeHttpClient{
				resp: &http.Response{StatusCode: http.StatusOK},
			},
		}

		testMsg := LoadTestEvent("testdata/s3-event.json")
		expectedLog := "TEST: Cannot determine how to process event: "

		err := notifier.HandleEvent(testMsg)

		assert.NoError(t, err)
		assert.NotContains(t, readLogBuffer(logBuffer), expectedLog)
	})
}

type FakeHttpClient struct {
	resp      *http.Response
	err       error
	postCount int
}

func (f *FakeHttpClient) Post(url, contentType string, body io.Reader) (*http.Response, error) {
	f.postCount++
	return f.resp, f.err
}
