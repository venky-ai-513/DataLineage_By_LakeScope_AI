package main

import (
	"testing"

	"github.com/stretchr/testify/assert"
)

func TestPopulateCloudTrail(t *testing.T) {
	t.Run("it correctly populates a card from a detail element", func(t *testing.T) {
		event := LoadTestEvent("testdata/eventbridge-event.json")
		ebEvent, _ := UnmarshalEventbridge(event)

		card, err := ebEvent.CreateMessageCard()

		expectedSections := []MessageCardSection{
			{
				Title: "Event Details",
				Facts: []MessageCardFacts{
					{Name: "IdentityType", Value: "AssumedRole"},
					{Name: "Principal", Value: "AROA5BJ4IKX3GOMEI6VL2:colin.panisset@davidjones.com.au"},
					{Name: "Source IP", Value: "159.196.181.228"},
					{Name: "User Agent", Value: "aws-internal/3 aws-sdk-java/1.12.157 Linux/5.4.172-100.336.amzn2int.x86_64 OpenJDK_64-Bit_Server_VM/25.322-b06 java/1.8.0_322 vendor/Oracle_Corporation cfg/retry-mode/standard"},
					{Name: "API Call", Value: "SetQueueAttributes"},
					{Name: "Service", Value: "sqs.amazonaws.com"},
					{Name: "Region", Value: "ap-southeast-2"},
				},
			},
		}

		assert.NoError(t, err)
		assert.Equal(t, expectedSections, card.Sections)
	})
}

func TestUnmarshalEventBridge(t *testing.T) {
	t.Run("it correctly unmarshals an eventbridge event", func(t *testing.T) {
		// arrange
		testMsg := LoadTestEvent("testdata/eventbridge-event.json")

		// act
		event, err := UnmarshalEventbridge(testMsg)

		// assert
		assert.NoError(t, err)
		assert.Equal(t, "7d405d02-0bdb-5879-d7bc-b7917259dbc0", event.ID)
	})

	t.Run("it correctly returns nothing for a non-cloudtrail event", func(t *testing.T) {
		// arrange
		testMsg := LoadTestEvent("testdata/eventbridge-event-ec2.json")

		// act
		event, err := UnmarshalEventbridge(testMsg)

		// assert
		assert.NoError(t, err)
		assert.Nil(t, event)
	})

	t.Run("it correctly fails unmarshalling a non-eventbridge event as an eventbridge event", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/alarm-message.json")

		event, err := UnmarshalEventbridge(testMsg)

		assert.NoError(t, err)
		assert.Nil(t, event)
	})

	t.Run("it correctly identifies events as sendable", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/eventbridge-event.json")

		event, err := UnmarshalEventbridge(testMsg)
		sendable := event.IsSendable()

		assert.NoError(t, err)
		assert.NotNil(t, event)
		assert.True(t, sendable)
	})

	t.Run("it correctly identifies events as not sendable when readonly", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/eventbridge-event-readonly.json")

		event, err := UnmarshalEventbridge(testMsg)
		sendable := event.IsSendable()

		assert.NoError(t, err)
		assert.NotNil(t, event)
		assert.False(t, sendable)
	})

	t.Run("it correctly identifies events as sendable when s3 and access denied", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/eventbridge-filter-event.json")

		event, err := UnmarshalEventbridge(testMsg)
		sendable := event.IsSendable()

		assert.NoError(t, err)
		assert.NotNil(t, event)
		assert.False(t, sendable)
	})

	t.Run("it correctly excludes events that are prefixed with Get, List, or Describe", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/eventbridge-filter-event-prefix.json")

		event, err := UnmarshalEventbridge(testMsg)
		sendable := event.IsSendable()

		assert.NoError(t, err)
		assert.NotNil(t, event)
		assert.False(t, sendable)
	})

	t.Run("it correctly identifies events as not sendable when s3 and access granted", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/s3-event.json")

		event, err := UnmarshalEventbridge(testMsg)

		assert.NoError(t, err)
		assert.NotNil(t, event)

		sendable := event.IsSendable()
		assert.False(t, sendable)
	})

	t.Run("it correctly handles an aws logs event", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/logs-event.json")

		event, err := UnmarshalEventbridge(testMsg)

		assert.NoError(t, err)
		assert.NotNil(t, event)

		sendable := event.IsSendable()
		assert.False(t, sendable)
	})

	t.Run("it correctly handles an athena event", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/athena-event.json")

		event, err := UnmarshalEventbridge(testMsg)

		assert.NoError(t, err)
		assert.NotNil(t, event)

		sendable := event.IsSendable()
		assert.False(t, sendable)
	})

	t.Run("it correctly handles an stop query athena event", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/athena-events-stopquery.json")

		event, err := UnmarshalEventbridge(testMsg)

		assert.NoError(t, err)
		assert.NotNil(t, event)

		sendable := event.IsSendable()
		assert.False(t, sendable)
	})

	t.Run("it correctly handles a step functions event", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/step-functions-event.json")

		event, err := UnmarshalEventbridge(testMsg)

		assert.NoError(t, err)
		assert.NotNil(t, event)

		sendable := event.IsSendable()
		assert.False(t, sendable)
	})

	t.Run("it correctly handles an IAM User event", func(t *testing.T) {
		testMsg := LoadTestEvent("testdata/iam-user-event.json")

		event, err := UnmarshalEventbridge(testMsg)

		assert.NoError(t, err)
		assert.NotNil(t, event)

		sendable := event.IsSendable()
		assert.True(t, sendable)

		card, err := event.CreateMessageCard()
		assert.NoError(t, err)

		assert.Contains(t, card.Title, "Kafka_User invoked s3:MakeToast")
	})
}
