"""
Lambda function to process SNS events and send a formatted message to a Teams webhook.
"""
import os
import json
import requests

def lambda_handler(event, _context):
    """
    Lambda function to process SNS events and send a formatted message to a Teams webhook.
    """
    webhook_url = os.getenv('webhook_url')
    print('event:',event)
    print('dump_events',json.dumps(event))
    print('webhook_url:',webhook_url)
    # Extract message from SNS event using .get() to handle missing keys gracefully
    records = event.get('Records', [])

    for record in records:
        sns = record.get('Sns', {})
        message_str = sns.get('Message', '{}')

        message = json.loads(message_str)

        if "AlarmName" in message:
            # Extract the region dynamically from the SNS record
            region = record.get('AwsRegion', 'unknown-region')
            print('Input Event from Alarm :',message['AlarmName'])
            transform_message = {
                  "sections": [
                    {
                      "facts": [
                        {
                          "name": "Description",
                          "value": message['Trigger']['Dimensions'][0]['value']
                        },
                        {
                          "name": "Region",
                          "value": region
                        },
                        {
                          "name": "Metric",
                          "value": message['Trigger']['MetricName']
                        }
                      ],
                      "title": "Event Details"
                    }
                  ],
                  "summary": message['AlarmName'],
                  "text": message['NewStateReason'],
                  "title": message['AlarmDescription']
                }
            print('transform_message :',transform_message)
            message=transform_message
            # Convert transform_message to JSON string
            message_json = transform_message
        else:
            # message from stepfunction
            region = os.environ.get('AWS_REGION', 'unknown-region')
            message['text']=str(message['text']) # convert input json to string
            message['summary']="https://"+region+".console.aws.amazon.com/states/home?region="+region+"#/executions/details/"+message['summary']
            message_json = message
            print('message_json',message_json)

    headers = {
        "Content-Type": "application/json"
    }

    response = requests.post(webhook_url, headers=headers, data=json.dumps(message_json))

    # Check for success status codes
    if response.status_code not in [200, 202]:
        raise ValueError(
            f"Request to Teams webhook returned an error {response.status_code}, "
            f"the response is: {response.text}"
        )

    return {
        "statusCode": 200,
        "body": json.dumps("Message sent to Teams successfully!")
    }
