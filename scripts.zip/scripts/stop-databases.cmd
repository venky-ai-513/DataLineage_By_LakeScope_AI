@echo off
setlocal
set "PATH=C:\Program Files\Git\usr\bin;C:\Program Files\RedHat\Podman;%PATH%"
set "PROJECT_DIR=%~dp0.."

"%PROJECT_DIR%\.venv\Scripts\podman-compose.exe" -f "%PROJECT_DIR%\compose.yaml" stop
if errorlevel 1 exit /b %errorlevel%

echo LakeScope databases stopped. Persistent data was preserved.
