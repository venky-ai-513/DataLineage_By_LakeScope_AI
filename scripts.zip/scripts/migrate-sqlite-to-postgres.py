from __future__ import annotations

import argparse
from pathlib import Path
import sys
from typing import Any

from sqlalchemy import create_engine, delete, func, select, text
from sqlalchemy.engine import Engine

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.app.config import PROJECT_ROOT
from backend.app.database import Base
from backend.app import models  # noqa: F401 - registers all tables with Base.metadata


DEFAULT_SOURCE = f"sqlite:///{(PROJECT_ROOT / 'data' / 'lakescope.db').as_posix()}"
DEFAULT_TARGET = "postgresql+psycopg://lakescope:lakescope-local@127.0.0.1:5432/lakescope"


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Copy LakeScope metadata from SQLite into an empty PostgreSQL database."
    )
    parser.add_argument("--source", default=DEFAULT_SOURCE, help="Source SQLAlchemy database URL")
    parser.add_argument("--target", default=DEFAULT_TARGET, help="Target PostgreSQL SQLAlchemy database URL")
    parser.add_argument(
        "--replace",
        action="store_true",
        help="Replace existing LakeScope rows in the target (the source SQLite file is never modified)",
    )
    return parser.parse_args()


def _row_count(engine: Engine, table) -> int:
    with engine.connect() as connection:
        return int(connection.scalar(select(func.count()).select_from(table)) or 0)


def _reset_postgres_sequences(connection) -> None:
    preparer = connection.dialect.identifier_preparer
    for table in Base.metadata.sorted_tables:
        if "id" not in table.c:
            continue
        table_name = preparer.quote(table.name)
        qualified_name = f"public.{table.name}"
        connection.execute(
            text(
                f"SELECT setval(pg_get_serial_sequence(:table_name, 'id'), "
                f"COALESCE(MAX(id), 1), MAX(id) IS NOT NULL) FROM {table_name}"
            ),
            {"table_name": qualified_name},
        )


def migrate(source_url: str, target_url: str, replace: bool = False) -> dict[str, Any]:
    if source_url == target_url:
        raise ValueError("Source and target database URLs must be different")
    if source_url.startswith("sqlite:///"):
        source_path = Path(source_url.removeprefix("sqlite:///"))
        if not source_path.exists():
            raise FileNotFoundError(f"SQLite source does not exist: {source_path}")

    source_engine = create_engine(source_url, future=True)
    target_engine = create_engine(target_url, future=True)
    Base.metadata.create_all(target_engine)
    with target_engine.begin() as connection:
        connection.execute(text("ALTER TABLE query_runs ALTER COLUMN bytes_scanned TYPE BIGINT"))

    target_counts = {table.name: _row_count(target_engine, table) for table in Base.metadata.sorted_tables}
    populated = {name: count for name, count in target_counts.items() if count > 0}
    if populated and not replace:
        details = ", ".join(f"{name}={count}" for name, count in populated.items())
        raise RuntimeError(
            f"PostgreSQL already contains LakeScope data ({details}). "
            "Run without changing it, or pass --replace intentionally."
        )

    counts: dict[str, int] = {}
    with source_engine.connect() as source, target_engine.begin() as target:
        if replace:
            for table in reversed(Base.metadata.sorted_tables):
                target.execute(delete(table))
        for table in Base.metadata.sorted_tables:
            rows = [dict(row) for row in source.execute(select(table)).mappings()]
            if rows:
                for offset in range(0, len(rows), 500):
                    target.execute(table.insert(), rows[offset : offset + 500])
            counts[table.name] = len(rows)
        _reset_postgres_sequences(target)

    mismatches = {
        table.name: {"source": counts[table.name], "target": _row_count(target_engine, table)}
        for table in Base.metadata.sorted_tables
        if counts[table.name] != _row_count(target_engine, table)
    }
    if mismatches:
        raise RuntimeError(f"Migration count verification failed: {mismatches}")
    return {"tables": counts, "verified": True}


def main() -> None:
    args = _parse_args()
    result = migrate(args.source, args.target, replace=args.replace)
    print("LakeScope migration verified")
    for table_name, count in result["tables"].items():
        print(f"  {table_name}: {count}")


if __name__ == "__main__":
    main()
