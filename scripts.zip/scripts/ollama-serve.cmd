@echo off
rem Runs "ollama serve" for LakeScope. Started by start-ai.cmd, which sets OLLAMA_EXE, AI_LOG and the OLLAMA_* settings.
"%OLLAMA_EXE%" serve 1>>"%AI_LOG%" 2>&1
