@echo off
rem Starts LakeScope's own Ollama instance on its own port (default 127.0.0.1:11435).
rem It never touches any other Ollama instance on this machine (for example the one on 11434).
setlocal
set "PROJECT_DIR=%~dp0.."
set "ENV_FILE=%PROJECT_DIR%\.env"

rem Defaults; overridden by the matching keys in .env.
set "AI_ENABLED=true"
set "OLLAMA_EXE=D:\Ollama\ollama.exe"
set "OLLAMA_PORT=11435"
set "OLLAMA_MODELS_DIR=D:\Ollama\models"

if exist "%ENV_FILE%" (
  for /f "usebackq eol=# tokens=1,* delims==" %%a in ("%ENV_FILE%") do (
    if /i "%%a"=="LAKESCOPE_AI_ENABLED" set "AI_ENABLED=%%b"
    if /i "%%a"=="LAKESCOPE_OLLAMA_EXE" set "OLLAMA_EXE=%%b"
    if /i "%%a"=="LAKESCOPE_OLLAMA_PORT" set "OLLAMA_PORT=%%b"
    if /i "%%a"=="LAKESCOPE_OLLAMA_MODELS" set "OLLAMA_MODELS_DIR=%%b"
  )
)

if /i not "%AI_ENABLED%"=="true" (
  echo LakeScope AI is disabled ^(LAKESCOPE_AI_ENABLED is not true^). Skipping Ollama.
  exit /b 0
)

if not exist "%OLLAMA_EXE%" (
  echo Ollama was not found at "%OLLAMA_EXE%". Set LAKESCOPE_OLLAMA_EXE in .env.
  exit /b 1
)

set "AI_URL=http://127.0.0.1:%OLLAMA_PORT%"

curl.exe -s -o nul -f "%AI_URL%/api/version" >nul 2>&1
if not errorlevel 1 (
  echo LakeScope Ollama is already running at %AI_URL%
  exit /b 0
)

if not exist "%PROJECT_DIR%\data" mkdir "%PROJECT_DIR%\data"
set "AI_LOG=%PROJECT_DIR%\data\ollama-lakescope.log"

rem These settings apply only to this Ollama process, not to the machine.
set "OLLAMA_HOST=127.0.0.1:%OLLAMA_PORT%"
set "OLLAMA_MODELS=%OLLAMA_MODELS_DIR%"
rem Shared model folder: never prune blobs another instance may be downloading.
set "OLLAMA_NOPRUNE=1"
rem One request at a time; chat model + embedding model may both stay loaded.
set "OLLAMA_NUM_PARALLEL=1"
set "OLLAMA_MAX_LOADED_MODELS=2"
rem Free the memory after 30 idle minutes.
set "OLLAMA_KEEP_ALIVE=30m"

rem Launch through ShellExecute (Start-Process), not "start": a child created by "start" inherits this
rem script's open handles, so if the caller redirected us to a log file, Ollama would keep that file locked.
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~dp0ollama-serve.cmd' -WindowStyle Hidden" >nul 2>&1

set /a AI_ATTEMPTS=0
:wait_for_ai
curl.exe -s -o nul -f "%AI_URL%/api/version" >nul 2>&1
if not errorlevel 1 goto ai_ready
set /a AI_ATTEMPTS+=1
if %AI_ATTEMPTS% GEQ 30 (
  echo LakeScope Ollama did not start within 60 seconds. See "%AI_LOG%".
  exit /b 1
)
"%SystemRoot%\System32\PING.EXE" 127.0.0.1 -n 3 >nul
goto wait_for_ai

:ai_ready
echo LakeScope Ollama: %AI_URL%  ^(log: data\ollama-lakescope.log^)
exit /b 0
