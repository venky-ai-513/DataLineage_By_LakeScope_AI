@echo off
setlocal
set "PATH=C:\Program Files\Git\usr\bin;C:\Program Files\RedHat\Podman;%PATH%"
set "PROJECT_DIR=%~dp0.."

podman machine inspect lakescope-machine >nul 2>&1
if errorlevel 1 (
  echo LakeScope Podman machine is not initialized.
  echo Run: podman machine init --cpus 4 --memory 6144 --disk-size 50 lakescope-machine
  exit /b 1
)

podman machine start lakescope-machine >nul 2>&1
set /a PODMAN_ATTEMPTS=0

:wait_for_podman
podman info >nul 2>&1
if not errorlevel 1 goto podman_ready
set /a PODMAN_ATTEMPTS+=1
if %PODMAN_ATTEMPTS% GEQ 30 (
  echo Podman did not become ready within 60 seconds.
  echo Try: podman machine stop lakescope-machine
  echo Then: podman machine start lakescope-machine
  exit /b 1
)
echo Waiting for the LakeScope Podman machine... %PODMAN_ATTEMPTS%/30
"%SystemRoot%\System32\PING.EXE" 127.0.0.1 -n 3 >nul
goto wait_for_podman

:podman_ready
"%PROJECT_DIR%\.venv\Scripts\podman-compose.exe" -f "%PROJECT_DIR%\compose.yaml" up -d
if errorlevel 1 exit /b %errorlevel%

echo LakeScope databases are starting.
echo PostgreSQL: 127.0.0.1:5432
echo Neo4j:      http://127.0.0.1:7474
