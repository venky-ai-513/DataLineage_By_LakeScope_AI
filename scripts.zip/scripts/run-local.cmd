@echo off
setlocal
set "PROJECT_DIR=%~dp0.."

call "%~dp0start-databases.cmd"
if errorlevel 1 exit /b %errorlevel%

call "%~dp0start-ai.cmd"
if errorlevel 1 echo WARNING: LakeScope AI ^(Ollama^) did not start. LakeScope will run without AI features.

cd /d "%PROJECT_DIR%"
echo LakeScope is starting locally at http://127.0.0.1:8000
echo LAN access: http://5CG3402KMH:8000 or the current LAN IP on port 8000
echo Press Ctrl+C to stop the application. PostgreSQL and Neo4j data will remain available.
"%PROJECT_DIR%\.venv\Scripts\python.exe" -m uvicorn backend.app.main:app --host 0.0.0.0 --port 8000
