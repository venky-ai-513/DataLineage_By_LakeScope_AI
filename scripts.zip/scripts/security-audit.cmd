@echo off
setlocal
set "PROJECT_DIR=%~dp0.."
cd /d "%PROJECT_DIR%"

echo Checking Python dependency consistency...
".venv\Scripts\python.exe" -m pip check || exit /b 1

echo Checking Python packages for published vulnerabilities...
".venv\Scripts\python.exe" -m pip_audit --local --progress-spinner off || exit /b 1

echo Checking backend code for medium and high severity security findings...
".venv\Scripts\bandit.exe" -r backend\app -x backend\tests -ll -q || exit /b 1

echo Checking production browser packages for published vulnerabilities...
call pnpm audit --prod || exit /b 1

echo Building the browser application with the installed package versions...
call pnpm build || exit /b 1

echo Running the backend regression tests...
".venv\Scripts\python.exe" -m pytest backend\tests -q || exit /b 1

echo LakeScope application security checks passed.
