@echo off
rem Starts LakeScope's own Neo4j (graph projection) on 127.0.0.1:7687 if the graph is enabled.
rem Called by the service launcher on every loop, like start-ai.cmd; does nothing when Neo4j is already up.
setlocal
set "PROJECT_DIR=%~dp0.."
set "ENV_FILE=%PROJECT_DIR%\.env"

rem Defaults; .env keys override them, and a LAKESCOPE_GRAPH_ENABLED set by the launcher wins over .env.
set "GRAPH_ENABLED=false"
set "NEO4J_DIR=C:\LakeScope\neo4j\neo4j-community-5.26.19"
set "NEO4J_JAVA=C:\LakeScope\neo4j\jdk-21.0.13.1+2"

if exist "%ENV_FILE%" (
  for /f "usebackq eol=# tokens=1,* delims==" %%a in ("%ENV_FILE%") do (
    if /i "%%a"=="LAKESCOPE_GRAPH_ENABLED" set "GRAPH_ENABLED=%%b"
    if /i "%%a"=="LAKESCOPE_NEO4J_HOME" set "NEO4J_DIR=%%b"
    if /i "%%a"=="LAKESCOPE_NEO4J_JAVA_HOME" set "NEO4J_JAVA=%%b"
  )
)
if defined LAKESCOPE_GRAPH_ENABLED set "GRAPH_ENABLED=%LAKESCOPE_GRAPH_ENABLED%"

if /i not "%GRAPH_ENABLED%"=="true" (
  echo LakeScope graph is disabled ^(LAKESCOPE_GRAPH_ENABLED is not true^). Skipping Neo4j.
  exit /b 0
)
if not exist "%NEO4J_DIR%\bin\neo4j.bat" (
  echo Neo4j was not found at "%NEO4J_DIR%". Set LAKESCOPE_NEO4J_HOME in .env.
  exit /b 1
)
if not exist "%NEO4J_JAVA%\bin\java.exe" (
  echo Java 21 for Neo4j was not found at "%NEO4J_JAVA%". Set LAKESCOPE_NEO4J_JAVA_HOME in .env.
  exit /b 1
)

set "NEO4J_URL=http://127.0.0.1:7474"
curl.exe -s -o nul -f "%NEO4J_URL%" >nul 2>&1
if not errorlevel 1 (
  echo LakeScope Neo4j is already running at bolt://127.0.0.1:7687
  exit /b 0
)

rem Hidden, detached process (Start-Process), so it does not hold this script's redirected log handles.
set "LAKESCOPE_NEO4J_DIR=%NEO4J_DIR%"
set "LAKESCOPE_NEO4J_JAVA=%NEO4J_JAVA%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~dp0neo4j-console.cmd' -WindowStyle Hidden" >nul 2>&1

set /a GRAPH_ATTEMPTS=0
:wait_for_neo4j
curl.exe -s -o nul -f "%NEO4J_URL%" >nul 2>&1
if not errorlevel 1 goto neo4j_ready
set /a GRAPH_ATTEMPTS+=1
if %GRAPH_ATTEMPTS% GEQ 45 (
  echo LakeScope Neo4j did not start within 90 seconds. See "%NEO4J_DIR%\logs\neo4j-console.log".
  exit /b 1
)
"%SystemRoot%\System32\PING.EXE" 127.0.0.1 -n 3 >nul
goto wait_for_neo4j

:neo4j_ready
echo LakeScope Neo4j: bolt://127.0.0.1:7687  ^(browser: %NEO4J_URL%^)
exit /b 0
