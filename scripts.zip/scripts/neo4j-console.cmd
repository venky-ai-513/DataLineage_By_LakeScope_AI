@echo off
rem Runs LakeScope's Neo4j in the foreground of a hidden window (started by start-neo4j.cmd).
rem Java 21 is used only for this process; the machine's own Java is not changed.
setlocal
if not defined LAKESCOPE_NEO4J_DIR set "LAKESCOPE_NEO4J_DIR=C:\LakeScope\neo4j\neo4j-community-5.26.19"
if not defined LAKESCOPE_NEO4J_JAVA set "LAKESCOPE_NEO4J_JAVA=C:\LakeScope\neo4j\jdk-21.0.13.1+2"
set "JAVA_HOME=%LAKESCOPE_NEO4J_JAVA%"
set "NEO4J_HOME=%LAKESCOPE_NEO4J_DIR%"
rem A machine-wide JAVA_TOOL_OPTIONS (old Java 8 setting) must not leak into Neo4j.
set "JAVA_TOOL_OPTIONS="
set "PATH=%JAVA_HOME%\bin;%PATH%"
call "%NEO4J_HOME%\bin\neo4j.bat" console >> "%NEO4J_HOME%\logs\neo4j-console.log" 2>&1
