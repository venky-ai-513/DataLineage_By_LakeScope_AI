$ErrorActionPreference = "Stop"

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectDirectory = Split-Path -Parent $scriptDirectory
$pythonExecutable = Join-Path $projectDirectory ".venv\Scripts\python.exe"
$databaseLauncher = Join-Path $scriptDirectory "start-databases.cmd"

if (-not (Test-Path -LiteralPath $pythonExecutable)) {
    throw "LakeScope is not set up. Run scripts\setup-local.ps1 first."
}

& $databaseLauncher
if ($LASTEXITCODE -ne 0) {
    throw "PostgreSQL and Neo4j could not be started. Open Podman Desktop and try again."
}

& (Join-Path $scriptDirectory "start-ai.cmd")
if ($LASTEXITCODE -ne 0) {
    Write-Warning "LakeScope AI (Ollama) did not start. LakeScope will run without AI features."
}

Write-Host "LakeScope is starting at http://127.0.0.1:8000"
Write-Host "Press Ctrl+C to stop it."
Push-Location $projectDirectory
try {
    & $pythonExecutable -m uvicorn backend.app.main:app --host 127.0.0.1 --port 8000
}
finally {
    Pop-Location
}
