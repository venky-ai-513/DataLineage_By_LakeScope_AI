# Puts the CRG sign-in page and user logbook live on production (port 3003).
# The new frontend and backend must go live together: the login page calls /api/auth/login,
# which only exists once the service has restarted on the new backend code.
# Run from an elevated PowerShell:
#   powershell -ExecutionPolicy Bypass -File C:\LakeScope\LakeScope\scripts\enable-login.ps1

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
$staged = Join-Path $root "data\dist-login"
$live = Join-Path $root "dist"
$task = "\OneStop-DataLineage-3003"

if (-not (Test-Path (Join-Path $staged "index.html"))) { throw "Staged build not found at $staged" }

Write-Host "Stopping $task ..."
schtasks /end /tn $task | Out-Null
Start-Sleep -Seconds 3

Write-Host "Swapping in the sign-in frontend ..."
$backup = Join-Path $root "data\dist.bak-before-login"
if (-not (Test-Path $backup)) { Copy-Item $live $backup -Recurse }
Remove-Item $live -Recurse -Force
Copy-Item $staged $live -Recurse

Write-Host "Starting $task ..."
schtasks /run /tn $task | Out-Null

# A 403 "Invalid user" for a non-CRG address means the new endpoint is up and enforcing the rule.
$bodyFile = Join-Path $env:TEMP "lakescope-login-check.json"
Set-Content -Path $bodyFile -Value '{"email":"healthcheck@example.com"}' -Encoding ascii
$deadline = (Get-Date).AddSeconds(90)
do {
  Start-Sleep -Seconds 3
  $code = & curl.exe -sk -o NUL -w "%{http_code}" -X POST -H "Content-Type: application/json" --data-binary "@$bodyFile" "https://127.0.0.1:3003/api/auth/login"
  $ok = ($code -eq "403")
} until ($ok -or (Get-Date) -gt $deadline)
Remove-Item $bodyFile -ErrorAction SilentlyContinue

if ($ok) { Write-Host "Sign-in is live on port 3003." -ForegroundColor Green }
else { Write-Host "Service did not answer the login check within 90 s. Check C:\OneStop Automation\logs\lineage.log" -ForegroundColor Yellow }
