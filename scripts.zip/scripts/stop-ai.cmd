@echo off
rem Stops only LakeScope's own Ollama instance (the process listening on its port).
setlocal
set "PROJECT_DIR=%~dp0.."
set "ENV_FILE=%PROJECT_DIR%\.env"
set "OLLAMA_PORT=11435"

if exist "%ENV_FILE%" (
  for /f "usebackq eol=# tokens=1,* delims==" %%a in ("%ENV_FILE%") do (
    if /i "%%a"=="LAKESCOPE_OLLAMA_PORT" set "OLLAMA_PORT=%%b"
  )
)

set "FOUND="
for /f "tokens=5" %%p in ('netstat -ano ^| findstr /r /c:"127\.0\.0\.1:%OLLAMA_PORT% .*LISTENING"') do (
  set "FOUND=1"
  taskkill /PID %%p /T /F >nul 2>&1
)

if defined FOUND (
  echo LakeScope Ollama on port %OLLAMA_PORT% stopped.
) else (
  echo LakeScope Ollama is not running on port %OLLAMA_PORT%.
)
exit /b 0
