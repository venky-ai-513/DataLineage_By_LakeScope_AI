$ErrorActionPreference = "Stop"

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectDirectory = Split-Path -Parent $scriptDirectory
$venvDirectory = Join-Path $projectDirectory ".venv"
$pythonExecutable = Join-Path $venvDirectory "Scripts\python.exe"

if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    throw "Python 3.12 or newer is required."
}
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
    throw "pnpm is required. Install Node.js, then run: corepack enable"
}

Push-Location $projectDirectory
try {
    if (-not (Test-Path -LiteralPath $pythonExecutable)) {
        python -m venv $venvDirectory
    }
    & $pythonExecutable -m pip install -r scripts\requirements-local.txt
    pnpm install
    pnpm build
    Write-Host "LakeScope is ready. Run scripts\run-local.cmd"
}
finally {
    Pop-Location
}
