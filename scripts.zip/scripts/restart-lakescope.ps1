# Restarts the LakeScope service on port 3003 so backend changes take effect.
# It does not touch the other Ollama on port 11434. Run from an elevated PowerShell:
#   powershell -ExecutionPolicy Bypass -File C:\LakeScope\LakeScope\scripts\restart-lakescope.ps1

$ErrorActionPreference = "Stop"
$task = "\OneStop-DataLineage-3003"

Write-Host "Stopping $task ..."
schtasks /end /tn $task | Out-Null
Start-Sleep -Seconds 3

# Stopping the task does not end Git/SSH processes LakeScope started for a Bitbucket pull.
# Only LakeScope's own ones are matched (its fetch arguments, its temporary key folder or Bitbucket's SSH host).
Get-CimInstance Win32_Process -Filter "Name='git.exe' OR Name='ssh.exe'" |
  Where-Object { $_.CommandLine -match '--no-tags -q origin|lakescope-ssh-|altssh\.bitbucket\.org' } |
  ForEach-Object {
    Write-Host "Ending stuck $($_.Name) ($($_.ProcessId)) from a Bitbucket pull ..."
    taskkill /T /F /PID $_.ProcessId | Out-Null
  }

Write-Host "Starting $task ..."
schtasks /run /tn $task | Out-Null

$deadline = (Get-Date).AddSeconds(90)
do {
  Start-Sleep -Seconds 3
  $code = & curl.exe -sk -o NUL -w "%{http_code}" "https://127.0.0.1:3003/api/ai/status"
} until ($code -eq "200" -or (Get-Date) -gt $deadline)

if ($code -eq "200") { Write-Host "LakeScope is back up on port 3003." -ForegroundColor Green }
else { Write-Host "LakeScope did not answer within 90 s. Check C:\OneStop Automation\logs\lineage.log" -ForegroundColor Yellow }
