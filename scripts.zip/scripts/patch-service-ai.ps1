# One-off: make the production service (OneStop-DataLineage-3003) start LakeScope's own Ollama.
# Ensures run-lineage.cmd calls scripts\start-ai.cmd right after ":loop" with its output sent to NUL.
# (Redirecting it to lineage.log is NOT safe: the Ollama process inherits that handle and keeps the
#  log locked, so the wrapper can no longer start uvicorn.) Keeps a backup, stops the LakeScope Ollama
# on 11435 (never the one on 11434) and restarts the scheduled task. Safe to run more than once.
# Run from an elevated prompt:  powershell -ExecutionPolicy Bypass -File C:\LakeScope\LakeScope\scripts\patch-service-ai.ps1
$ErrorActionPreference = 'Stop'
$f    = 'C:\OneStop Automation\service\run-lineage.cmd'
$line = 'call "C:\LakeScope\LakeScope\scripts\start-ai.cmd" >nul 2>&1'
$task = 'OneStop-DataLineage-3003'

if (-not (Test-Path "$f.bak-before-ai")) { Copy-Item $f "$f.bak-before-ai" }
$content = Get-Content $f | Where-Object { $_ -notmatch 'scripts\\start-ai\.cmd' }   # drop any earlier version
$out = foreach ($l in $content) { $l; if ($l -eq ':loop') { $line } }
Set-Content $f $out -Encoding ASCII
Write-Host "Patched $f (original kept as $f.bak-before-ai)"
Select-String $f -Pattern 'start-ai' | ForEach-Object { "  line $($_.LineNumber): $($_.Line)" }

Write-Host "Stopping $task ..."
schtasks /end /tn $task | Out-Null
Start-Sleep -Seconds 2
# Stop only the LakeScope Ollama (127.0.0.1:11435) and its cmd parent, which hold the old log handle.
$pids = netstat -ano | Select-String '127\.0\.0\.1:11435\s.*LISTENING' | ForEach-Object { ($_ -split '\s+')[-1] } | Select-Object -Unique
foreach ($p in $pids) {
    $parent = (Get-CimInstance Win32_Process -Filter "ProcessId=$p").ParentProcessId
    taskkill /PID $p /T /F | Out-Null
    if ($parent -and (Get-CimInstance Win32_Process -Filter "ProcessId=$parent AND Name='cmd.exe'")) { taskkill /PID $parent /T /F | Out-Null }
}
Start-Sleep -Seconds 2
Write-Host "Starting $task ..."
schtasks /run /tn $task
