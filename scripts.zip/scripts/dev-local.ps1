$ErrorActionPreference = "Stop"

$scriptDirectory = Split-Path -Parent $MyInvocation.MyCommand.Path
$projectDirectory = Split-Path -Parent $scriptDirectory
$pythonExecutable = Join-Path $projectDirectory ".venv\Scripts\python.exe"
$logDirectory = Join-Path $projectDirectory "data"
$databaseLauncher = Join-Path $scriptDirectory "start-databases.cmd"

if (-not (Test-Path -LiteralPath $pythonExecutable)) {
    throw "LakeScope is not set up. Run scripts\setup-local.ps1 first."
}
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
    throw "pnpm is required for frontend development. Install Node.js and enable pnpm with Corepack."
}

& $databaseLauncher
if ($LASTEXITCODE -ne 0) {
    throw "PostgreSQL and Neo4j could not be started. Open Podman Desktop and try again."
}

& (Join-Path $scriptDirectory "start-ai.cmd")
if ($LASTEXITCODE -ne 0) {
    Write-Warning "LakeScope AI (Ollama) did not start. LakeScope will run without AI features."
}

New-Item -ItemType Directory -Path $logDirectory -Force | Out-Null
$apiLog = Join-Path $logDirectory "api-dev.log"
$apiErrorLog = Join-Path $logDirectory "api-dev-error.log"
$apiProcess = Start-Process -FilePath $pythonExecutable `
    -ArgumentList "-m", "uvicorn", "backend.app.main:app", "--host", "127.0.0.1", "--port", "8000", "--reload" `
    -WorkingDirectory $projectDirectory `
    -WindowStyle Hidden `
    -RedirectStandardOutput $apiLog `
    -RedirectStandardError $apiErrorLog `
    -PassThru

Push-Location $projectDirectory
try {
    Write-Host "Frontend: http://127.0.0.1:5173"
    Write-Host "API:      http://127.0.0.1:8000/docs"
    pnpm dev
}
finally {
    if (-not $apiProcess.HasExited) {
        Stop-Process -Id $apiProcess.Id
    }
    Pop-Location
}
