# LakeScope — front-end mockup export

## What's in here

```
LakeScope Overview v2 - Studio.dc.html   the full app: 7 screens, sidebar navigation
LakeScope Overview.dc.html               v1, Organic design-system styling (overview only)
support.js                               runtime that renders the .dc.html files
_ds/organic-.../                         the Organic design system (tokens + bundle)
```

Each `.dc.html` is a single self-contained page: markup at the top, a small
`class Component` logic block at the bottom. `support.js` compiles and mounts it
in the browser. No build step, no npm install.

## Running it

The pages load `support.js` and `_ds/...` by relative path, so `file://` will be
blocked by CORS. Serve the folder over HTTP from the project root:

```bash
# Python (already on macOS / most Linux)
python3 -m http.server 8000

# or Node
npx serve .
```

Then open:

```
http://localhost:8000/LakeScope%20Overview%20v2%20-%20Studio.dc.html
```

Navigation is client-side state — the sidebar switches between Estate overview,
Lineage explorer, Impact analysis, SQL inspector, Health & cost, Documentation
and Connections. `⌘K` / `Ctrl+K` opens the command palette. Light/dark and the
five palettes are in the top-right of the header.

## Where the data lives

All sample data is inline markup — there is no data layer yet. Everything is
retail-lake fiction: `retail_raw`, `retail_curated`, `retail_marts`,
`retail_reporting`, with `pos_transactions` → `vw_order_lines_enriched` →
`mv_sku_daily_margin` → `rpt_store_performance_daily` as the spine of the
failing-report story.

## Suggested back-end shape

If you wire this to a real service, these are the reads each screen needs:

| Screen | Endpoint | Returns |
| --- | --- | --- |
| Estate overview | `GET /estate/summary` | object counts, growth series, coverage, failure rate |
| Estate overview | `GET /changes?since=48h` | recent changes with downstream counts |
| Lineage explorer | `GET /lineage/{fqn}?mode=complete&depth=4` | `{nodes[], edges[]}`; edge carries `transform` (SELECT/JOIN/CTAS/…), `inferred`, `health` |
| Asset drawer | `GET /assets/{fqn}` | metadata, freshness, Athena stats, columns, SQL, links |
| Impact analysis | `POST /impact` | `{target, column, changeType}` → impacted assets with severity, distance, path |
| SQL inspector | `GET /assets/{fqn}/sql?version=14` | formatted SQL, parsed references, warnings, unresolved refs |
| SQL inspector | `GET /assets/{fqn}/sql/diff?from=13&to=14` | added/removed/changed edges |
| Health | `GET /health/queries?status=failed` | failures with Athena error codes and downstream impact |
| Health | `GET /health/materialization-candidates` | score + factors (runs, scanned bytes, runtime, failures, downstream) |
| Documentation | `GET/PUT /assets/{fqn}/docs` | descriptions, owner, tags, sensitivity, lifecycle state |
| Documentation | `GET /governance/reviews` | approval queue + audit trail |
| Connections | `GET /connections`, `GET /scans/latest` | source health, scan result, lineage confidence |

Sources to build from: AWS Glue `GetDatabases`/`GetTables` for the catalogue,
Athena `ListQueryExecutions` + `GetQueryExecution` for run history, scan volume
and cost, and a SQL parser (sqlglot handles Athena/Trino dialects well) over
each view's `ViewOriginalText` to derive table- and column-level edges. Store the
graph in Postgres with a recursive CTE for upstream/downstream traversal, or in
Neptune if you want native path queries for the critical-path highlight.

## Notes

- The lineage graph is hand-placed SVG + absolutely positioned nodes. For real
  data, swap it for a layout engine (ELK or dagre) feeding the same node/edge
  visual vocabulary — shapes and icons already distinguish type, so colour is
  never load-bearing on its own.
- v2 follows a minimal editorial direction, not the bound Organic system; v1 is
  the Organic-styled version if you'd rather carry that language forward.
